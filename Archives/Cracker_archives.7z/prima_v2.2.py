"""Module dealing with prime numbers."""

auth = 'Elerias'
date = '05.02.2020'
version = '2.2'


##-import

from math import sqrt
from random import randint
from datetime import datetime
from tkinter import *
from time import time


##-fonctions

def modexp(a, e, n):
    """Return fastly a ** e % n."""
    p = a
    if e == 0:
        return 1
    m = 1
    while e > 1:
        if e % 2 == 1:
            m = m * p
            e = e - 1
        p = p ** 2
        e = e // 2
        m = m % n
        p = p % n
    return (m*p) % n

def expmod(a, e, n): return modexp(a, e, n)

def exponent(a, e):
    """Return fastly a ** e."""
    p = a
    if e == 0:
        return 1
    m = 1
    while e > 1:
        if e % 2 == 1:
            m = m * p
            e = e - 1
        p = p ** 2
        e = e // 2
    return m * p

def gcd(a, b):
    """Return fastly the greater same divisor of a and b."""
    if b > a:
        a, b = b, a
    if b == 0:
        return a
    if a == b or a % b == 0:
        return b

    rest = a % b
    while rest > 0:
        last_rest = rest
        a = b
        b = rest
        rest = a % b

    return last_rest

def pgcd(a, b) : return gcd(a ,b)

def trial_division(n) :
    """Return the primality and the factorization of n as a product of a prime number with trial division algorithm."""

    if n == 0:
        return False, []
    n2 = n

    L_prime_factors = []
    while n2 % 2 == 0:
        n2 = n2 // 2
        L_prime_factors.append('2')
    while n2 % 3 == 0:
        n2 = n2 // 3
        L_prime_factors.append('3')
    while n2 % 5 == 0:
        n2 = n2 // 5
        L_prime_factors.append('5')

    d = 7
    while n2 != 1 and d <= sqrt(n2) :
        while n2 % d == 0:
            n2 = n2 // d
            L_prime_factors.append(str(d))
        d += 4
        while n2 % d == 0:
            n2 = n2 // d
            L_prime_factors.append(str(d))
        d += 2
        while n2 % d == 0:
            n2 = n2 // d
            L_prime_factors.append(str(d))
        d += 4
        while n2 % d == 0:
            n2 = n2 // d
            L_prime_factors.append(str(d))
        d += 2
        while n2 % d == 0:
            n2 = n2 // d
            L_prime_factors.append(str(d))
        d += 4
        while n2 % d == 0:
            n2 = n2 // d
            L_prime_factors.append(str(d))
        d += 6
        while n2 % d == 0:
            n2 = n2 // d
            L_prime_factors.append(str(d))
        d += 2
        while n2 % d == 0:
            n2 = n2 // d
            L_prime_factors.append(str(d))
        d += 6

    if n2 != 1:
        L_prime_factors.append(str(n2))
    primality = False
    if len(L_prime_factors) == 1:
        primality = True
    return (primality, L_prime_factors)

def decomposition_divisions_successives(n) : return trial_division(n)

def factor_fermat(n):
    """Return two factors of n with the factorization of Fermat."""
    x = int(sqrt(n))
    y = 0.5
    while int(y) != y:
        x = x + 1
        y = x ** 2 % n
        y = sqrt(y)
    t = (int(gcd(x - y, n)), int(gcd(x + y, n)))
    if t[0] == n:
        return (t[0]//t[1], t[1])
    elif t[1] == n:
        return (t[1]//t[0], t[0])
    else:
        return t

def fermat_factorization(n):
    """Return the primality and the factorization of n with the factorization of Fermat."""
    L = []
    a, b = factor_fermat(n)
    if (a, b) in [(1, n), (n, 1)]:
        return True, [n]
    else:
        p, La = fermat_factorization(a)
        L.extend(La)
        p, Lb = fermat_factorization(b)
        L.extend(Lb)
    return False, L

def factor_pollard_pm1(n, a) :
    """Find a prime factor of n with the pollard's p - 1 algorithm."""

    if n == 1:
        return False, 1
    if n == 0:
        return False, 0

    end = int(sqrt(n)) + 1

    x = gcd(a, n)
    if x == n:
        return True, n
    if x != 1:
        return False, x

    i = 1
    for B in range(2, end + 1):
        if i % B != 0:
            i = (i*B) % n
        if B % 5000 == 0:
            print(B)
        x = gcd(modexp(a, i, n) - 1, n)
        if i == n - 1 and x == n:
            break
        if x == n:
            return "Error", n
        if x != 1:
            return False, x
    return True, n

def pollard_pm1(n) :
    """Return the primality and the factorization of n as a product of a prime number with pollard's p - 1 algorithm."""

    L_prime_factors = []
    primality, n2 = factor_pollard_pm1(n, 2)
    while primality == "Error":
        primality, n2 = factor_pollard_pm1(n, randint(2 , n - 1))
    if primality:
        return True, [str(n)]
    else :
        L_prime_factors.extend(pollard_pm1(n2)[1])
        n3 = n // n2
        L_prime_factors.extend(pollard_pm1(n3)[1])
    return False, L_prime_factors

def fermat2(n) :
    """Return the primality of n with the probabilistic test of Fermat and a trial division with small numbers."""

    primality = ""

    # Même si cela ne fait pas partie du test, on teste d'abord avec des petits numbers premiers
    if n == 1 or n % 2 == 0 or n % 3 == 0 or n % 5 == 0 or n % 7 == 0:
        primality = False
    if n in (2, 3, 5, 7):
        primality = True

    if primality == "":
        if  n > 1027:
            for d in range(7, 1028, 30) :
                if n % d == 0 or n % (d+4) == 0 or n % (d+6) == 0 or n % (d+10) == 0 or n % (d+12) == 0 or n % (d+16) == 0 or n % (d+22) == 0 or n % (d+24) == 0:
                    primality = False

    # Test PGP
    if primality == "":
            if modexp(2, n - 1, n) != 1 or modexp(3, n - 1, n) != 1 or modexp(5, n - 1, n)!=1 or modexp(7, n - 1, n) != 1:
                primality = False
    if primality == "":
        # Si le number n'a pas été discrédité par la fonction, il a de fortes chances d'être premier
        primality = True

    return primality

def miller_rabin_witness(a, d, s, n):
    """Return True if a is a Miller-Rabin witness."""

    r = modexp(a, d, n)
    if r == 1 or r == n - 1:
        return False

    for k in range(s):
        r = r**2 % n
        if r == n - 1:
            return False

    return True

def miller_rabin(n, k) :
    """Return the primality of n using the probabilistic test of primality of Miller-Rabin. k is the number of the loops. The possible decreases in averages of 75 % by unity if k."""

    # calculation de s et de d tels que 2**s*d = n-1 avec s le plus grand possible
    s = 1
    d = n // 2
    while d % 2 == 0:
        s +=  1
        d = d // 2
    for k in range(k) :
        a = randint(2, n - 1)
        if miller_rabin_witness(a, d, s, n):
            return False
    return True

def f(x) : return x ** 2 + 1

def pollard_rho(n):
    """Return the primality and the factorization of n as a product of prime factors with Pollard's rho algorithm."""

    L = []
    while n > 1:
        x = 2
        y = 2
        d = 1
        while d == 1:
            x = f(x) % n
            y = f(f(y)) % n
            d = gcd(abs(x - y), n)
        L.append(d)
        n = n // d
    return (len(L) == 1, L)
    # Inspire de wikipedia


##-using


##-console

def use():
    """Use prima fonctions"""

    c = ''
    while c not in ('quit', 'exit', 'quit', 'quit', '5'):

        print('Menu :\n')

        print("Factorization of a number as a product of prime numbers")
        print('1 : Trial division')
        print("2 : Pollard's p - 1 algorithm")
        print("3 : Pollard's rho algorithm")
        print("4 : Fermat factorization")
        print("Probabilistic primality's test")
        print('5 : Fermat test with some small divisions')
        print("6 : Miller-Rabin test")
        print('7 : Quit')

        c = ''
        c = input('\nChoice : ')
        while c not in ('1', '2', '3', '4', '5', '6', '7'):
            print('Error, choice not found in the menu')
            c = input('\nChoice : ')

        if c != '6':
            n = int(input('Enter the integer number : '))

        t1 = datetime.now()
        if c == '1':
            p, L = trial_division(n)
        elif c == '2':
            p, L = pollard_pm1(n)
        elif c == '3':
            p, L = pollard_rho(n)
        elif c == '4':
            p, L = fermat_factorization(n)
        elif c == '5':
            p = fermat2(n)
        elif c == '6':
            nt = int(input('Number of tests (Error = 0.25 ** number of tests) : '))
            t1 = datetime.now()
            p = miller_rabin(n, nt)

        t = datetime.now() - t1
        if c in ('1', '2', '3', '4'):
            if p:
                print(n, 'is a prime number')
            else:
                print(n, 'is a composite number')
            print('List of prime factors : ', L)
        elif c in ('5', '6'):
            if p:
                print(n, 'is likely a prime number')
            else:
                print(n, 'is a composite number')
        if c != '7':
            print('Realised in', t)
            input('')


##-tkinter

def refresh() :

    global var_algorithm, var_type_algorithm, window

    algorithm = var_algorithm.get()
    type_algorithm = var_type_algorithm.get()

    if type_algorithm == "Decomposition" and algorithm in ["Trial division", "Pollard's p - 1 algorithm", "Pollard's rho algorithm", "Fermat's factorization"]:
        window.after(100, refresh)
        return 1

    if type_algorithm == "Probabilistic" and algorithm in ["Miller-Rabin's primality test", "Fermat's primality test (+ trial division)"]:
        window.after(100, refresh)
        return 1

    if type_algorithm == "Decomposition":
        var_algorithm.set("Trial division")
        L = OptionMenu(window, var_algorithm, "Trial division", "Pollard's p - 1 algorithm", "Pollard's rho algorithm", "Fermat's factorization")
        L.place(x=325, y=250)
    elif type_algorithm == "Probabilistic":
        var_algorithm.set("Miller-Rabin's primality test")
        L = OptionMenu(window, var_algorithm, "Miller-Rabin's primality test", "Fermat's primality test (+ trial division)")
        L.place(x=325, y=250)
    elif type_algorithm == "Deterministic":
        var_algorithm.set("")
        L = OptionMenu(window, var_algorithm, "")
        L.place(x=325, y=250)
    window.after(50, refresh)
    return 1


def calculate() :

    global var_algorithm, var_number

    t1 = time()
    mode = var_algorithm.get()
    number = var_number.get()
    result_1 = Label(window,text="Processing ... "+" "*120)
    result_2 = Label(window, text=" "*120)
    primality = ""
    decomposition = []

    if mode == "Fermat's primality test (+ trial division)":
        primality = fermat2(number)
    elif mode == "Trial division":
        primality, decomposition = trial_division(number)
    elif mode == "Pollard's p - 1 algorithm":
        primality, decomposition = pollard_pm1(number)
    elif mode == "Pollard's rho algorithm":
        primality, decomposition = pollard_rho(number)
    elif mode == "Fermat's factorization":
        primality, decomposition = fermat_factorization(number)
    elif mode=="Miller-Rabin's primality test":
        primality = miller_rabin(number, 10)

    if primality:
        if len(str(number)) <= 90:
            result_1["text"] = str(number) + " is a prime number" + " "*120
        else :
            result_1["text"] = "That number is a prime number" + " "*120
    else :
        if len(str(number)) <= 90:
            result_1["text"] = str(number)+" is not a prime number" + " "*120
        else :
            result_1["text"] = "That number is not a prime number" + " "*120
    result_1.place(x=50, y=350)

    if len(decomposition) > 0:
        if len(decomposition) > 1:
            for k in range(len(decomposition)):
                decomposition[k] = str(decomposition[k])
            result_2["text"] = str(number) + " = " + "*".join(decomposition)+" "*120
        else :
            result_2["text"] = str(number) + " = " + decomposition[0] + " "*120
    result_2.place(x=50, y=380)

    time_calculation = round(time() - t1, 2) * 1000
    label_time_calculation = Label(window,text="Duration of the calculation : " + str(time_calculation) + " ms" + " "*150)
    if time_calculation >= 1000:
        label_time_calculation = Label(window,text="Duration of the calculation : " + str(int(time_calculation/1000)) + " s " + str(time_calculation) + " ms" + " "*150)
    if time_calculation >= 60000:
        label_time_calculation = Label(window,text="Duration of the calculation : " + str(int(time_calculation/60000))+" h " + str(int(time_calculation/1000))+" s "+str(time_calculation)+ " ms"+" "*150)
    if time_calculation >= 3600000 :
        label_time_calculation = Label(window,text="Duration of the calculation : " + str(int(time_calculation/3600000)) + " j " + str(int(time_calculation/60000)) + " h " + str(int(time_calculation/1000)) + " s " + str(time_calculation) + " ms" + " "*150)
    label_time_calculation.place(x=50, y=410)
    return 0

def use_tkinter():
    """Launch prima in gui."""

    global window
    window = Tk()
    window.title("Prima")
    window.resizable(False, False)
    window.geometry("800x500+283+134")

    titre = Label(window, text="Prima", width=50)
    titre.place(x=222, y=15)

    button_quit = Button(window, text="Quit", command=window.destroy)
    button_quit.place(x=730, y=15, width=50)

    global var_algorithm, var_number, var_type_algorithm

    ask_number = Label(window, text="Enter a number :", width=0)
    ask_number.place(x=349, y=70)

    var_number = IntVar()

    number_entry_line = Entry(window, textvariable=var_number, width=100)
    number_entry_line.place(x=96, y=100)

    label_type_algorithm = Label(window, text="Type of algorithm :", width=0)
    label_type_algorithm.place(x=347, y=140)

    var_type_algorithm = StringVar()

    type_decomposition = Radiobutton(window, text="Decomposition as a product of prime factors", variable=var_type_algorithm, value="Decomposition")
    type_probabilistic = Radiobutton(window, text="Probabilistic primality test", variable=var_type_algorithm, value="Probabilistic")
    type_deterministic = Radiobutton(window, text="Deterministic primality test", variable=var_type_algorithm, value="Deterministic")

    type_decomposition.place(x=300, y=170)
    type_probabilistic.place(x=300, y=190)
    type_deterministic.place(x=300, y=210)

    var_algorithm = StringVar()

    window.after(50, refresh)

    button_calculate = Button(window, text="Calculate", command=calculate)
    button_calculate.place(x=367, y=300)

    window.mainloop()