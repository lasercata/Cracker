"""Module incuding wordlist_generator fonctions"""

auth = 'Lasercata'
date = '02.02.2020'
version = '3.2'

##-ini

from hashlib import *
from datetime import datetime
from random import shuffle

from color import cl_out, c_output, cl_inp, c_succes, c_wrdlt, c_error
from base_functions import inp_lst, inp_int, space


##-hasher

def hasher(h, txt):
    """Return txt's h hash."""

    h_str = tuple(algorithms_available)

    if h in h_str:
        try:
            ret = eval(h_str[h_str.index(h)])(txt.encode()).hexdigest()

        except:
            ret = new(h_str[h_str.index(h)], txt.encode()).hexdigest()

    else:
        return 'The hash was NOT founded !!!'

    return ret

def use():

    h_str = tuple(algorithms_available)
    prompt_h = 'sha3-256, sha512-256, sha512, blake2s256, whirlpool, shake256, md5, shake_128, sm3, mdc2, blake2b512, sha3_256, sha512-224, sha3-384, sha3_224, sha3_512, sha3-224, shake_256, sha384, shake128, blake2b, md4, sha224, sha3_384, blake2s, md5-sha1, sha1, sha256, sha3-512, ripemd160'
    prompt = 'Hashes :\n\n ' + prompt_h + '\n\nChoose a hash to hash with :'

    h = inp_lst(prompt, h_str)

    txt = cl_inp('Word to hash :')

    prnt = '=====> ' + hasher(h, txt)
    cl_out(c_output, prnt)

##-hash_crack

def hash_crack():
    """Crack a hash"""

    h_str = tuple(algorithms_available)
    prompt_h = 'sha3-256, sha512-256, sha512, blake2s256, whirlpool, shake256, md5, shake_128, sm3, mdc2, blake2b512, sha3_256, sha512-224, sha3-384, sha3_224, sha3_512, sha3-224, shake_256, sha384, shake128, blake2b, md4, sha224, sha3_384, blake2s, md5-sha1, sha1, sha256, sha3-512, ripemd160'

    found = False

    continu = True
    while continu:

        h = inp_lst('Hashes :\n\n' + prompt_h + '\n\nWhat hash type to crack ? : ', h_str)

        try:
            wordlist_user = cl_inp('Enter your wordlist\'s name :')
            wordlist = open(wordlist_user, 'r')

            hash_user = cl_inp('Enter your ' + h + ' hash :')

        except:
            cl_out(c_error, 'No file of this name !!! \n')

        else:
            #---------verbose
            verbose = 5000
            while not (0 <= verbose <= 100):
                verbose = inp_int('Show the progression ? (the less shown, the faster it is)\nShow : nothing (0), all attemps (100), or each x % (0 < x < 100) :')

            #---------opening wordlist
            print('\nThis operation may be long if the wordlist is big.\n\nOpening ...')
            t1 = datetime.now()

            lst_wrdlst_lines = wordlist.readlines()
            shuffle(lst_wrdlst_lines)
            nb_rep = len(lst_wrdlst_lines)

            t2 = datetime.now() #calc the time duration
            t_dif = t2 - t1
            cl_out(c_succes, 'Opened in ' + str(t_dif) + ' second(s)')

            #---------main loop
            print('\nProcessing ...')
            t1 = datetime.now()

            i = 0
            lst_rep = []
            for word in lst_wrdlst_lines:
                word = word.strip('\n')
                wordlist_hash = hasher(h, word)
                i += 1

                if hash_user == wordlist_hash:
                    prnt = 'Password FOUND !!! ===> ' + word + '\nin ' + space(i) + ' attemps.'
                    cl_out(c_output, prnt)

                    t2 = datetime.now() #calc the time duration
                    t_dif = t2 - t1
                    cl_out(c_succes, 'Done in ' + str(t_dif) + ' second(s)')

                    found = True
                    continu = False
                    break

                else:
                    i100 = round(i/nb_rep*100)
                    if verbose == 100:
                        print('Password is NOT ', word, ' !')
                        print('Attemp n°', space(i), '\n')

                    elif (i100 % verbose == 0) and (i100 not in lst_rep):
                        cl_out(c_wrdlt, str(i100) + ' % of the wordlist tested.', sp=False)
                        lst_rep.append(i100)

            if not found:
                t2 = datetime.now() #calc the time duration
                t_dif = t2 - t1

                cl_out(c_error, 'The password was NOT founded !')
                cl_out(c_error, 'You waste ' + str(t_dif) + ' second(s) !!!')

                continu = False
                break