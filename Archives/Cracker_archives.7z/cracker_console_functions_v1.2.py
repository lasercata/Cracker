#!/bin/python3
# -*- coding: utf-8 -*-

cracker_console_functions__auth = 'Lasercata'
cracker_console_functions__last_update = '26.05.2020'
cracker_console_functions__version = '1.2'

cracker_authors = 'Lasercata, Elerias'


##-import

from os import getcwd
from os import chdir
from os import system
from datetime import datetime
from getpass import getpass
from time import sleep
from sys import exit as sysexit
import platform

#chdir('../..')

try:
    from modules.base.matrix import *
    from modules.base.base_functions import *
    from modules.base.console.color import *

    from modules.ciphers.hashes import hasher
    from modules.ciphers.crypta import crypta
    from modules.ciphers.kris import AES #, RSA, KRIS

    from modules.wordlists import wordlist_generator #, wordlist_analyzor
    from modules.prima import prima
    from modules.b_cvrt import b_cvrt
    from modules.password_testor import pwd_testor


except ModuleNotFoundError as ept:
    err = str(ept).strip("No module named")

    try:
        cl_out(c_error, 'Put the module ' + err + ' back !!!')

    except NameError: #color not imported
        print('\nPut the module ' + err + ' back !!!')

    sysexit()


##-ini

#---------ascii art
auth_ascii_lasercata = """
       _______ _______ _______  ______ _______ _______ _______ _______
|      |_____| |______ |______ |_____/ |       |_____|    |    |_____|
|_____ |     | ______| |______ |    \_ |_____  |     |    |    |     |"""

auth_ascii_Elerias = """
 _______        _______  ______ _____ _______ _______
 |______ |      |______ |_____/   |   |_____| |______
 |______ |_____ |______ |    \_ __|__ |     | ______|"""

# http://patorjk.com/software/taag/#p=display&f=Cyberlarge&t=Cracker
cracker = """
 _______  ______ _______ _______ _     _ _______  ______
 |       |_____/ |_____| |       |____/  |______ |_____/
 |_____  |    \_ |     | |_____  |    \_ |______ |    \_"""

# http://patorjk.com/software/taag/#p=display&f=Speed&t=Cracker
cracker_ = """
_________                   ______
__  ____/____________ _________  /______________
_  /    __  ___/  __ `/  ___/_  //_/  _ \_  ___/
/ /___  _  /   / /_/ // /__ _  ,<  /  __/  /
\____/  /_/    \__,_/ \___/ /_/|_| \___//_/"""

# https://manytools.org/hacker-tools/convert-images-to-ascii-art/
cracker_logo = """
      ///  ////
     ///      //
     //       //
    /////   /////
   /////// ///////
   /////   ///////
   //////  ///////
    //////   ////"""

lst_ascii = (cracker, cracker_, cracker_logo, auth_ascii_Elerias, auth_ascii_lasercata)

#---------menu
menu_on = True
menu_choice = ''

choice = ''

#---------passwords
pwd_h = 'sha512'
pwd = '6a0cc613e360caf70250b1ddbe169554ddfe9f6edc8b0ec33d61d80d9d0b11090434fcf27d24b40f710bc81e01c05efd78a0086b4673bd042b213e8c7afb4b0c'

#pwd = 'c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec'

admin_h = 'sha512'
admin_pwd = '0e1faf4b92c262ea33c915792b3245b890bc9c30efc3aed327ac559b2731355a8531a2ba7a04efc36eefda6aa64fca6e375e123a4c8c84a856c1121429a6357d'

#---------version
try:
    with open('version.txt', 'r') as f:
        cracker_version = f.read()

except FileNotFoundError:
    cl_out(c_error, 'The file "version.txt" was not found. A version will be set but can be wrong.')
    cracker_version = '3.0.0 ?'

else:
    if len(cracker_version) > 9:
        cl_out(c_error, 'The file "version.txt" contain more than 9 characters, so it certainly doesn\'t contain the actual version. A version will be set but can be wrong.')
        cracker_version = '3.0.0 ?'

#---------modules_ver
try:
    with open('versions_modules.txt') as f_:
        modules_ver = f_.read()

except FileNotFoundError: #todo: if not found, use the headers var (i.g. crypta__ver)
    cl_out(c_error, 'The file "versions_modules.txt" was NOT found !!!')
    modules_ver = ''

#---------update_notes (histrory)
try:
    with open('Updates/history.txt') as f_:
        update_notes = f_.read()

except FileNotFoundError:
    cl_out(c_error, 'The file "history.txt" was NOT found !!!')
    update_notes = ''


##-fonctions


##-admin

def admin():
    cl_out(c_error, 'You just activate the admin mode !', c_admin)
    admin_lock(admin_h, admin_pwd)
    print('test')

    cl_out_2(c_prog, 'Update notes :', c_output, update_notes, c_admin)
    cl_out_2('pink', 'Authors :', c_ascii, auth_ascii_Elerias + '\n' + auth_ascii_lasercata, c_admin)

    cl_out(c_wrdlt, '\nLaunching command prompt ...\n', c_ascii)
    print('Tap "exit" to exit.\n')
    if platform.system() == 'Windows':
        system('cmd')
    elif platform.system() == 'Linux':
        system('bash')

    print('\nBack menu ...')


##-admin_lock

def admin_lock(h, pwd_hashed):
    locked = True

    while locked:
        color(c_admin)
        print('\nWrite your password :')
        color('light_blue')
        saisie = getpass('>')
        color(c_admin)

        saisie_hashed = hasher.hasher(saisie, h)

        if saisie_hashed == pwd_hashed:
            cl_out(c_admin, 'Good password !')
            locked = False

        else:
            cl_out(c_error, 'Bad password !!!')


##-lock

def lock(pwd_hashed, max_tries=3):

    locked = True
    score_l = 0

    while locked:
        print('\nEnter your password :')
        color(c_input)
        saisie = getpass('>')
        color(c_prog)

        saisie_hashed = hasher.hasher(saisie, pwd_h)

        if saisie_hashed == pwd_hashed:
            cl_out(c_succes, 'Good password !')
            sleep(0.25)
            locked = False

        else:
            score_l += 1
            cls()
            prnt = 'Bad password, try n°' + str(score_l)
            cl_out(c_error, prnt)

        if score_l >= max_tries:
            menu_on = False
            sysexit()


##-path

def path():
    prnt = ' ' + getcwd()
    cl_out_2(c_prog, 'Current working directory :', c_input, prnt)

    try:
        path = cl_inp('Path of the new repertory (0 or ctrl + C to abort) (/ between folders) :')

        if path in ('0', ''):
            cl_out(c_error, 'Aborting ...\nBack menu ...')

        else:
            chdir(path)

    except FileNotFoundError:
        cl_out(c_error, 'The path was NOT founded !\nBack menu ...')

    else:
        cl_out(c_succes, 'Success !!!')


##-menu

def menu_inp():
    color(c_prog)
    print('\nMenu :\n')

    color(c_error)
    print('    0.Quit')
    print('    l.lock')

    color(c_input)
    print('    ' + '-' * 16)
    color(c_ascii)

    print('    1.Hasher menu')
    print('    2.Wordlists menu')
    print('    3.Crypta menu')
    print('    4.Prima menu')
    print('    5.Base convert menu')
    print('    6.Test your password\'s strenth')

    color(c_input)
    print('    ' + '-' * 16)
    color(c_wrdlt)

    print('    7.Change directory')
    print('    8.Change colors')
    print('    9.Show infos on Cracker')

    color(c_prog)
    print('\nYour choice :')

    color(c_input)
    ret = input('>')
    color(c_prog)

    return ret


def heading(small=False, more=True): #todo: change the versions !

    if more:
        print('\n\n')

    if not small:
        print('This toolbox application allow you to generate wordlists, hashs, crack hashs, and more !')
        color(c_wrdlt)
        print('\nThis app uses wordlist_generator_6 and hasher tools, developped by lasercata and Elerias.')

    else:
        color(c_wrdlt)
        print('This toolbox application allow you to generate wordlists, hashs, crack hashs, and more !\n')

    color(c_prog)
    print('Version of Cracker :', cracker_version)
    print('Version of wordlist_generator :', wordlist_generator.version)
    print('Version of hasher_tools :', hasher.version)
    print('Version of color :', color_version)
    print('Version of prima :', prima.version)
    print('Version of crypta :', crypta.version)

    if more:
        color(c_succes)
        input('--- After ---')

        cl_out(c_wrdlt, 'Ascii art vars :', c_ascii)
        for k in lst_ascii:
            print(k)

        color(c_succes)
        input('--- After ---')

        cl_out_2(c_wrdlt, 'Update notes :', c_output, update_notes)

        color(c_succes)
        input('--- After ---')

        cl_out_2(c_wrdlt, 'Authors :', c_ascii, auth_ascii_Elerias + '\n' + auth_ascii_lasercata)

        color(c_succes)
        input('--- End ---')


#---------ini
dct_func = {'1': hasher.use, '2': wordlist_generator.use, '3': crypta.use, '4' : prima.use,
'5': b_cvrt.use, '6': pass_test.use, '7': path, '8': c_color, '9': heading, 'admin': admin}