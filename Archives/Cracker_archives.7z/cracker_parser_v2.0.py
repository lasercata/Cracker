auth = 'lasercata'
version = '2.0'
date = '05.02.2020'


##-import

import argparse
from cracker_console_functions import *


##-parser

def chk_rng(arg): #check range for verbosity, from internet
    try:
        value = int(arg)

    except ValueError as err:
       raise argparse.ArgumentTypeError(str(err))

    if not 0 <= value <= 100:
        message = "Expected value in [0 ; 100], got {}".format(value)
        raise argparse.ArgumentTypeError(message)

    return value


#---------ini
cmd_ = False

info = 'This toolbox application allow you to generate wordlists, hashs, crack hashs, and more !'

examples = """Examples :

    Crackerp2.py -hsh -ht md5 -txt test
    Crackerp2.py -w -lth 4 -alf a-z -fn w4az -v 5
    Crackerp2.py -c -fn w4az -ht md5 -txt 098f6bcd4621d373cade4e832627b4f6 -v5

    Crackerp2.py -o -fn w4az"""


def Cracker_parser():
    global cmd_


    parser = argparse.ArgumentParser(prog='Crackerp2',
                                        description=info,
                                        epilog=examples,
                                        formatter_class=argparse.RawDescriptionHelpFormatter)


    grp_lvl1 = parser.add_mutually_exclusive_group()

    grp_lvl1.add_argument('-hsh', '--hash',
                            help='Hash a string',
                            action='store_true')

    grp_lvl1.add_argument('-w', '--generate_wordlist',
                            help='Generates a wordlist',
                            action='store_true')

    grp_lvl1.add_argument('-c', '--hash_crack',
                            help='Try to crack a hash (brute force attack)',
                            action='store_true')

    grp_lvl1.add_argument('-o', '--open',
                            help='Open a wordlist and show infos',
                            action='store_true')

    grp_lvl1.add_argument('-i', '--show_infos',
                            help='Show infos on Cracker',
                            action='store_true')


    parser.add_argument('-v', '--verbosity',
                        type=chk_rng,
                        default=5,
                        help='Increase output verbosity. Must be in [0 ; 100] (0 : show nothing, 100 : all). Default set as 5.')


    parser.add_argument('-ht', '--hash_type',
                        help='The hash\'s type. Should be used with -hsh and -c option.') #hasher, h_crack

    parser.add_argument('-txt', '--text',
                        help='Some text (word to hash in -hsh, hash to crack in -c)') #hasher, hash_crack


    parser.add_argument('-fn', '--file_name',
                        help='The wordlist\'s name. Should be used with -w, -c and -o options.') #wrdlst_gen, h_crack, open_w

    parser.add_argument('-lth', '--lenth',
                        type=int,
                        help='The wordlist\'s words lenth. Should be used with -w option.') #wrdlst_gen

    parser.add_argument('-alf', '--alphabet',
                        help='The alphabet (a-z ; 0-9 ; a-z, 0-9 ; A-Z ; A-Z, 0-9 ; a-z, A-Z ; a-z, A-Z, 0-9 ; 0-1 ; hex (0-9, A-F) ; spe ; all (a-z, A-Z, 0-9, spe) are defined, but you can also write yours). Should be used with -w option.') #wrdlst_gen

    args = parser.parse_args()


    if args.show_infos: #------------------------------------------------------i

        lock(pwd)

        heading()


    elif args.hash: #--------------------------------------------------------hsh
        if args.hash_type != None and args.text != None:

            hashed = hasher.hasher(args.hash_type, args.text)

            if hashed != 'The hash was NOT founded !!!':
                cl_out_2(c_prog, 'The hash of "' + args.text + '" in ' + args.hash_type + ' is :\n', c_output, ' ' + hashed)

            else:
                print('\n', hashed)

        else:
            cl_out(c_error, '\nYou must complete --hash_type (-ht) and --text options (-txt) !!!')


    elif args.generate_wordlist: #---------------------------------------------w

        lock(pwd)

        if args.alphabet != None and args.lenth != None and args.file_name != None:

            wordlist_generator.use(args.file_name, args.lenth, args.alphabet, args.verbosity)

        else:
            cl_out(c_error, '\nYou must complete --lenth (-lth), --alphabet (-alf) and --file_name (-fn) options !!! (and optionaly --verbosity (-v))')


    elif args.hash_crack: #----------------------------------------------------c

        lock(pwd)

        if args.hash_type != None and args.file_name != None and args.text != None:

            hasher.hash_crack(args.hash_type, args.text, args.file_name, args.verbosity)

        else:
            cl_out(c_error, '\nYou must complete --file_name (-fn), --hash_type (-ht) and --text (-txt) options !!! (and optionaly --verbosity (-v))')


    elif args.open: #----------------------------------------------------------o
        if args.file_name != None:

            open_w(args.file_name)

        else:
            cl_out(c_error, '\nYou must complete --file_name (-fn) option !!!')


    else : #--------------------------------------------------------------------
        print('\nWelcome in Cracker !')
        heading(False, False)

        color(c_input)
        print('\nHash : --hash (-hsh) option ;')
        print('Generate a wordlist : --generate_wordlist (-w) option ;')
        print('Crack a hash (bruteforce attack) : --hash_crack (-c) option ;')
        print('Show info on a wordlist : --open (-o) option ;')
        print('Show informations on Cracker : --show_infos (-i) option.')

        cl_out(c_output, 'Type "Crackerp2.py -h" for more information.')

        cmd_ = True


#todo: add log files (option) where we can write result
#todo: add option open from a file (like lst of hashes)


##-run
color(c_prog)

print('___')
color(c_ascii)
print(cracker)
color(c_wrdlt)
print('\nby ', auth)

color(c_ascii)
print('')
print('\\'*60)
color(c_prog)


try:
    Cracker_parser()

except KeyboardInterrupt:
    cl_out(c_error, 'Keyboard Interrupt !!!', sp=True)

finally:
    color(c_ascii)
    print('')
    print('\\'*60)


if cmd_:
    if platform.system() == 'Windows':
        cl_out(c_wrdlt, 'Launching command prompt ...\n', c_ascii)
        system('prompt $gcmd$g&cmd') #prompt >cmd> and launch a command prompt instance, to keep the prog open

#by lasercata, Elerias

# _______        _______  ______ _____ _______ _______
# |______ |      |______ |_____/   |   |_____| |______
# |______ |_____ |______ |    \_ __|__ |     | ______|

#          _______ _______ _______  ______ _______ _______ _______ _______
#   |      |_____| |______ |______ |_____/ |       |_____|    |    |_____|
#   |_____ |     | ______| |______ |    \_ |_____  |     |    |    |     |
