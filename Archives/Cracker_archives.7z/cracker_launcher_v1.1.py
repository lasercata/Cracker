auth = 'lasercata'
version = '1.1'
date = '05.02.2020'


##-import
from sys import exit as sysexit

try:
    from modules.base.cracker_console_functions import *

except ModuleNotFoundError as ept:
    err = str(ept).strip("No module named")

    print('\nPut the module ' + err + ' back !!!')

    sysexit()


##-run

color(c_prog)

lock(pwd)

cls()

print('\nWelcome in Cracker !')
heading(False, False)

while menu_on:

    color(c_ascii)
    print(cracker)
    color(c_output)
    print('\nby ', auth)

    color(c_input)
    print('')
    print('\\'*60)
    color(c_prog)

    menu_choice = menu_inp()


    if menu_choice in tuple(dct_func.keys()): # option 1 to 9
        use_menu(dct_func[menu_choice])


    elif menu_choice == 'l': # lock
        cls()
        lock(pwd)
        cls()
        menu_choice = False


    elif menu_choice in ('0', 'q', 'exit', 'Exit', 'EXIT', 'quit', 'Quit', 'QUIT'): # quit

        sure = ''
        if menu_choice not in ('quit', 'q'): #tap 'q' or 'quit' to exit faster (don't need to confirm)
            while sure != 'y' and sure != 'n':

                color(c_error)
                sure = input('\nAre you sure ? (y/n) :\n>')
                color(c_prog)

        if sure == 'y' or menu_choice in ('quit', 'q'):
            cl_out('yellow', 'By ' + auth)
            sleep(0.15)
            cl_out(c_ascii, auth_ascii_Elerias)
            sleep(0.30)
            cl_out(c_ascii, auth_ascii_lasercata)
            sleep(0.5)
            cl_out(c_error, 'Quitting ...')
            sleep(0.25)

            menu_on = False

        else:
            print('\nBack menu ...')
            menu_choice = False


    else:
        prnt = '"' + menu_choice + '" is NOT an option of this menu !'
        cl_out(c_error, prnt)

#by lasercata, Elerias

 # _______        _______  ______ _____ _______ _______
 # |______ |      |______ |_____/   |   |_____| |______
 # |______ |_____ |______ |    \_ __|__ |     | ______|

#          _______ _______ _______  ______ _______ _______ _______ _______
#   |      |_____| |______ |______ |_____/ |       |_____|    |    |_____|
#   |_____ |     | ______| |______ |    \_ |_____  |     |    |    |     |