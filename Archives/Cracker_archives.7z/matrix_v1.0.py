"""Programme traitant des matrices"""

auth = 'Elerias'
date = '22.12.2019'
version = '1.0'


def det(M) :
    """Fonction recursive calculant le determinant d'une matrice carree M"""

    if len(M) == 1 :    # calcul pour matrice carree de taille 1
        return M[0][0]
    if len(M) == 2 :    # calcul pour matrice carree de taille 2
        return M[0][0] * M[1][1] - M[0][1] * M[1][0]
    else :    # calcul pour toutes matrices
        d = 0
        for k in range(len(M)) :
            M2=[]
            for l in range(len(M)-1) :
                M2.append(M[l+1][0:k]+M[l+1][k+1:len(M)]) # on crée la matrice M2 qui sera formée par le reste de la matrice M en supprimant la première ligne et la k+1ème colonne
            if k % 2 == 0 :    # on multiplie le déterminant de la matrice M2 par le coefficient se situant à l'intersection de la ligne et de la colonne supprimées lors de la formation de M2
                d = d + M[0][k] * det(M2)
            else :
                d = d - M[0][k] * det(M2)
        return d

def t(M,i,j) :
    M2 = []
    for h in M :
        M2.append(list(h))
    del M2[i]
    for k in range(len(M2)) :
        del M2[k][j]
    return M2

def inverse_modulaire(a,n) :
    if a == 1 :
        return 1
    n2=n
    reste=a%n2
    aq=1
    au=1
    av=0
    u=0
    v=1
    while reste>1 :
        reste=a%n2
        q=(a-reste)//n2
        nu=au-q*u
        nv=av-q*v
        aq=q
        au=u
        av=v
        u=nu
        v=nv
        a=n2
        n2=reste
    inverse=(u+n)%n
    return inverse

class Matrix :
    """Classe permettant d'utiliser les matrices, L est la valeur de la matrice. C'est une liste composée de m listes représentants les lignes et elles-mêmes composées de n nombres"""

    def __init__(self, M) :
        self.valeur = M

    def __repr__(self) :
        a = ""
        for k in self.valeur :
            for l in k :
                a = a + str(l) + " "
            a = a[0:-1] + "\n"
        return a[0:-1]

    def __getitem__(self, i) :
        return self.valeur[i]

    def __add__(A, B) :
        """Somme de deux matrices"""

        vA = A.valeur
        vB = B.valeur
        if len(vA) == len(vB) and len(vA[0]) == len(vB[0]) :
            vC = []
            for i in range(len(vA)) :
                a = []
                for j in range(len(vA[0])) :
                    a.append(vA[i][j] + vB[i][j])
                vC.append(a)
            C = Matrix(vC)
            return C
        else :
            return "Indéfini"

    def __sub__(A, B) :
        """Différence de deux matrices"""

        vA = A.valeur
        vB = B.valeur
        if len(vA) == len(vB) and len(vA[0]) == len(vB[0]) :
            vC = []
            for i in range(len(vA)) :
                a = []
                for j in range(len(vA[0])) :
                    a.append(vA[i][j] - vB[i][j])
                vC.append(a)
            C = Matrix(vC)
            return C
        else :
            return "Indéfini"

    def __mul__(A, B) :
        """Produit de deux matrices ou une matrice et un nombre"""

        if type(A) != Matrix or type(B) != Matrix :
            if type(A) == Matrix :
                A, B = B, A
            vB = B.valeur
            vC = []
            for i in vB :
                a = []
                for j in i :
                    a.append(A * j)
                vC.append(a)
            C = Matrix(vC)
            return C

        vA = A.valeur
        vB = B.valeur
        if len(vA[0]) == len(vB) :
            vC = []
            for i in range(len(vA)) :
                a = []
                for j in range(len(vB[0])) :
                    s = 0
                    for k in range(len(vA[0])) :
                        s = s + vA[i][k] * vB[k][j]
                    a.append(s)
                vC.append(a)
            C = Matrix(vC)
            return C
        else :
            return "Indéfini"

    def __truediv__(A, B) :
        """Produit de la matrice A et l'inverse de la matrice ou le nombre B"""

        if type(B) == Matrix :
            if n == 0 :
                return A * B.inverse()
        else :
            if n == 0 :
                return A * (1 / B)

    def __mod__(A, n) :
        """Fonction renvoyant la matrice A modulo n"""

        vA = A.valeur
        vB = []
        for i in vA :
            c = []
            for j in i :
                c.append(j % n)
            vB.append(c)
        return Matrix(vB)

    def __pow__(A, n) :
        """Elevation de la matrice A à la puissance n"""

        B = A
        for k in range(n-1) :
            B = B * A
        return B

    def det(self) :
        """Fonction renvoyant le déterminant de la matrice"""

        M = self.valeur
        if len(M) == len(M[0]) :    # si la matrice est carrée, on calcule son déterminant
            return det(M)
        else :
            return "Indéfini"

    def transposee(self) :
        """Fonction renvoyant la transposée de la matrice"""

        M = self.valeur
        M2 = []
        for j in range(len(M[0])) :
            c = []
            for k in range(len(M)) :
                c.append(M[k][j])
            M2.append(c)
        return Matrix(M2)

    def comatrice(self) :
        """Fonction renvoyant la comatrice issue de la matrice"""

        M = self.valeur
        C = []
        nl = len(M)
        nc = len(M[0])
        for i in range(nc) :
            c = []
            for j in range(nl) :
                if (i + j) % 2 == 0 :
                    c.append(det(t(M, i, j)))
                else :
                    c.append(-det(t(M, i, j)))
            C.append(c)
        return Matrix(C)

    def inverse(self, n=0) :
        """Fonction renvoyant l'inverse de la matrice carrée M et modulo n si spécifié"""

        M = self.valeur
        if n == 0 :
            return self.comatrice().transposee() * (1 / (self.det()))
        else :
            return (self.comatrice().transposee() * inverse_modulaire(self.det(), n)) % n

    def trace(self) :
        """Fonction renvoyant la trace de la matrice carrée M"""

        t = 0
        M = self.valeur
        a = len(M[0])
        if len(M) < len(M[0]) :
            a = len(M)
        for k in range(a) :
            t = t + M[k][k]
        return t