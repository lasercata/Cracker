auth = 'lasercata, Elerias' #authors
version = 'v5.2_parse' #version of Cracker
ver = 'v5.2_p'

ver_wdlst_gen_6 = 'v6.2.2' #version of wordlist_generator_6

ver_hasher_tools = 'v3.2' #version of hasher_tools

update_notes = """
Cracker_v5.0 ~~~ 31.12.2019
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
Improvements (from 4.1) :
    -This list ;
    -This list is print in the admin mode ;
    -ver_wdlst_gen_6 is now correct (v6.2.2) ;
    -hasher v5 is used (a lot smaller and uses all available hashes) ;
    -color v2.0 is used, it is smaller (uses a dict) ;
    -The input prompt ends now by '\\n>' (and no more by '\\n>>>') ;
    -When an error occur in a function, it now print the error. (cf to use_menu()) ;
    -Adding function space from b_cvrt_all : space(1234567, 3) -> '1 234 567' ;
    -Adding wlth and walf functions from P@ssw0rd_Test0r to improve open_w :
    => open_w show now the alphabets and their lenth ;
    => It also show all the differents characters present in the wordlist ;
    -Replacement of the menu by a function to save hundreds of lines ;
    -Improving hash_crack : it can now show every x% the progression ;
    -Some smalls corrections (bugs and other) ;

    -Adding ascii art (auth_ascii, cracker, cracker_logo).

**************
"""

update_notes += """
Cracker_v5.1 ~~~ 01.01.2020
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
Improvements (from 5.0) :
    -Creating the function set_prompt which return a string enumeration from a list ;
    -hash_crack now show the time you waste if you didn't find the password ;
    -open_w and hash_crack show how many time did they spend to open and read a wordlist ;
    -hash_crack use random.shuffle to randomize the order of the wordlist to find the password faster ;
    -Addind an option to the menu which show this and other informations ;
    -Adding color var c_ascii, set to 'orange', used to print ascii art ;
    -Using now sys.exit() to quit in lock, if there was more than 4 bad passwords trieds.

**************
"""

update_notes += """
Cracker_v5.1_parse "Crackerp.py" ~~~ 07.01.2020
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
Improvements (from 5.1) :
    -Correcting lock : the max tries are now correct (no more max_ + 1) ;
    -Adding ver variable (version in smaller) ;

    -Renaming the file to "Crackerp.py" (easier to write in the terminal) ;
    -Adding a argparse function to use the prog.

**************
"""

update_notes += """
Cracker_v5.2_parse "Crackerp2.py" ~~~ 12.01.2020
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
Improvements (from 5.1_parse) :
    Now compatible with Linux !!!

    -Upgraging the color function : the prog can now run on Linux ;
    -Adding function cls which clear screen (win and linux) ;
    -Adding the konsole to the admin mode (to run cmd in Parrot os) ;
    -Seting the password in sha512 hash to deserve more platforms (like win32).

**************
"""

##-import
import ctypes #color

import platform

from os import getcwd
from os import chdir
from os import system

from sys import exit as sysexit

from datetime import datetime

from getpass import getpass

from random import shuffle

from time import sleep

from hashlib import *

import argparse

##-ini
#---------ascii art
auth_ascii_lasercata = """
       _______ _______ _______  ______ _______ _______ _______ _______
|      |_____| |______ |______ |_____/ |       |_____|    |    |_____|
|_____ |     | ______| |______ |    \_ |_____  |     |    |    |     |"""

auth_ascii_Elerias = """
 _______        _______  ______ _____ _______ _______
 |______ |      |______ |_____/   |   |_____| |______
 |______ |_____ |______ |    \_ __|__ |     | ______|"""

#http://patorjk.com/software/taag/#p=display&f=Cyberlarge&t=Cracker
cracker = """
 _______  ______ _______ _______ _     _ _______  ______
 |       |_____/ |_____| |       |____/  |______ |_____/
 |_____  |    \_ |     | |_____  |    \_ |______ |    \_"""

#http://patorjk.com/software/taag/#p=display&f=Speed&t=Cracker
cracker_ = """
_________                   ______
__  ____/____________ _________  /______________
_  /    __  ___/  __ `/  ___/_  //_/  _ \_  ___/
/ /___  _  /   / /_/ // /__ _  ,<  /  __/  /
\____/  /_/    \__,_/ \___/ /_/|_| \___//_/"""

#https://manytools.org/hacker-tools/convert-images-to-ascii-art/
cracker_logo = """
      ///  ////
     ///      //
     //       //
    /////   /////
   /////// ///////
   /////   ///////
   //////  ///////
    //////   ////"""

lst_ascii = (cracker, cracker_, cracker_logo, auth_ascii_Elerias, auth_ascii_lasercata)

#---------menu
menu_on = True
menu_choice = ''

choice = ''

#---------prog colors
c_prog = 'light_blue'
c_input = 'green'
c_error = 'red'
c_wrdlt = 'pink'
c_admin = 'green'
c_succes = 'green'
c_ascii = 'orange'

if platform.system() == 'Windows':
    c_output = 'yellow'

elif platform.system() == 'Linux':
    c_output = 'blue'

#---------passwords
pwd_h = 'sha512'
pwd = '6a0cc613e360caf70250b1ddbe169554ddfe9f6edc8b0ec33d61d80d9d0b11090434fcf27d24b40f710bc81e01c05efd78a0086b4673bd042b213e8c7afb4b0c'

admin_h = 'sha512'
admin_pwd = '0e1faf4b92c262ea33c915792b3245b890bc9c30efc3aed327ac559b2731355a8531a2ba7a04efc36eefda6aa64fca6e375e123a4c8c84a856c1121429a6357d'

#---------alf for wordlist_generators
alf_0_1 = ('0', '1')

alf_0_9 = ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')


alf_hex = ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a','b','c','d','e',
'f')


alf_a_z = ('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q',
'r','s','t','u','v','w','x','y','z')


alf_A_Z = ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
'O', 'P', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z')


alf_a_z_0_9 = ('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2',
'3', '4', '5', '6', '7', '8', '9')


alf_A_Z_0_9 = ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
'N', 'O', 'P', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3',
'4', '5', '6', '7', '8', '9')


alf_a_z_A_Z = ('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C',
'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T',
'U', 'V', 'W', 'X', 'Y', 'Z')


alf_a_z_A_Z_0_9 = ('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l',
'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B',
'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S',
'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8',
'9')


alf_spe = (' ', '!', '"', '#', '$', '%', '&', "'", '(', ')', '*', '+', ',', '-',
 '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{',
  '|', '}', '~', '£', '§', '¨', '°', '²', 'µ', '’', '€')


alf_all = alf_a_z_A_Z_0_9 + alf_spe


alfs = (alf_0_1, alf_0_9, alf_hex, alf_a_z, alf_A_Z, alf_a_z_0_9, alf_A_Z_0_9,
alf_a_z_A_Z, alf_a_z_A_Z_0_9, alf_spe, alf_all)

inp_alf = ('0-1', '0-9', 'hex', 'a-z', 'A-Z', 'a-z, 0-9', 'A-Z, 0-9', 'a-z, A-Z',
'a-z, A-Z, 0-9', 'spe', 'all')

#---------color
dct_col = {'invisible' : 0, 'orange' : 1, 'blue' : 9, 'green' : 10, 'light_blue' : 11,
'red' : 12, 'pink' : 13, 'yellow' : 14, 'white' : 15}

#---------Hashes
h_str = tuple(algorithms_available)



##-fonctions
#---------inp_int
def inp_int(prompt):
    """Works like input but accepts only intengers, reask if not.""" #sorry for the english

    while True:
        try:
            var = cl_inp(prompt)
            var = int(var)

        except ValueError:
            cl_out(c_error, '\nWhat you entered is NOT an interger number !!!')

        else:
            break

    return var


#---------inp_lst
def inp_lst(prompt, lst):
    """Works like input but accepts only values in the list lst, reask if not.""" #sorry for the english

    c = ''
    while c not in lst:
        c = cl_inp(prompt)

    return c


#---------set_prompt
def set_prompt(lst):
    """Return a str organized correctly to print ;
    lst should be a list, a tuple, or a set."""

    var = list(str(lst))
    while "'" in var:
        var.remove("'")

    del var[0], var[-1]

    ret = ''
    for k in var:
        ret += k

    return ret


#---------space
def space(n, grp=3): #----------------------
    """Return n with spaced groups of grp."""
    n = str(n)

    lth = len(str(n))
    n_lst = list(n)
    n_lst.reverse()

    i = 0
    for k in range(lth):
        if k % grp == 0 and k != 0:
            n_lst = n_lst[:k+i] + [' '] + n_lst[k+i:]
            i += 1

    n_lst.reverse()

    ret = ''
    for k in n_lst:
        ret += k

    return ret


#---------clear_screen
def cls():
    if platform.system() == 'Windows':
        system('cls')

    elif platform.system() == 'Linux':
        system('clear')


##-alphabets functions
#---------wlth
def wlth(word):
    """Return the sort list of all differents word's characters, in one occurence."""

    lst_exist = []

    for k in word:
        if k not in lst_exist:
            lst_exist.append(k)

    lst_exist.sort()
    return tuple(lst_exist)


#---------walf
def walf(word, verbose=False):
    """Return word's alphabet lenth.
    If verbose, return the alphabets, in str."""

    char = ([], [], [], []) #char_nb, char_alph, char_alph_up, char_spe
    lst_chr = [] #last character [0;1], [2;9], [a;f], [g/G;z/Z], spe

    #---------get last alphabet character
    for k in word:
        if k in alf_0_9: #numeric
            char[0].append(k)

        elif k in alf_a_z: #alphabetic lowercases
            char[1].append(k)

        elif k in alf_A_Z: #alphabetic uppercases
            char[2].append(k)

        elif k in alf_spe: #specials characters
            char[3].append(k)

    for k in char:
        if k != []:
            k.sort(reverse=True)
            lst_chr.append(k[0])


    #---------get alfs
    bi = dec = hex_ = alph = alph_up = spe = False

    for k in lst_chr:
        if k in alf_0_1: #binary
            bi = True

        elif k in alf_0_9[2:]: #decimal
            dec = True

        elif k in alf_hex[10:] and (k not in alf_a_z[6:] and k not in alf_A_Z[6:]): #hexadecimal
            hex_ = True

        elif k in alf_a_z[6:]: #alphabetic lowercases
            alph = True

        elif k in alf_A_Z: #alphabetic uppercases
            alph_up = True

        elif k in alf_spe: #specials
            spe = True


    #---------sort alfs
    ret_alfs = ''
    n = 0 #lenth of the alphabet

    if hex_:
        ret_alfs += 'Hexadecimal'
        n += 16

    elif dec:
        ret_alfs += 'Decimal'
        n += 10

    elif bi:
        ret_alfs += 'Binary'
        n += 2

    if alph and alph_up:
        if bi or dec or hex_: #to print correctly the ',' between alphabets
            ret_alfs += ', Alphabetic lower and uppercases'
        else:
            ret_alfs += 'Alphabetic lower and uppercases'
        n += 2*26

    elif alph_up:
        if bi or dec or hex_:
            ret_alfs += ', Alphabetic uppercases'
        else:
            ret_alfs += 'Alphabetic uppercases'
        n += 26

    elif alph:
        if bi or dec or hex_:
            ret_alfs += ', Alphabetic lowercases'
        else:
            ret_alfs += 'Alphabetic lowercases'
        n += 26


    if spe:
        if bi or dec or hex_ or alph or alph_up:
            ret_alfs += ', Specials'
        else:
            ret_alfs += 'Specials'
        n += len(alf_spe)


    if verbose:
        return ret_alfs

    return n


##-color
#---------ini
if platform.system() == 'Windows':
    handle = ctypes.windll.kernel32.GetStdHandle(-11)

    col = lambda x : ctypes.windll.kernel32.SetConsoleTextAttribute(handle, x)

    dct_col = {'invisible' : 0, 'orange' : 1, 'blue' : 9, 'green' : 10, 'light_blue' : 11,
    'red' : 12, 'pink' : 13, 'yellow' : 14, 'white' : 15}


elif platform.system() == 'Linux':
    col = lambda x : print('\033[' + str(x) + 'm', end='')

    dct_col = {'none' : 0, 'bold' : 1, 'lite' : 2, 'italics' : 3, 'underline' : 4,
    'flaches' : 5, 'norm' : 6, 'reverse' : 7, 'invisible' : 8, 'cross' : 9,

    'black' : 30, 'red' : 31, 'green' : 32, 'orange' : 33, 'light_blue' : 34,
    'pink' : 35, 'blue' : 35, 'white' : 37}


#---------color
def color(choice_color):
    """Changes the color ;
    Return False if there was no error ;
    Return True if choice_color is not in dct_col (if an error occur)."""

    global dct_col

    try:
        col(dct_col[choice_color])

    except KeyError:
        print('The input is not a color !!!')
        return True

    else:
        col(dct_col[choice_color])
        return False

##-color_input
def cl_inp(prompt): #color input, works like normal input : var = cl_inp(prompt)
    color(c_prog)
    print('')
    print(prompt)
    color(c_input)
    ret = input('>')
    color(c_prog)

    return ret

def cl_inp_2(color_prompt, prompt, color_input, color_prog): #color_input_2, more precise in the colors.
    color(color_prompt)
    print('')
    print(prompt)
    color(color_input)
    ret = input('>')
    color(color_prog)

    return ret

def cl_out(color_1, prompt, color_2=c_prog, sp=True): #color_output, works like print, with the colors. ex : cl_out(c_error, 'Error')
    color(color_1)
    if sp:
        print('')
    print(prompt)
    color(color_2)

def cl_out_2(color_1, prompt, color_2, prompt_2, color_3=c_prog): #color_output_2, used to print 2 lines with different colors.
    color(color_1)
    print('')
    print(prompt)
    color(color_2)
    print(prompt_2)
    color(color_3)



##-lock
def lock(pwd_hashed, max_tries=3):

    locked = True
    score_l = 0

    while locked:
        print('\nYou must enter the password to acces to this option :')
        color(c_input)
        saisie = getpass('>')
        color(c_prog)

        saisie_hashed = hasher(pwd_h, saisie)

        if saisie_hashed == pwd_hashed:
            cl_out(c_succes, 'Good password !')
            sleep(0.25)
            locked = False

        else:
            score_l += 1
            prnt = 'Bad password, try n°' + str(score_l)
            cl_out(c_error, prnt)

        if score_l >= max_tries:
            menu_on = False
            sysexit()




##-open
def open_w(file_name):
    try:
        wordlist_f = open(file_name, 'r')

    except FileNotFoundError:
        return 'No file of this name !!! \nBack menu ...'

    else:
        print('\nThis operation may be long if the wordlist is big.\n\nOpening ...')

        t1 = datetime.now()
        wordlist_f = open(file_name, 'r')

        #lenth of every word
        line = wordlist_f.readline()
        line = line.strip('\n')
        len_line = len(line)

        print('\nReading ...')

        #number of lines
        wordlist_content = line + '\n' + wordlist_f.read()
        wordlist_c = wordlist_content.split('\n')
        l_wordlist_c = len(wordlist_c)

        #alphabets
        alfs_ = walf(wordlist_content, True)#list of the alphabets
        alf_lth = walf(wordlist_content) #lenth of the alphabets

        #list of the differents characters
        lst_chr = list(wlth(wordlist_content))
        lst_chr.remove('\n')
        char = set_prompt(lst_chr)

        #number of differents chararters
        lth_chr = len(lst_chr)

        #calc the time duration
        t2 = datetime.now()
        t_dif = t2 - t1
        cl_out(c_succes, 'Opened in ' + str(t_dif) + ' second(s)')


        color(c_output)

        prnt = '\nLenth of the words : ' + str(len_line) + ' ;\nLenth of the alphabet : ' + space(alf_lth)
        prnt += ' ;\nLenth of the wordlist : ' + space(l_wordlist_c) + ' lines ;' + '\n\nAlphabets : ' + alfs_ + ' ;'
        prnt += '\n\nNumber of differents characters : ' + space(lth_chr) + ' ;\nList of all the presents characters :\n '
        prnt += str(char)
        print(prnt)

        choice = inp_lst('Print the content ? (y/n)', ('y', 'n'))

        if choice == 'y':
            cl_out(c_wrdlt, wordlist_content)
            cl_out(c_output, prnt + '\n')

        else:
            print('\nBack menu ...')

        color(c_prog)

        wordlist_f.close()

##-hasher
#---------ini
prompt_h = set_prompt(algorithms_available)

#---------hasher
def hasher(h, txt):
    """Return txt's h hash."""

    global h_str

    if h in h_str:
        try:
            ret = eval(h_str[h_str.index(h)])(txt.encode()).hexdigest()

        except:
            ret = new(h_str[h_str.index(h)], txt.encode()).hexdigest()

    else:
        return 'The hash was NOT founded !!!'

    return ret


#---------use_hasher
def use_hasher():

    global h_str
    global prompt_h

    prompt = 'Hashes :\n\n ' + prompt_h + '\n\nChoose a hash to hash with :'

    h = inp_lst(prompt, h_str)

    txt = cl_inp('Word to hash :')

    prnt = '=====> ' + hasher(h, txt)
    cl_out(c_output, prnt)

##-hash_crack
def hash_crack(ht, u_hash, wrdlst, verbose):
    """Try to crack a hash with a wordlist.
    ht : the hash type ;
    u_hash : user's hash to crack ;
    wrdlst : the wordlist's name ;
    verbose : verbose level (show : nothing (0), every (100), or each x % (0 < x < 100)).
    """

    global h_str

    found = False

    continu = True
    while continu:
        try:
            wordlist = open(wrdlst, 'r')

        except:
            return 'No file of this name !!! \n'

        else:
            #---------opening wordlist
            print('\nThis operation may be long if the wordlist is big.\n\nOpening ...')
            t1 = datetime.now()

            lst_wrdlst_lines = wordlist.readlines()
            shuffle(lst_wrdlst_lines)
            nb_rep = len(lst_wrdlst_lines)

            t2 = datetime.now() #calc the time duration
            t_dif = t2 - t1
            cl_out(c_succes, 'Opened in ' + str(t_dif) + ' second(s)')

            #---------main loop
            print('\nProcessing ...')
            t1 = datetime.now()

            i = 0
            lst_rep = []
            for word in lst_wrdlst_lines:
                word = word.strip('\n')
                wordlist_hash = hasher(ht, word)
                i += 1

                if u_hash == wordlist_hash:
                    color(c_succes)
                    print('\nPassword FOUND !!! ===> ' + word)
                    color(c_output)
                    print('in ' + space(i) + ' attemps.')

                    t2 = datetime.now() #calc the time duration
                    t_dif = t2 - t1
                    cl_out(c_succes, 'Done in ' + str(t_dif) + ' second(s)')

                    found = True
                    continu = False
                    break

                else:
                    if verbose:
                        i100 = round(i/nb_rep*100)

                        if verbose == 100:
                            print('Password is NOT ', word, ' !')
                            print('Attemp n°', space(i), '\n')

                        elif (i100 % verbose == 0) and (i100 not in lst_rep):
                            cl_out(c_wrdlt, str(i100) + ' % of the wordlist tested.', sp=False)
                            lst_rep.append(i100)

            if not found:
                t2 = datetime.now() #calc the time duration
                t_dif = t2 - t1

                cl_out(c_error, 'The password was NOT founded !')
                cl_out(c_error, 'You waste ' + str(t_dif) + ' second(s) !!!')

                continu = False
                break


##-wordlist_generator_6
def wordlist_generator_6(alf,dep_lth,lth,f_name,b_word, verbose):
    """Write a wordlist in a file. version : v6.2.2
    alf : the alphabet used to write the wordlist ;
    dep_lth : the lenth of the words in the wordlist ;
    lth : the remaining letters to add to the word ;
    f_name : the filename ;
    b_word : the begin of the word."""

    global file_
    global rep
    global lst_rep

    len_alf = len(alf)
    lth_wrdlst = len_alf**int(dep_lth)

    nb_rep = sum(len_alf**k for k in range(dep_lth - 1))


    if lth == dep_lth : #if it is main function (to open only one time)
        file_ = open(f_name, 'w')

        print('Processing ...\n')
        t1 = datetime.now()
        rep = 0
        lst_rep = []


    if lth == 1:
        for k in alf:
            file_.write(b_word + k + '\n')

    else :
        for k in alf:
            wordlist_generator_6(alf, dep_lth, lth-1, f_name, b_word + k, verbose)

        #print the progression
        if verbose:
            rep += 1
            rep100 = round(rep/nb_rep*100, 3)
            r_rep100 = round(rep100)

            if verbose == 100:
                cl_out(c_wrdlt, str(rep100) + ' % done.', sp=False)

            elif (r_rep100 % verbose == 0) and (r_rep100 not in lst_rep):
                cl_out(c_wrdlt, str(r_rep100) + ' % done.', sp=False)
                lst_rep.append(r_rep100)



    if lth == dep_lth:
        t2 = datetime.now() #calc the time duration
        t_dif = t2 - t1
        cl_out(c_succes, 'Done in ' + str(t_dif) + ' second(s)')

        file_.close()


#---------use
def use_wrdlst_gen(f_name, lenth, in_alf, verbose):
    global alf_a_z, afl_A_Z, alf_0_9, alf_a_z_0_9, alf_a_z_A_Z, alf_A_Z_0_9, alf_a_z_A_Z_0_9, alf_hex, alf_0_1, alf_spe, alf_all, alfs, inp_alf

    if in_alf not in inp_alf:
        alf = list(in_alf)

    else:
        for k in range(len(inp_alf)):
            if inp_alf[k] == in_alf:
                alf = list(alfs[k])


    #---------confirm
    len_alf = len(alf)
    len_wordlist = len_alf**int(lenth)

    prnt = 'Lenth of the words : ' + str(lenth) + '\nLenth of the alphabet : ' + space(len_alf)
    prnt += '\nLenth of the wordlist : ' + space(len_wordlist) + ' lines.' + '\n\nShow every ' + str(verbose) + '%'
    cl_out(c_output, prnt)

    choice = inp_lst('Generate ? (y/n) :', ('y', 'n'))

    if choice == 'y':
        wordlist_generator_6(alf, lenth, lenth, f_name, '', verbose)


##-menu
#---------menu_heading
def heading(small=False, more=True):

    if more:
        print('\n\n')

    if not small:
        print('This toolbox application allow you to generate wordlists, hashs, crack hashs, and more !')
        color(c_wrdlt)
        print('\nThis app uses wordlist_generator_6 and hasher tools, developped by lasercata and Elerias.')

    else:
        color(c_wrdlt)
        print('This toolbox application allow you to generate wordlists, hashs, crack hashs, and more !')

    if platform.system() == 'Linux':
        color(c_prog)

    col(3)
    print('\nVersion of Craker :', version, '(' + ver + ')')
    print('Version of wordlist_generator_6 :', ver_wdlst_gen_6)
    print('Version of hasher_tools :', ver_hasher_tools)

    if platform.system() == 'Linux':
        col(0)

    color(c_prog)

    if more:
        color(c_succes)
        input('--- After ---')

        cl_out(c_wrdlt, 'Ascii art vars :', c_ascii)
        for k in lst_ascii:
            print(k)

        color(c_succes)
        input('--- After ---')

        cl_out_2(c_wrdlt, 'Update notes :', c_output, update_notes)

        color(c_succes)
        input('--- After ---')

        cl_out_2(c_wrdlt, 'Authors :', c_ascii, auth_ascii_Elerias + '\n' + auth_ascii_lasercata)

        color(c_succes)
        input('--- End ---')


##-parser
#---------chk_rng
def chk_rng(arg): #check range for verbosity, from internet
    try:
        value = int(arg)

    except ValueError as err:
       raise argparse.ArgumentTypeError(str(err))

    if not 0 <= value <= 100:
        message = "Expected value in [0 ; 100], got {}".format(value)
        raise argparse.ArgumentTypeError(message)

    return value


#---------ini
cmd_ = False

info = 'This toolbox application allow you to generate wordlists, hashs, crack hashs, and more !'

examples = """Examples :

    Crackerp2.py -hsh -ht md5 -txt test
    Crackerp2.py -w -lth 4 -alf a-z -fn w4az -v 5
    Crackerp2.py -c -fn w4az -ht md5 -txt 098f6bcd4621d373cade4e832627b4f6 -v5

    Crackerp2.py -o -fn w4az"""


#---------parser
def Cracker_parser():
    global cmd_


    parser = argparse.ArgumentParser(prog='Crackerp2',
                                        description=info,
                                        epilog=examples,
                                        formatter_class=argparse.RawDescriptionHelpFormatter)


    grp_lvl1 = parser.add_mutually_exclusive_group()

    grp_lvl1.add_argument('-hsh', '--hash',
                            help='Hash a string',
                            action='store_true')

    grp_lvl1.add_argument('-w', '--generate_wordlist',
                            help='Generates a wordlist',
                            action='store_true')

    grp_lvl1.add_argument('-c', '--hash_crack',
                            help='Try to crack a hash (brute force attack)',
                            action='store_true')

    grp_lvl1.add_argument('-o', '--open',
                            help='Open a wordlist and show infos',
                            action='store_true')

    grp_lvl1.add_argument('-i', '--show_infos',
                            help='Show infos on Cracker',
                            action='store_true')


    parser.add_argument('-v', '--verbosity',
                        type=chk_rng,
                        default=5,
                        help='Increase output verbosity. Must be in [0 ; 100] (0 : show nothing, 100 : all). Default set as 5.')


    parser.add_argument('-ht', '--hash_type',
                        help='The hash\'s type. Should be used with -hsh and -c option.') #hasher, h_crack

    parser.add_argument('-txt', '--text',
                        help='Some text (word to hash in -hsh, hash to crack in -c)') #hasher, hash_crack


    parser.add_argument('-fn', '--file_name',
                        help='The wordlist\'s name. Should be used with -w, -c and -o options.') #wrdlst_gen, h_crack, open_w

    parser.add_argument('-lth', '--lenth',
                        type=int,
                        help='The wordlist\'s words lenth. Should be used with -w option.') #wrdlst_gen

    parser.add_argument('-alf', '--alphabet',
                        help='The alphabet (a-z ; 0-9 ; a-z, 0-9 ; A-Z ; A-Z, 0-9 ; a-z, A-Z ; a-z, A-Z, 0-9 ; 0-1 ; hex (0-9, A-F) ; spe ; all (a-z, A-Z, 0-9, spe) are defined, but you can also write yours). Should be used with -w option.') #wrdlst_gen

    args = parser.parse_args()


    if args.show_infos: #------------------------------------------------------i

        lock(pwd)

        heading()


    elif args.hash: #--------------------------------------------------------hsh
        if args.hash_type != None and args.text != None:

            hashed = hasher(args.hash_type, args.text)

            if hashed != 'The hash was NOT founded !!!':
                cl_out_2(c_prog, 'The hash of "' + args.text + '" in ' + args.hash_type + ' is :\n', c_output, ' ' + hashed)

            else:
                print('\n', hashed)

        else:
            cl_out(c_error, '\nYou must complete --hash_type (-ht) and --text options (-txt) !!!')


    elif args.generate_wordlist: #---------------------------------------------w

        lock(pwd)

        if args.alphabet != None and args.lenth != None and args.file_name != None:

            use_wrdlst_gen(args.file_name, args.lenth, args.alphabet, args.verbosity)

        else:
            cl_out(c_error, '\nYou must complete --lenth (-lth), --alphabet (-alf) and --file_name (-fn) options !!! (and optionaly --verbosity (-v))')


    elif args.hash_crack: #----------------------------------------------------c

        lock(pwd)

        if args.hash_type != None and args.file_name != None and args.text != None:

            hash_crack(args.hash_type, args.text, args.file_name, args.verbosity)

        else:
            cl_out(c_error, '\nYou must complete --file_name (-fn), --hash_type (-ht) and --text (-txt) options !!! (and optionaly --verbosity (-v))')


    elif args.open: #----------------------------------------------------------o
        if args.file_name != None:

            open_w(args.file_name)

        else:
            cl_out(c_error, '\nYou must complete --file_name (-fn) option !!!')


    else : #--------------------------------------------------------------------
        print('\nWelcome in Cracker !')
        heading(False, False)

        color(c_input)
        print('\nHash : --hash (-hsh) option ;')
        print('Generate a wordlist : --generate_wordlist (-w) option ;')
        print('Crack a hash (bruteforce attack) : --hash_crack (-c) option ;')
        print('Show info on a wordlist : --open (-o) option ;')
        print('Show informations on Cracker : --show_infos (-i) option.')

        cl_out(c_output, 'Type "Crackerp2.py -h" for more information.')

        cmd_ = True


#todo: add log files (option) where we can write result
#todo: add option open from a file (like lst of hashes)


##-run
color(c_prog)

print('___')
color(c_ascii)
print(cracker)
color(c_wrdlt)
print('\nby ', auth)

color(c_ascii)
print('')
print('\\'*60)
color(c_prog)


try:
    Cracker_parser()

except KeyboardInterrupt:
    cl_out(c_error, 'Keyboard Interrupt !!!', sp=True)

finally:
    color(c_ascii)
    print('')
    print('\\'*60)


if cmd_:
    if platform.system() == 'Windows':
        cl_out(c_wrdlt, 'Launching command prompt ...\n', c_ascii)
        system('prompt $gcmd$g&cmd') #prompt >cmd> and launch a command prompt instance, to keep the prog open

#by lasercata, Elerias

# _______        _______  ______ _____ _______ _______
# |______ |      |______ |_____/   |   |_____| |______
# |______ |_____ |______ |    \_ __|__ |     | ______|

#          _______ _______ _______  ______ _______ _______ _______ _______
#   |      |_____| |______ |______ |_____/ |       |_____|    |    |_____|
#   |_____ |     | ______| |______ |    \_ |_____  |     |    |    |     |
