#!/bin/python3
# -*- coding: utf-8 -*-
'''Module incuding hasher fonctions'''

auth = 'Lasercata'
date = '07.02.2020'
version = '3.3'

##-import
from hashlib import *
from datetime import datetime
from random import shuffle
#from os import chdir
#chdir('../..')

from modules.base.console.color import color, cl_out, c_output, cl_inp, c_succes, c_wrdlt, c_error, c_prog, c_ascii
from modules.base.base_functions import inp_lst, inp_int, space, set_prompt, use_menu
from modules.crack import hash_crack_2

##-ini
h_str = tuple(algorithms_available)

##-hasher
def hasher(h, txt):
    '''Return txt's h hash.'''

    h_str = tuple(algorithms_available)

    if h in h_str:
        try:
            ret = eval(h_str[h_str.index(h)])(txt.encode()).hexdigest()

        except:
            ret = new(h_str[h_str.index(h)], txt.encode()).hexdigest()

    else:
        return 'The hash was NOT founded !!!'

    return ret

#---#
def use_hasher():
    '''Use hasher function.'''

    h_str = tuple(algorithms_available)
    prompt_h = set_prompt(algorithms_available)
    prompt = 'Hashes :\n\n ' + prompt_h + '\n\nChoose a hash to hash with :'

    h = inp_lst(prompt, h_str)

    txt = cl_inp('Word to hash :')

    prnt = '=====> ' + hasher(h, txt)
    cl_out(c_output, prnt)


##-hash_crack
def hash_crack(ht, u_hash, wrdlst):
    '''Try to crack a hash with a wordlist.
    ht : the hash type ;
    u_hash : user's hash to crack ;
    wrdlst : the wordlist's name.'''

    found = False

    continu = True
    while continu:

        try:
            wordlist = open(wrdlst)

        except FileNotFoundError:
            cl_out(c_error, 'No file of this name !!! \n')

        else:
            #---------opening wordlist
            print('\nThis operation may be long if the wordlist is big.\n\nOpening ...')
            t1 = datetime.now()

            lst_wrdlst_lines = wordlist.readlines()
            shuffle(lst_wrdlst_lines)
            nb_rep = len(lst_wrdlst_lines)

            wordlist.close()

            t2 = datetime.now() #calc the time duration
            t_dif = t2 - t1
            cl_out(c_succes, 'Opened in ' + str(t_dif) + ' second(s)')

            #---------main loop
            print('\nProcessing ...\n')
            t1 = datetime.now()

            i = 0
            l_rep = []
            for word in lst_wrdlst_lines:
                word = word.strip('\n')
                wordlist_hash = hasher(ht, word)
                i += 1

                if u_hash == wordlist_hash:
                    prnt = '\nPassword FOUND !!! ===> ' + word + '\nin ' + space(i) + ' attemps.'
                    cl_out(c_output, prnt)

                    t2 = datetime.now() #calc the time duration
                    t_dif = t2 - t1
                    cl_out(c_succes, 'Done in ' + str(t_dif) + ' second(s)')

                    found = True
                    continu = False
                    break

                else:
                    #---show progression (progress bar)
                    i50 = round(i / nb_rep * 50)

                    if i50 not in l_rep:
                        l_rep.append(i50)

                        color(c_wrdlt)
                        if i > 1:
                            print('\b'*52, end='')
                        print('|' + '#'*i50 + ' '*(50-i50) + '|', end='')
                        color(c_prog)

            if not found:
                t2 = datetime.now() #calc the time duration
                t_dif = t2 - t1

                cl_out(c_error, '\nThe password was NOT founded !')
                cl_out(c_error, 'You waste ' + str(t_dif) + ' second(s) !!!')

                continu = False
                break


def use_hash_crack():
    '''Use hash_crack function.'''
    h_str = tuple(algorithms_available)
    prompt_h = set_prompt(algorithms_available)

    while True:

        try:
            wrdlst_user = cl_inp('Enter your wordlist\'s name :')
            wordlist = open(wrdlst_user, 'r')

            h = inp_lst('Hashes :\n\n' + prompt_h + '\n\nWhat hash type to crack ? : ', h_str)
            u_hash = cl_inp('Enter your ' + h + ' hash :')

        except FileNotFoundError:
            cl_out(c_error, 'No file of this name !!! \n')

        else:
            wordlist.close()
            break

    hash_crack(h, u_hash, wrdlst_user)


##-Using function (menu)
def use():
    '''Use hasher functions'''

    #---menu
    c = ''
    while c not in ('quit', 'exit', '0', 'q'):

        color(c_succes)
        print('')
        print('\\'*50)

        color(c_prog)
        print('\nHasher menu :\n')

        color(c_error)
        print('    0.Main menu')

        color(c_succes)
        print('    ' + '-'*16)
        color(c_ascii)

        print('    1.Hash')
        print('    2.Crack a hash with a wordlist')
        print('    3.Crack a hash with wordlist and brute force')
        color(c_prog)

        c = ''
        c = cl_inp('Your Choice :')


        if c not in ('0', '1', '2', '3', 'q'):
            prnt = '"' + c + '" is NOT an option of this menu !'
            cl_out(c_error, prnt)

        if c == '1':
            use_menu(use_hasher)

        elif c == '2':
            use_menu(use_hash_crack)
        elif c == '3':
            use_menu(hash_crack_2.use())

##-test module
if __name__ == '__main__':
    use()