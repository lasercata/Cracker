auth = 'Elerias'
date = '25.02.2020'
version = '1.0'
site_wlst = 'https://wiki.skullsecurity.org/Passwords'


##-import

from hashlib import *
from os import chdir, listdir


##-main fonctions

def keyboard_sequence(L_result, func, alf='azertyuiopqsdfghjklmwxcvbn'):
    alf = alf + alf
    alfo = list(alf)
    alfo.reverse()
    alfo = "".join(alfo)
    L_find = []
    for i in range(len(alf) // 2):
        for j in range(len(alf) // 2):
            word_test = alf[i:i + j + 1]
            for k in L_result:
                if k == func(word_test):
                    L_result.remove(k)
                    L_find.append((word_test, k))
                    print(word_test, "-->", k)
            word_test = alfo[i:i + j + 1]
            for k in L_result:
                if k == func(word_test):
                    L_result.remove(k)
                    L_find.append((word_test, k))
                    print(word_test, "-->", k)
    return L_result, L_find

def test(L, lenth, L_result, func, dw=""):
    if lenth==1:
        L_find = []
        for i in L:
            word_test = dw + i
            for j in L_result:
                if j == func(word_test):
                    L_result.remove(j)
                    L_find.append((word_test, j))
                    print(word_test, "-->", j)
        return L_result, L_find
    else:
        L_find2 = []
        for k in L:
            L_result, L_find = test(L, lenth-1, L_result, func, dw + k)
            L_find2.extend(L_find)
        return L_result, L_find2


def preimage_finder(L_result, func):
    """Find the preimage of a list of images L_result of a function func, often a hash function, by brute force."""

    L_find2 = []

    # Test 1 - Current password
    L = ['password', '123456', '12345678', 'qwerty', 'abc123', 'monkey', '1234567', 'letmein', 'trustno1', 'dragon', 'baseball', '111111', 'iloveyou', 'master', 'sunshine', 'ashley', 'bailey','passw0rd', 'shadow', '123123', '654321', 'superman', 'qazwsx', 'michael', 'Football', 'welcome', 'football', 'jesus', 'ninja', 'mustang', 'password1', 'adobe123', 'admin', '1234567890', 'photoshop', '1234', '12345', 'princess', 'azerty', '000000', 'access', '696969', 'batman', '123456789', '1qaz2wsx', 'login', 'qwertyuiop', 'solo', 'starwars', 'flower', 'hottie', 'loveme', 'zaq1zaq1', 'hello', 'freedom', 'whatever', '666666', '!@#$%^&*', 'donald', 'qwerty123', 'pussy', 'jennifer', '2000', 'jordan', 'harley', 'fuckme', 'hunter', 'fuckyou', 'ranger', 'buster', 'thomas', 'tigger', 'robert', 'soccer', 'fuck', 'test', 'pass', 'killer', 'hockey', 'george', 'charlie', 'andrew', 'michelle', 'love', 'jessica', 'asshole', '6969', 'pepper', 'daniel', 'joshua', 'maggie', 'silver', 'william', 'dallas', 'yankees', 'amanda', 'orange', 'biteme', 'computer', 'sexy', 'thunder', 'nicole', 'ginger', 'heather', 'hammer', 'summer', 'corvette', 'taylor', 'fucker', 'austin', '1111', 'merlin', 'matthew', '121212', 'golfer', 'cheese', 'martin', 'chelsea', 'patrick', 'richard', 'diamond', 'yellow', 'bigdog', 'secret', 'asdfgh', 'sparky', 'cowboy']
    print("Test 1 - Current passwords wordlist -", len(L), 'values')
    for i in L:
        for j in L_result:
            if func(i) == j:
                    L_result.remove(j)
                    L_find2.append((i, j))
                    print(i, "-->", j)

    # Test 2 - Keyboard sequence - 1300 * 4 + 8 * 20 = 5360 values
    print("Test 2 - Keyboard sequence - 1300 * 4 + 8 * 20 = 5360 values")
    L_alph = ['azertyuiopqsdfghjklmwxcvbn', 'AZERTYUIOPQSDFGHJKLMWXCVBN', 'qwertyuiopasdfghjklzxcvbnm', 'QWERTYUIOPASDFGHJKLZXCVBNM', '0123456789', """"²&é"'(-è_çà)=""", '0123456789°+', 'azertyuiop^$qsdfghjklmù*wxcvbn,;:!']
    for k in L_alph:
        L_result, L_find = keyboard_sequence(L_result, func, k)
        L_find2.extend(L_find)
    if len(L_result) == 0:
           return L_find2

    # Test 3 - 1-6 numbers - 1 111 110 values
    print("Test 3 - 1-6 numbers - 1 111 110 values")
    L = list('0123456789')
    for lenth in range(1, 7):
        if len(L_result) == 0:
           return L_find2
        L_result, L_find = test(L, lenth, L_result, func)
        L_find2.extend(L_find)

    # Test 4 - 1-4 letters a-z - 456 976 values
    print("Test 4 - 1-4 letters a-z - 456 976 values")
    L = list('abcdefghijklmnopqrstuvwxyz')
    for lenth in range(1, 5):
        if len(L_result) == 0:
           return L_find2
        L_result, L_find = test(L, lenth, L_result, func)
        L_find2.extend(L_find)

    # Test 5 - 1-4 letters A-Z - 456 976 values
    print("Test 5 - 1-4 letters A-Z - 456 976 values")
    L = list('ABCDEFGHIJKLMNOPQRSTUVWXYZ')
    for lenth in range(1, 5):
        if len(L_result) == 0:
           return L_find2
        L_result, L_find = test(L, lenth, L_result, func)
        L_find2.extend(L_find)

    # Test 6 - 1-3 all - 1 236 599 values
    print("Test 6 - 1-3 all - 1 236 599 values")
    L = list('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 _&ÃƒÆ’Ã‚Â©~"#\'\\{([-|ÃƒÆ’Ã‚Â¨`ÃƒÆ’Ã‚Â§^ÃƒÆ’ @)Ãƒâ€šÃ‚Â°]=+}$Ãƒâ€šÃ‚Â£Ãƒâ€šÃ‚Â¤Ãƒâ€šÃ‚Â¨ÃƒÆ’Ã‚Â¹%*Ãƒâ€šÃ‚Âµ!Ãƒâ€šÃ‚Â§:/.;?,<>Ã‚Â²')
    for lenth in range(1, 4):
        if len(L_result) == 0:
           return L_find2
        L_result, L_find = test(L, lenth, L_result, func)
        L_find2.extend(L_find)

    # Test 7 - Wordlists
    print("Test 7 - Wordlists")
    try:
        chdir("wordlists")
    except:
        print("Directory wordlists not found !")
    L_wl = listdir()
    for h in range(len(L_wl)):
        print(str(h + 1) + ". " + L_wl[h])
        a = open(L_wl[h], encoding='cp437')
        for i in a:
            for j in L_result:
                if func(i) == j:
                    L_result.remove(j)
                    L_find2.append((i, j))
                    print(i, "-->", j)
        a.close()
        if len(L_result) == 0:
            return L_find2
    chdir('..')

    print("End of the test")

    return L_find2

def use():
    print("Preimage finder by brute force")
    print("Functions (", algorithms_available, ")")
    a = input("Choice : ")
    def f(t):
        h = eval(a)(t.encode()).hexdigest()
        return h
    nw = int(input("Number of words : "))
    L_w = []
    for k in range(nw):
        L_w.append(input("Word " + str(k) + " : "))
    L = preimage_finder(L_w, f)
    for k in L:
        print(k[0], "-->", k[1])