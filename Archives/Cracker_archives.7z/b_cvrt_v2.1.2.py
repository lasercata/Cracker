#!/bin/python3
# -*- coding: utf-8 -*-
'''Module incuding b_cvrt fonctions'''

auth = 'Lasercata'
date = '08.02.2020'
version = '2.1.2'

##-import
#from os import chdir
#chdir('../..')

from math import log

from modules.base.color import color, cl_inp, cl_out, c_error, c_output, c_prog, c_succes, c_ascii
from modules.base.base_functions import use_menu

##-ini
alf_36 = ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z')

##-functions
def b_cvrt(n, nb, b): #----------------------

    '''n : number to convert, in any base ;
    nb : base of n ;
    b : base in the one convert.'''

    lth = len(str(n))
    lst_n = list(str(n))
    lst_n.reverse()

    if b in (1, '1'):
        if int(b_cvrt(n, nb, 10)) < 309:
            return '1' * int(b_cvrt(n, nb, 10))

        else:
            return 0

    if nb in (1, '1'):
        return b_cvrt(lth, 10, b)

    dct = {}
    for i in range(lth):
        dct[i] = int(lst_n[i], nb) * nb**i

    n_10 = 0
    for j in dct:
        n_10 += dct[j]

    #------

    lst_ret = []
    while n_10 > 0:
        reste = n_10%b
        lst_ret.append(reste)
        n_10 = n_10//b

    lst_ret.reverse()

    ret = ""
    for i in lst_ret:
        ret += str(alf_36[i])

    if ret == '':
        ret = 0

    return ret


def b_cvrt_lth(n, nb, b, lth=8): #----------------------

    '''n -> number to convert, in any base ;
    nb -> base of n ;
    b -> base in the one convert ;
    lth -> lenth of the return.'''

    lth_n = len(str(n))
    lst_n = list(str(n))
    lst_n.reverse()

    dct = {}
    for i in range(lth_n):
        dct[i] = int(lst_n[i], nb) * nb**i

    n_10 = 0
    for j in dct:
        n_10 += dct[j]

    #------

    lst_ret = []
    while n_10 > 0:
        reste = n_10%b
        lst_ret.append(reste)
        n_10 = n_10//b

    lst_ret.reverse()

    ret = ''
    for i in lst_ret:
        ret += str(alf_36[i])

    return n_add(ret, lth)


def n_add(n, lth): #----------------------
    if len(str(n)) < lth:
        add = lth - len(str(n))
        lst_n = list(str(n))
        lst_n.reverse()

        for i in range(add):
            lst_n.append(0)

        lst_n.reverse()

        ret = ''
        for i in lst_n:
            ret += str(i)

    else:
        ret = n

    return ret


def inverse(n): #----------------------
    '''Return the reverse of n. n must be a sting.'''

    lst = list(str(n))
    lth = len(lst)

    ret = ''
    for k in range(lth):
        ret += lst[lth-k-1]

    return ret


def insert(lst, n, k): #----------------------
    '''This function returns the list lst with n insert at the position k (lst[k])'''

    return lst[:k] + [n] + lst[k:]


def lth_standard(n, NEG=False): #----------------------
    '''Return n with 0 at left to make a 8, 16, 32, 64, 128, 512, or 1024 bytes number according to the lenth of n.'''

    n = str(n)
    lth = len(n)

    if NEG:
        lth += 1

    if lth <= 8:
        return n_add(n, 8)

    else:
        for k in range(int(log(lth, 2)) + 1):
            if lth > 2**k and lth <= 2*2**k:
                return n_add(n, 2*2**k)


def sp_grp(n, grp): #----------------------
    '''Base of space. Return n with spaced groups of grp.'''
    lth = len(str(n))
    n_lst = list(n)
    n_lst.reverse()

    i = 0
    for k in range(lth):
        if k % grp == 0 and k != 0:
            n_lst = n_lst[:k+i] + [' '] + n_lst[k+i:]
            i += 1

    n_lst.reverse()

    ret = ''
    for k in n_lst:
        ret += k

    return ret


def space(n, nb=3): #----------------------
    '''Return n with regular spaces to easilier read the numbers.
    n -> number to space ;
    nb -> number's base.'''

    lth = len(str(n))
    n = str(n)
    n_lst = list(n)

    if nb <= 10: # floating
        if int(float(n)) != float(n):
            n_int = str(int(float(n))) #integer

            lst_n_fl = n.split('.') # float
            n_fl = lst_n_fl[1]
            n_fl = inverse(n_fl)

            return space(n_int, nb) + '.' + inverse(space(n_fl, nb))

    if nb == 2:
        return sp_grp(n, 4)


    elif nb == 10:
        return sp_grp(n, 3)

    elif nb == 16:
        return sp_grp(n, 2)

    else:
        return sp_grp(n, 3)


def b_cvrt_neg_2(n, nb, b): #----------------------
    '''Return b_cvrt(n, nb, b), using the two by two's complement negative standard'''

    if nb != 2:
        np_0_10 = int( b_cvrt( abs( int( str(n), nb)), nb, 10))
        np_0_de = abs(np_0_10) - 1

        np_0_bi = lth_standard(b_cvrt(np_0_de, nb, b), True)

        ret = ''
        for k in np_0_bi:

            if k == '1':
                ret += '0'

            else:
                ret += '1'

        return ret

    else:
        np_0_bi = ''

        for k in str(n):
            if k == '1':
                np_0_bi += '0'

            else:
                np_0_bi += '1'

        ret = int(b_cvrt(int(np_0_bi), 2, b)) + 1
        ret -= 2 * ret

        return ret


def floating(n, nb, b, inf_ask=False): #----------------------
    inf = False

    lst_n = []

    if nb == 10 and b == 2:
        if int(n) == float(n):
            return float(b_cvrt(n, nb, b))

        fl = '0.'
        int_n_2 = int(b_cvrt(int(n), 10, 2))
        fl_n = round(n - int(n), len(str(n)) - (len(str(int(n))) + 1))

        while fl_n < 1:
            fl_n *= 2
            fl += str(int(fl_n))

            if fl_n > 1 and fl_n != int(fl_n):
                fl_n -= int(fl_n)
                fl_n = round(fl_n, 7)

            if fl_n in lst_n:
                inf = True
                break

            lst_n.append(fl_n)

        fl = float(fl)
        fl += int_n_2

        if inf and inf_ask:
            return 'Approxiamte value : '

        elif not inf_ask:
            return fl


    elif nb == 2 and b == 10:
        if inf_ask:
            return None

        int_n_10 = int(b_cvrt(int(n), 2, 10))
        fl_n = round(n - int(n), len(str(n)) - (len(str(int(n))) + 1))

        lst_fl_n = list(str(fl_n))
        del lst_fl_n[0], lst_fl_n[0] #del '0.'
        lth = len(lst_fl_n)


        lst_ = []
        for i in range(1, lth+1):
            lst_.append(str(int(lst_fl_n[i-1], nb) * nb**-i))

        fl_n_10 = 0
        for j in lst_:
            fl_n_10 += float(j)

        ret = float(int_n_10 + fl_n_10)
        return ret

    else:
        return 'Can only convert float from base 10 in 2, and vice versa.'


def mtse_add(mantisse):
    m = str(mantisse)
    if len(m) < 23:
        add_m = 23 - len(m)
        lst_m = list(m)

        for i in range(add_m):
            lst_m.append(0)

        mtse23 = ''
        for i in lst_m:
            mtse23 += str(i)

        return mtse23

def exp_add(exp_10):
    exp_10_shift = exp_10 + 127
    exp_2 = b_cvrt(exp_10_shift, 10, 2)

    if len(str(exp_2)) < 8: #adding missing 0 to form an octet
        add = 8 - len(str(exp_2))
        lst_exp = list(str(exp_2))
        lst_exp.reverse()

        for i in range(add):
            lst_exp.append(0)

        lst_exp.reverse()

        exp_2_8bits = ''
        for i in lst_exp:
            exp_2_8bits += str(i)

    else:
        exp_2_8bits = exp_2

    return exp_2_8bits


def ieee754(n, nb, b='ieee754'):

    '''This function return n convert in binary, using the standard IEEE 754.
    Form of the IEEE 754 return : 'S EEEEEEEE MMMMMMMMMMMMMMMMMMMMMMM'

    n : float number to convert ;
    nb : base of n ;
    b : base of the returned result, is at ieee754 by default.'''


    if b in ['ieee754', '2', 2] and nb == 10:

        if n < 0:
            bit1 = 1

        else:
            bit1 = 0

        if nb == 10:
            n_fl_2 = floating(abs(n), nb, 2)

        else:
            n_fl_2 = n


        if int(float(n_fl_2)) == 1: #------------------------------------1.01101

            lst_n_fl_2 = str(n_fl_2).split('.')
            mantisse = lst_n_fl_2[1]

            mtse23 = mtse_add(mantisse)

            exp_2_8bits = '01111111'


        elif int(float(n_fl_2)) == 0: #--------------------------------0.0101101

            lst_fl = str(n_fl_2).split('.')

            a = lst_fl[1]
            b = int(lst_fl[1])

            mantisse = ''
            for i in range(len(str(b))):
                if i != 0 and str(b)[i] != '.':
                    mantisse += str(b)[i]

            exp_10 = len(str(mantisse)) - len(a) # exposant
            if not -126 < exp_10 < 127:
                return 'The number is too large or too small : the exposant is not in [-126 ; 127] !!!'

            exp_2_8bits = exp_add(exp_10)

            mtse23 = mtse_add(mantisse)


        else: #----------------------------------------------------------101.101
            str_n_2 = str(n_fl_2)

            mantisse = '' #mantisse
            for i in range(len(str_n_2)):
                if i != 0 and str_n_2[i] != '.':
                    mantisse += str_n_2[i]

            mtse23 = mtse_add(mantisse) #end mantisse

            lst_int_n_fl = str_n_2.split('.') #exposant

            exp_10 = len(lst_int_n_fl[0]) - 1
            if not -126 < exp_10 < 127:
                return 'The number is too large or too small : the exposant is not in [-126 ; 127] !!!'

            exp_2_8bits = exp_add(exp_10)


        ret = str(bit1) + ' ' + str(exp_2_8bits) + ' ' + str(mtse23)
        return ret


    elif b == 10 and nb in ['ieee754', '2', 2]: #-------------------------------
        lst_n = n.split(' ')

        S = int(lst_n[0])
        exp_2 = lst_n[1]
        mtse23 = lst_n[2]

        exp_10_shift = b_cvrt(exp_2, 2, 10)
        exp_10 = int(exp_10_shift) - 127

        mtse_2 = float('1.' + mtse23)
        mtse_10 = floating(mtse_2, 2, 10)

        ret = mtse_10 * 2 **exp_10

        if S < 0:
            ret = -ret

        return ret

    else:
        return 'This program can only convert from base 10 in 2 with the standard IEEE754, and vice-versa.'


##-use
def use_b_cvrt(n, nb, b, NEG, IEEE754=False):
    try:
        nb = int(nb)
        b = int(b)

    except ValueError:
        return "The base b and the number's base nb must be intergers !!!"

    try: #try if it's an int, float or str
        n = float(n)

    except ValueError:
        INT = False
        FL = False

    else:
        if int(float(n)) == float(n):
            n = int(n)
            INT = True
            FL = False

        else:
            FL = True
            fl_n = round(n - int(n), len(str(n)) - (len(str(int(n))) + 1))


    if nb == 2:
        if NEG in (True, 'true', 'T', 't', '1', 1):
            NEG = True

        else:
            NEG = False

    elif FL or INT:
        if float(n) < 0:
            NEG = True



    if IEEE754:
        return ieee754(n, nb, b)


    elif NEG and FL and b == 2:
        if floating(abs(fl_n), nb, b, True) == None:
            return space(float(b_cvrt_neg_2(int(float(n)), nb, b)) + floating(abs(fl_n), nb, b), b)

        else:
            return floating(abs(fl_n), nb, b, True) + space(float(b_cvrt_neg_2(int(float(n)), nb, b)) + floating(abs(fl_n), nb, b), b)


    elif NEG and FL and b == 10:
        if floating(abs(fl_n), nb, b, True) == None:
            return space(float(b_cvrt_neg_2(int(float(n)), nb, b)) - floating(abs(fl_n), nb, b), b)

        else:
            return floating(abs(fl_n), nb, b, True) + space(float(b_cvrt_neg_2(int(float(n)), nb, b)) - floating(abs(fl_n), nb, b), b)


    elif NEG:
        return space(b_cvrt_neg_2(n, nb, b), b)


    elif FL:
        if floating(n, nb, b, True) == None:
            return space(floating(n, nb, b), b)
        else:
            return floating(n, nb, b, True) + space(floating(n, nb, b), b)


    else:
        return space(b_cvrt(n, nb, b), b)


def use_b_cvrt_input():
    correct = False

    while not correct: #Entry of n, nb, b
        try:
            n = cl_inp('Enter the number to convert :')
            nb = int(cl_inp('Enter number\'s base :'))
            b = int(cl_inp('Enter return\'s base :'))

        except ValueError:
            cl_out(c_error, 'The value must be an interger !!!')

        else:
            correct = True


    try: #try if it's an int, float or str
        n = float(n)

    except ValueError:
        INT = False
        FL = False

    else:
        if int(float(n)) == float(n):
            n = int(n)
            INT = True
            FL = False

        else:
            FL = True
            fl_n = round(n - int(n), len(str(n)) - (len(str(int(n))) + 1))


    NEG = False
    if nb == 2:
        NEG = ''
        while NEG not in ('y', 'yes', 'Yes', 'YES', 'n', 'no', 'No', 'NO'):
            NEG = cl_inp("Is the binary digit encoded negatively with the two by two's complement's standard ? (y/n) :")

        if NEG in ('y', 'yes', 'Yes', 'YES'):
            NEG = True

        else:
            NEG = False

    elif FL or INT:
        if float(n) < 0:
            NEG = True


    cl_out(c_output, use_b_cvrt(n, nb, b, NEG))

def use_ieee754():
    correct = False

    while not correct: #Entry of n, nb, b
        try:
            n = cl_inp('Enter the number to convert :')
            nb = int(cl_inp('Enter number\'s base :'))
            b = int(cl_inp('Enter return\'s base :'))

        except ValueError:
            cl_out(c_error, 'The value must be an interger !!!')

        else:
            correct = True

    try: #try if it's an int, float or str
        n = float(n)

    except ValueError:
        INT = False
        FL = False

    else:
        if int(float(n)) == float(n):
            n = int(n)
            INT = True
            FL = False

    cl_out(c_output, ieee754(n, nb, b))



#---------use
def use():
    '''Use b_cvrt functions'''

    #---menu
    c = ''
    while c not in ('quit', 'exit', '0', 'q'):

        color(c_succes)
        print('')
        print('\\'*50)
        color(c_prog)

        print('\nBase convert menu :\n')

        color(c_error)
        print('    0.Main menu')

        color(c_succes)
        print('    ' + '-'*16)
        color(c_ascii)

        print('    1.Convert a number')
        print('    2.Convert using the standard IEEE 754')
        color(c_prog)

        c = ''
        c = cl_inp('Your Choice :')


        if c not in ('0', '1', '2'):
            prnt = '"' + c + '" is NOT an option of this menu !'
            cl_out(c_error, prnt)

        if c == '1':
            use_menu(use_b_cvrt_input)

        elif c == '2':
            use_menu(use_ieee754)

##-test
if __name__ == '__main__':
    use()