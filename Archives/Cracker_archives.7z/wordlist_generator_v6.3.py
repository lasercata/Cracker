"""Module incuding wordlist_generator fonctions"""

author = ('Lasercata', 'Elerias')
date = '26.01.2020'
version = '6.3'


##-initialisation

from datetime import datetime

alf_0_1 = ('0', '1')
alf_0_9 = ('0', '1', '2', '3', '4', '5', '6', '7', '8', '9')
alf_hex = alf_0_9 + ('a', 'b', 'c', 'd', 'e', 'f')
alf_a_z = ('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z')
alf_A_Z = ('A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z')
alf_a_z_0_9 = alf_a_z + alf_0_9
alf_A_Z_0_9 = alf_A_Z + alf_0_9
alf_a_z_A_Z = alf_a_z + alf_A_Z
alf_a_z_A_Z_0_9 = alf_a_z_A_Z + alf_0_9
alf_spe = (' ', '!', '"', '#', '$', '%', '&', "'", '(', ')', '*', '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', '?', '@', '[', '\\', ']', '^', '_', '`', '{', '|', '}', '~', '£', '§', '¨', '°', '²', 'µ', '’', '€')
alf_all = alf_a_z_A_Z_0_9 + alf_spe
alfs = (alf_0_1, alf_0_9, alf_hex, alf_a_z, alf_A_Z, alf_a_z_0_9, alf_A_Z_0_9,
alf_a_z_A_Z, alf_a_z_A_Z_0_9, alf_spe, alf_all)
inp_alf = ('0-1', '0-9', 'hex', 'a-z', 'A-Z', 'a-z, 0-9', 'A-Z, 0-9', 'a-z, A-Z', 'a-z, A-Z, 0-9', 'spe', 'all', 'write')


##-main fonction

def wordlist_generator(alf, dep_lenth, lenth, f_name, b_word, verbose=0):
    """Write a wordlist in a file.

    Keywords arguments :
    alf : the alphabet used to write the wordlist
    dep_lth : the lenth of the words in the wordlist
    lth : the remaining letters to add to the word
    f_name : the filename
    b_word : the begin of the word
    verbose : print the progression all the verbose percents. If verbose = 0, progression is not printed
    """

    global file_

    if verbose != 0:
        global lst_rep
        global rep

    if lenth == dep_lenth:              # If it is main function (to open only one time)
        file_ = open(f_name, 'w')

        if verbose != 0:
            print('\nProcessing ...\n')
            t1 = datetime.now()
            rep = 0
            lst_rep = []

    if lenth == 1:
        for k in alf:
            file_.write(b_word + k + "\n")
    else:
        for k in alf:
            wordlist_generator(alf, dep_lenth, lenth - 1, f_name, b_word + k, verbose)

        if verbose != 0:
            len_alf = len(alf)
            nb = len_alf ** (dep_lenth-2)
            rep += 1
            rep100 = int(rep/nb*100 + 0.5)

            if verbose == 100:
                print(rep100 , '% done.')
            elif (rep100 % verbose == 0) and (rep100 not in lst_rep):
                print(rep100 , '% done.')
                lst_rep.append(rep100)

    if lenth == dep_lenth:
        file_.close()

        if verbose != 0:
            t2 = datetime.now()         # Calcul the time duration
            print('\nDone in ' + str(t2 - t1))


##-using fonction

def use() :
    """Fonction using worlist_generator with console input."""

    global alf_a_z, afl_A_Z, alf_0_9, alf_a_z_0_9, alf_a_z_A_Z, alf_A_Z_0_9, alf_a_z_A_Z_0_9, alf_hex, alf_0_1, alf_spe, alf_all, alfs, inp_alf

    #---------questions
    # name
    f_name = input('\nWhat name give to the wordlist ?\nIt will overwrite any other file of the same name\n>>> ')

    # lenth
    try :
        lenth = int(input('\nWhat lenth for the words ?\n>>> '))
    except ValueError:
        print('\nWhat you entered is not an interger number !')

    # alphabet
    in_alf = ''
    while in_alf not in inp_alf:
        in_alf = input('\nWhat alphabet choose ? \n(a-z ; 0-9 ; a-z, 0-9 ; A-Z ; A-Z, 0-9 ; a-z, A-Z ; a-z, A-Z, 0-9 ; 0-1 ; hex (0-9, A-F) ; spe ; all (a-z, A-Z, 0-9, spe) ; write)\n>>> ')

    if in_alf == 'write':
        alf = input('\nEnter your alphabet (between caracters, no space !) :\n>>> ')
        alf = alf.split(',')
    else:
        k = inp_alf.index(in_alf)
        alf = alfs[k]

    # verbose
    verbose = ''
    while verbose not in ('y', 'Y', 'yes', 'Yes', 'YES','oui', 'Oui', 'n', 'N', 'no', 'No', 'NO', 'non', 'Non'):
        verbose = input('\nShow the progression ? (faster if not)\n>>> ')

    if verbose in ('y', 'Y', 'yes', 'Yes', 'YES', 'oui', 'Oui'):
        verbose = 0
        while not ((5 <= verbose <= 50) or (verbose == 100)):
            try:
                verbose = int(input('\nShow all (100) or every x % with 5 <= x <= 50) ? :\n>>> '))
            except ValueError:
                print('\nWhat you entered is not an interger number !')
    else:
        verbose = 0


    #---------confirm
    len_alf = len(alf)
    len_wordlist = len_alf ** int(lenth)

    print('\nLenth of the alphabet : ' + str(len_alf))
    print('Lenth of the wordlist : ' + str(len_wordlist) + ' lines.')

    choice = ''
    while choice not in ('y', 'n'):
        choice = input('\nGenerate ? (y/n) :\n>>> ')

    if choice == 'y':
        wordlist_generator(alf, lenth, lenth, f_name, '', verbose)
        print('File has been created succesfully')
    else:
        raise KeyboardInterrupt