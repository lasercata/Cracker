"""Toolbox application allowing to generate wordlists, hashs, to crack hashes by brute force"""

auth = ['lasercata', 'Elerias']
version = '2.0.0'
date = '02.02.2020'

update_notes = """
Cracker_v1.5.0 ~~~ 31.12.2019
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
Improvements (from 1.4.1) :
    -This list ;
    -This list is print in the admin mode ;
    -ver_wdlst_gen_6 is now correct (v6.2.2) ;
    -hasher v5 is used (a lot smaller and uses all available hashes) ;
    -color v2.0 is used, it is smaller (uses a dict) ;
    -The input prompt ends now by '\\n>' (and no more by '\\n>>>') ;
    -When an error occur in a function, it now print the error. (cf to use_menu()) ;
    -Adding function space from b_cvrt_all : space(1234567, 3) -> '1 234 567' ;
    -Adding wlth and walf functions from P@ssw0rd_Test0r to improve open_w :
    => open_w show now the alphabets and their lenth ;
    => It also show all the differents characters present in the wordlist ;
    -Replacement of the menu by a function to save hundreds of lines ;
    -Improving hash_crack : it can now show every x% the progression ;
    -Some smalls corrections (bugs and other) ;

    -Adding ascii art (auth_ascii, cracker, cracker_logo).

**************
"""

update_notes += """
Cracker_v1.5.1 ~~~ 01.01.2020
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
Improvements (from 1.5.0) :
    -Creating the function set_prompt which return a string enumeration from a list ;
    -hash_crack now show the time you waste if you didn't find the password ;
    -open_w and hash_crack show how many time did they spend to open and read a wordlist ;
    -hash_crack use random.shuffle to randomize the order of the wordlist to find the password faster ;
    -Addind an option to the menu which show this and other informations ;
    -Adding color var c_ascii, set to 'orange', used to print ascii art.

**************
"""

update_notes += """
Cracker_v1.5.2 ~~~ 11.01.2020
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
Improvements (from 5.1) :
    Now compatible with Linux !!!

    -Upgraging the color function : the prog can now run on Linux ;
    -Adding function cls which clear screen (win and linux) ;
    -Adding the konsole to the admin mode (to run cmd in Parrot os) ;
    -Seting the password in sha512 hash to deserve more platforms (like win32) ;

    -Correcting lock : the max tries are now correct (no more max_ + 1).

**************
"""

update_notes += """
Cracker_v2.0.0 ~~~ 02.02.2020
\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
Improvements (from 1.5.2) :
    - Small visual corrections :
        * Applying of PEP convention
        * Deleting of commentary above the fonctions
        * Deleting of some blanks lines
    - Creating of Cracker repertory including in another files big fonctions :
        * Creating and upgrading of wordlist_generator module
        * Creating of color module
        * Creating of hasher module
        * Creating of base_fonction module
    - Joining to Cracker the module prima including :
        * pgcd, expmod, exponent fonctions
        * Probabilistic primality algorithmes (Fermat and Miller-Rabin)
        * Decomposition in primary factors algorithmes (sucessive divisions and algorithme p - 1 of Pollard)
        * console using fonction
        * tkinter using fonction
    - Joining to Cracker the module crypta including :
        * crypthographic fonctions (atbash, cesar, affine, vigenere, hill, monoalphabetic substitution)
        * cryptanalysis fonctions (ic, frequence analysis, kasiki test)
        * using fonction
    - Password changed because I did not know it. You will easily find it.

**************
"""

# 0:01:42.009312sec (9 848 259 attemps) (80% wrdlst) to find "voile" (hash : sha512) in w5az in order.
# 0:01:18.792728sec (7 677 641 attemps) (65% wrdlst) shuffle (only one try, not an average !)


##-import

from os import getcwd
from os import chdir
from os import system
from datetime import datetime
from getpass import getpass
from time import sleep
from sys import exit as sysexit
import platform

from color import *
from base_fonctions import *
import wordlist_generator
import hasher
import prima
import crypta


##-ini

#---------ascii art
auth_ascii_lasercata = """
       _______ _______ _______  ______ _______ _______ _______ _______
|      |_____| |______ |______ |_____/ |       |_____|    |    |_____|
|_____ |     | ______| |______ |    \_ |_____  |     |    |    |     |"""

auth_ascii_Elerias = """
 _______        _______  ______ _____ _______ _______
 |______ |      |______ |_____/   |   |_____| |______
 |______ |_____ |______ |    \_ __|__ |     | ______|"""

# http://patorjk.com/software/taag/#p=display&f=Cyberlarge&t=Cracker
cracker = """
 _______  ______ _______ _______ _     _ _______  ______
 |       |_____/ |_____| |       |____/  |______ |_____/
 |_____  |    \_ |     | |_____  |    \_ |______ |    \_"""

# http://patorjk.com/software/taag/#p=display&f=Speed&t=Cracker
cracker_ = """
_________                   ______
__  ____/____________ _________  /______________
_  /    __  ___/  __ `/  ___/_  //_/  _ \_  ___/
/ /___  _  /   / /_/ // /__ _  ,<  /  __/  /
\____/  /_/    \__,_/ \___/ /_/|_| \___//_/"""

# https://manytools.org/hacker-tools/convert-images-to-ascii-art/
cracker_logo = """
      ///  ////
     ///      //
     //       //
    /////   /////
   /////// ///////
   /////   ///////
   //////  ///////
    //////   ////"""

lst_ascii = (cracker, cracker_, cracker_logo, auth_ascii_Elerias, auth_ascii_lasercata)

#---------menu
menu_on = True
menu_choice = ''

choice = ''

#---------passwords
pwd_h = 'sha512'
pwd = '6a0cc613e360caf70250b1ddbe169554ddfe9f6edc8b0ec33d61d80d9d0b11090434fcf27d24b40f710bc81e01c05efd78a0086b4673bd042b213e8c7afb4b0c'
pwd = 'c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec'

admin_h = 'sha512'
admin_pwd = '0e1faf4b92c262ea33c915792b3245b890bc9c30efc3aed327ac559b2731355a8531a2ba7a04efc36eefda6aa64fca6e375e123a4c8c84a856c1121429a6357d'


##-fonctions


##-alphabets functions

def wlth(word):
    """Return the sort list of all differents word's characters, in one occurence."""

    lst_exist = []

    for k in word:
        if k not in lst_exist:
            lst_exist.append(k)

    lst_exist.sort()
    return tuple(lst_exist)


def walf(word, verbose=False):
    """Return word's alphabet lenth.
    If verbose, return the alphabets, in str."""

    char = ([], [], [], []) #char_nb, char_alph, char_alph_up, char_spe
    lst_chr = [] #last character [0;1], [2;9], [a;f], [g/G;z/Z], spe

    #---------get last alphabet character
    for k in word:
        if k in wordlist_generator.alf_0_9: #numeric
            char[0].append(k)

        elif k in wordlist_generator.alf_a_z: #alphabetic lowercases
            char[1].append(k)

        elif k in wordlist_generator.alf_A_Z: #alphabetic uppercases
            char[2].append(k)

        elif k in wordlist_generator.alf_spe: #specials characters
            char[3].append(k)

    for k in char:
        if k != []:
            k.sort(reverse=True)
            lst_chr.append(k[0])


    #---------get alfs
    bi = dec = hex_ = alph = alph_up = spe = False

    for k in lst_chr:
        if k in wordlist_generator.alf_0_1: #binary
            bi = True

        elif k in wordlist_generator.alf_0_9[2:]: #decimal
            dec = True

        elif k in wordlist_generator.alf_hex[10:] and (k not in wordlist_generator.alf_a_z[6:] and k not in wordlist_generator.alf_A_Z[6:]): #hexadecimal
            hex_ = True

        elif k in wordlist_generator.alf_a_z[6:]: #alphabetic lowercases
            alph = True

        elif k in wordlist_generator.alf_A_Z: #alphabetic uppercases
            alph_up = True

        elif k in wordlist_generator.alf_spe: #specials
            spe = True


    #---------sort alfs
    ret_alfs = ''
    n = 0 #lenth of the alphabet

    if hex_:
        ret_alfs += 'Hexadecimal'
        n += 16

    elif dec:
        ret_alfs += 'Decimal'
        n += 10

    elif bi:
        ret_alfs += 'Binary'
        n += 2

    if alph and alph_up:
        if bi or dec or hex_: #to print correctly the ',' between alphabets
            ret_alfs += ', Alphabetic lower and uppercases'
        else:
            ret_alfs += 'Alphabetic lower and uppercases'
        n += 2*26

    elif alph_up:
        if bi or dec or hex_:
            ret_alfs += ', Alphabetic uppercases'
        else:
            ret_alfs += 'Alphabetic uppercases'
        n += 26

    elif alph:
        if bi or dec or hex_:
            ret_alfs += ', Alphabetic lowercases'
        else:
            ret_alfs += 'Alphabetic lowercases'
        n += 26


    if spe:
        if bi or dec or hex_ or alph or alph_up:
            ret_alfs += ', Specials'
        else:
            ret_alfs += 'Specials'
        n += len(alf_spe)


    if verbose:
        return ret_alfs

    return n


##-admin

def admin():
    cl_out(c_error, 'You just activate the admin mode !', c_admin)
    admin_lock(admin_h, admin_pwd)

    cl_out_2(c_prog, 'Update notes :', 'yellow', update_notes, c_admin)
    cl_out_2('pink', 'Authors :', c_ascii, auth_ascii_Elerias + '\n' + auth_ascii_lasercata, c_admin)

    print('\nTap "exit" to exit.\n')
    if platform.system() == 'Windows':
        system('cmd')
    elif platform.system() == 'Linux' and 'parrot' in platform.release():
        system('konsole')

    print('\nBack menu ...')


##-admin_lock

def admin_lock(h, pwd_hashed):
    locked = True

    while locked:
        color(c_admin)
        print('\nWrite your password :')
        color('light_blue')
        saisie = getpass('>')
        color(c_admin)

        saisie_hashed = hasher(h, saisie)

        if saisie_hashed == pwd_hashed:
            cl_out(c_admin, 'Good password !')
            locked = False

        else:
            cl_out(c_error, 'Bad password !!!')


##-lock

def lock(pwd_hashed, max_tries=3):

    locked = True
    score_l = 0

    while locked:
        print('\nEnter your password :')
        color(c_input)
        saisie = getpass('>')
        color(c_prog)

        saisie_hashed = hasher.hasher(pwd_h, saisie)

        if saisie_hashed == pwd_hashed:
            cl_out(c_succes, 'Good password !')
            sleep(0.25)
            locked = False

        else:
            score_l += 1
            cls()
            prnt = 'Bad password, try n°' + str(score_l)
            cl_out(c_error, prnt)

        if score_l >= max_tries:
            menu_on = False
            sysexit()


##-path

def path():
    prnt = ' ' + getcwd()
    cl_out_2(c_prog, 'Current working directory :', c_input, prnt)

    try:
        path = cl_inp('Path of the new repertory (0 or ctrl + C to abort) (/ between folders) :')

        if path in ('0', ''):
            cl_out(c_error, 'Aborting ...\nBack menu ...')

        else:
            chdir(path)

    except FileNotFoundError:
        cl_out(c_error, 'The path was NOT founded !\nBack menu ...')

    else:
        cl_out(c_succes, 'Success !!!')


##-open

def open_w():
    try:
        file_name = cl_inp('Enter the wordlist\'s name :')
        wordlist_f = open(file_name, 'r')

    except FileNotFoundError:
        cl_out(c_error, 'No file of this name !!! \nBack menu ...')

    else:
        print('\nThis operation may be long if the wordlist is big.\n\nOpening ...')

        t1 = datetime.now()
        wordlist_f = open(file_name, 'r')

        #lenth of every word
        line = wordlist_f.readline()
        line = line.strip('\n')
        len_line = len(line)

        print('\nReading ...')

        #number of lines
        wordlist_content = line + '\n' + wordlist_f.read()
        wordlist_c = wordlist_content.split('\n')
        l_wordlist_c = len(wordlist_c)

        #alphabets
        alfs_ = walf(wordlist_content, True)#list of the alphabets
        alf_lth = walf(wordlist_content) #lenth of the alphabets

        #list of the differents characters
        lst_chr = list(wlth(wordlist_content))
        lst_chr.remove('\n')
        char = set_prompt(lst_chr)

        #number of differents chararters
        lth_chr = len(lst_chr)

        #calc the time duration
        t2 = datetime.now()
        t_dif = t2 - t1
        cl_out(c_succes, 'Opened in ' + str(t_dif) + ' second(s)')


        color(c_output)

        prnt = '\nLenth of the words : ' + str(len_line) + ' ;\nLenth of the alphabet : ' + space(alf_lth)
        prnt += ' ;\nLenth of the wordlist : ' + space(l_wordlist_c) + ' lines ;' + '\n\nAlphabets : ' + alfs_ + ' ;'
        prnt += '\n\nNumber of differents characters : ' + space(lth_chr) + ' ;\nList of all the presents characters :\n '
        prnt += str(char)
        print(prnt)

        choice = inp_lst('Print the content ? (y/n)', ('y', 'n'))

        if choice == 'y':
            cl_out(c_wrdlt, wordlist_content)
            cl_out(c_output, prnt + '\n')

        else:
            print('\nBack menu ...')

        color(c_prog)

        wordlist_f.close()


##-menu

def menu_inp():
    color(c_prog)
    print('\nMenu :\n')
    color(c_ascii)
    print('1.Hash')
    print('2.Generate a wordlist')
    print('3.Crack a hash')
    print('4.Open a wordlist')
    print('5.Change directory')
    print('6a.Launch prima')
    print('6b.Launch tkinter prima')
    print('7.Launch crypta')
    print('8.Change colors')
    print('9.Show infos on Cracker')
    color(c_error)
    print('10.Lock')
    print('11.Quit')
    color(c_prog)
    print('\nYour choice :')

    color(c_input)
    ret = input('>')
    color(c_prog)

    return ret

def heading(small=False, more=True):

    if more:
        print('\n\n')

    if not small:
        print('This toolbox application allow you to generate wordlists, hashs, crack hashs, and more !')
        color(c_wrdlt)
        print('\nThis app uses wordlist_generator_6 and hasher tools, developped by lasercata and Elerias.')

    else:
        color(c_wrdlt)
        print('This toolbox application allow you to generate wordlists, hashs, crack hashs, and more !\n')

    color(c_prog)
    print('Version of Craker :', version)
    print('Version of wordlist_generator :', wordlist_generator.version)
    print('Version of hasher_tools :', hasher.version)
    print('Version of color :', color_version)
    print('Version of prima :', prima.version)
    print('Version of crypta :', crypta.version)

    if more:
        ctn = cl_inp('Press enter to show next, enter 0 to exit :')
        if ctn == '0':
            raise KeyboardInterrupt

        cl_out_2(c_wrdlt, 'Update notes :', c_output, update_notes)

        ctn = cl_inp('Press enter to show next, enter 0 to exit :')
        if ctn == '0':
            raise KeyboardInterrupt

        cl_out(c_wrdlt, 'Ascii art vars :')
        color(c_ascii)
        for k in lst_ascii:
            print(k)

        ctn = cl_inp('Press enter to show next, enter 0 to exit :')
        if ctn == '0':
            raise KeyboardInterrupt
        cl_out_2(c_wrdlt, 'Authors :', c_ascii, auth_ascii_Elerias + '\n' + auth_ascii_lasercata)

        cl_out(c_wrdlt, '\\' * 60)

        cl_inp('Tap enter to exit ...')


#---------ini
dct_func = {'1': hasher.use, '2': wordlist_generator.use, '3': hasher.hash_crack, '4' :open_w,
'5': path, '6a': prima.use, '6b': prima.use_tkinter, '7': crypta.use, '8': c_color, '9': heading, 'admin': admin}

#---------use_menu
def use_menu(func):
    global menu_choice

    try:
        print('Press ctrl + C to back to menu, anytime.')
        func()

        menu_choice = False

    except KeyboardInterrupt:
        cl_out(c_error, '\nKeyboard interrupt.\nBack menu ...')
        menu_choice = False

    except MemoryError:
        cl_out(c_error, 'Memory Error.\nBack menu ...')

    except Exception as ept:
        cl_out(c_error, 'An error occurred : ' + str(ept) + '.\nBack menu ...')
        menu_choice = False


##-run

color(c_prog)

lock(pwd)

cls()

print('\nWelcome in Cracker !')
heading(False, False)

while menu_on:

    color(c_ascii)
    print(cracker)
    color(c_output)
    print('\nby ', auth)

    color(c_input)
    print('')
    print('\\'*60)
    color(c_prog)

    menu_choice = menu_inp()


    if menu_choice in tuple(dct_func.keys()): # option 1 to 7
        use_menu(dct_func[menu_choice])


    elif menu_choice == '10': # lock
        cls()
        lock(pwd)
        cls()
        menu_choice = False


    elif menu_choice in ('11', '0', 'exit', 'Exit', 'EXIT', 'quit', 'Quit', 'QUIT'): # quit

        sure = ''
        if menu_choice not in ('quit', '0'): #tap '0' or 'quit' to exit faster (don't need to confirm)
            while sure != 'y' and sure != 'n':

                color(c_error)
                sure = input('\nAre you sure ? (y/n) :\n>')
                color(c_prog)

        if sure == 'y' or menu_choice in ('quit', '0'):
            cl_out('yellow', 'By ' + auth)
            sleep(0.15)
            cl_out(c_ascii, auth_ascii_Elerias)
            sleep(0.30)
            cl_out(c_ascii, auth_ascii_lasercata)
            sleep(0.5)
            cl_out(c_error, 'Quitting ...')
            sleep(0.25)

            menu_on = False

        else:
            print('\nBack menu ...')
            menu_choice = False


    else: #----------------------
        prnt = '"' + menu_choice + '" is NOT an option of this menu !'
        cl_out(c_error, prnt)

#by lasercata, Elerias

 # _______        _______  ______ _____ _______ _______
 # |______ |      |______ |_____/   |   |_____| |______
 # |______ |_____ |______ |    \_ __|__ |     | ______|

#          _______ _______ _______  ______ _______ _______ _______ _______
#   |      |_____| |______ |______ |_____/ |       |_____|    |    |_____|
#   |_____ |     | ______| |______ |    \_ |_____  |     |    |    |     |