#!/bin/python3
# -*- coding: utf-8 -*-
"""Module incuding b_cvrt functions  gui"""

auth = 'lasercata'
version = 'v2.0'
date = ''


##-import

from tkinter import *
from modules.b_cvrt.b_cvrt import *


##-window

class Window_b_cvrt(Frame):

    def __init__(self, wind, **kwargs):
        Frame.__init__(self, wind, width=800, height=600, **kwargs)
        self.pack(fill=BOTH)

        # widgets
        self.frame_input = Frame(self)
        self.frame_input.grid(column=0, row=0)

        self.ms_n = Label(self.frame_input, text="      Enter the number n :") #n
        self.ms_n.grid(column=0, row=0)

        self.n = StringVar()
        self.inp_n = Entry(self.frame_input, textvariable=self.n, width=20)
        self.inp_n.grid(column=0, row=1)


        self.ms_nb = Label(self.frame_input, text="Enter number's base nb :") #nb
        self.ms_nb.grid(column=1, row=0)

        self.nb = StringVar()
        self.inp_nb = Entry(self.frame_input, textvariable = self.nb, width = 20)
        self.inp_nb.grid(column=1, row=1)


        self.ms_b = Label(self.frame_input, text="Enter return's base b :") #b
        self.ms_b.grid(column=2, row=0)

        self.b = StringVar()
        self.inp_b = Entry(self.frame_input, textvariable = self.b, width = 20)
        self.inp_b.grid(column=2, row=1)


        self.NEG = IntVar() #NEG
        self.inp_neg = Checkbutton(self, text="Encoded negatively with the two by two's complement's standard", variable = self.NEG)
        self.inp_neg.grid(column=0, row=1)


        self.IEEE754 = IntVar() #IEEE754
        self.inp_ieee754 = Checkbutton(self, text="Encoded with the standard IEEE754", variable = self.IEEE754)
        self.inp_ieee754.grid(column=0, row=2)


        self.ret = Label(self, text='result here', fg='#ffffff', bg='#ff4500') #ret
        self.ret.grid(column=0, row=3)

        self.space = Label(self, text='', width=2)
        self.space.grid(column=1, row=0)

        self.b_cvrt = Button(self, text="CONVERT", command=self.b_cvrt_)
        self.b_cvrt.grid(column=2, row=0)

    def b_cvrt_(self):

        self.ret["text"] = use_b_cvrt(self.n.get(), self.nb.get(), self.b.get(), self.NEG.get(), self.IEEE754.get())