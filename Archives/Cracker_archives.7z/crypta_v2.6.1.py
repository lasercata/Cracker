#!/bin/python3
# -*- coding: utf-8 -*-
"""Crypta is a cryptology program including cryptography and cryptanalysis fonctions."""

auth = 'Elerias'
date = '25.02.2020'
version = '2.6.1' # stable


##-import

try:
    from modules.prima import prima
    from modules.base.matrix import *
    from modules.base.color import color, cl_out, cl_inp, c_succes, c_output, c_wrdlt, c_error, c_prog, c_ascii
    from modules.base.base_functions import use_menu, inp_lst, inp_int
except:
    pass


##-base functions

def inverse(a, n):
    """Return the inverse of a in base n."""

    n2 = n
    rest = a % n2
    aq = 1
    au = 1
    av = 0
    u = 0
    v = 1
    while rest > 1:
        rest = a % n2
        q = (a-rest) // n2
        nu = au - q*u
        nv = av - q*v
        aq = q
        au = u
        av = v
        u = nu
        v = nv
        a = n2
        n2 = rest
    inverse = (u+n) % n
    return inverse


def msgform(M, f, space=False, number=False):
    """Delete the special characters."""

    spe = 'àâäãèêëéìîïòôöõùûüÿçñ'
    nor = 'aaaaeeeeiiioooouuuycn'
    aut = ""
    Mf = ""
    for k in range(len(spe)):
        M = M.replace(spe[k], nor[k])
    if f == 'maj':
        M = M.upper()
        aut = aut + 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    else:
        M = M.lower()
        aut = aut + 'abcdefghijklmnopqrstuvwxyz'
    if number:
        aut = aut + '0123456789'
    if space:
        aut = aut + ' '
    for k in range(len(M)):
        if M[k] in aut:
            Mf = Mf + M[k]
    return Mf

def read_lines(T):
    """Return the text issue of the reading in lines of the list of list T."""
    text = ""
    for k in T:
        text = text + "".join(k)
    return text

def read_columns(T):
    """Return the text issue of the reading in columns of the list of list T."""
    text = ""
    for i in range(len(T[0])):
        for j in range(len(T)):
            if len(T[j]) > i:
                text = text + T[j][i]
    return text

def write_lines_c(text, nc):
    """Return the list of the list T issue of the writing in lines of the text in nc columns."""
    T = [[]]
    i = 0
    for k in range(len(text)):
        T[i].append(text[k])
        if k % nc == nc - 1:
            i = i + 1
            T.append([])
    return T

def write_columns_c(text, nc):
    """Return the list of the list T issue of the writing in columns of the text in nc columns."""
    T = []
    nl = len(text) // nc
    r = 0
    if len(text) % nc != 0:
        nl = nl + 1
        r = len(text) % nc
    for k in range(nl):
        T.append([])
    i = 0
    for k in range(len(text)):
        T[i].append(text[k])
        i = (i+1) % nl
        if i == nl - 1 and len(T[i]) == r:
            i = 0
    return T

def generate_alphabet_word(word, alph='abcdefghijklmnopqrstuvwxyz'):
    """Return the cipher alphabet generated with a word key."""
    cipher_alph = ""
    for k in word:
        if k in alph:
            i = alph.index(k)
            alph = alph[0:i] + alph[i + 1:len(alph)]
            cipher_alph = cipher_alph + k
    cipher_alph = cipher_alph + alph
    return cipher_alph

def word_to_transposition_key(word, alph='abcdefghijklmnopqrstuvwxyz'):
    """Return a transposition key generated with a word key."""
    L = []
    for k in range(len(word)):
        i = alph.index(word[k])
        L.append((i, k))
    L.sort()
    Tk = []
    for k in L:
        Tk.append(k[1])
    return Tk

def read_file(f):
    """Return the text read of a file f after deleting of the \n."""
    a = open(f, 'r')
    t = a.read()
    t = t.split('\n')
    t = ' '.join(t)
    a.close()
    return t

def read_file_use():
    """Use read_file."""
    f = cl_inp('Name of the file to read : ')
    try:
        return read_file(f)
    except FileNotFoundError:
        cl_out(c_error, 'The file was NOT found !!!')
        return read_file_use()

def write_file(f, t):
    """Write in a file f the text t."""
    a = open(f, 'a')
    if type(t) == list:
        t = '\n'.join(t)
    a.write(t)
    a.close()

def write_file_use(t=""):
    """Use write_file."""
    f = cl_inp('Name of the file to write the data : ')
    if t == "":
        t = cl_inp('Text : ')
    write_file(f, t)
    print('Operation successfully realised')

def ask_text():
    """Use write_file or ask the text."""
    f = inp_lst('Read text from file ? (y/n) : ', ('y', 'yes', 'Y', 'YES', 'o', 'O', 'oui', 'OUI', 'n', 'no', 'non', 'Non', 'No'))
    if f in ('y', 'yes', 'Y', 'YES', 'o', 'O', 'oui', 'OUI'):
        t = read_file_use()
    else:
        t = cl_inp('Enter the text :\n')
    return t

def give_result(res):
    """Use write_file or print the result."""
    r = cl_inp('Write the result in a file ? (y/n) : ')
    if r in ('y', 'yes', 'Y', 'YES', 'o', 'O', 'oui', 'OUI'):
        write_file_use(res)
    else:
        print('Result :\n')
        print(res)


##-ciphers

class morse:

    def morse(text, mode):
        if mode == 0:
            return morse.encode(text)
        else:
            return morse.decode(text)

    def encode(text):
        d = {'a': '.-', 'b': '-...', 'c': '-.-.', 'd': '-..', 'e': '.', 'f': '..-.', 'g': '--.', 'h': '....', 'i': '..', 'j': '.---', 'k': '-.-', 'l': '.-..', 'm': '--', 'n': '-.', 'o': '---', 'p': '.--.', 'q': '--.-', 'r': '.-.', 's': '...', 't': '-', 'u': '..-', 'v': '...-', 'w': '.--', 'x': '-..-', 'y': '-.--', 'z': '--..', '1': '.----', '2': '..---', '3': '...--', '4': '....-', '5': '.....', '6': '-....', '7': '--...', '8': '---..', '9': '----.', '0': '-----'}
        alf_spe = "àåâæáāăãäąçćčďđėéęèěêĕëəēģğíıìįïīîķłľļĺňņńñőóøòöœõôŕřß§śšşþťțţųüűúůùūûýźżž"
        alf_nor = "aaaaaaaaaacccddeeeeeeeeeeggiiiiiiikllllnnnnoooooooorrsssssttttuuuuuuuuyzzz"
        text = text.lower()
        res = ""
        for k in text:
            if k in alf_spe:
                res += d[alf_nor[alf_spe.index(k)]] + ' '
            elif k in d:
                res += d[k] + ' '
            elif k == ' ':
                res += '/ '
        return res

    def decode(text, a='.', b='-', sep_l=' ', sep_w='/'):
        d = {a+b: 'a', b+a+a+a: 'b', b+a+b+a: 'c', b+a+a: 'd', a: 'e', a+a+b+a: 'f', b+b+a: 'g', a+a+a+a: 'h', a+a: 'i', a+b+b+b: 'j', b+a+b: 'k', a+b+a+a: 'l', b+b: 'm', b+a: 'n', b+b+b: 'o', a+b+b+a: 'p', b+b+a+b: 'q', a+b+a: 'r', a+a+a: 's', b: 't', a+a+b: 'u', a+a+a+b: 'v', a+b+b: 'w', b+a+a+b: 'x', b+a+b+b: 'y', b+b+a+a: 'z', a+b+b+b+b: '1', a+a+b+b+b: '2', a+a+a+b+b: '3', a+a+a+a+b: '4', a+a+a+a+a: '5', b+a+a+a+a: '6', b+b+a+a+a: '7', b+b+b+a+a: '8', b+b+b+b+a: '9', b+b+b+b+b: '0', sep_w: ' '}
        T = text.split(sep_l)
        res = ""
        for k in T:
            if k in d:
                res += d[k]
        return res

    def use():
        print("\nMorse code")
        t = ask_text()
        res = morse.encode(t)
        give_result(res)


class reverse_code:

    def reverse_code(text):
        L = list(text)
        L.reverse()
        return "".join(L)

    def use():
        print("\nReverse code")
        text = ask_text()
        res = reverse_code.reverse_code(text)
        give_result(res)


class scytale:
    """Class using scytale cipher."""

    def scytale(text, key, mode=0):
        key = int(key)
        if mode == 0:
            T = write_lines_c(text, key)
            return read_columns(T)
        else:
            T = write_columns_c(text, key)
            return read_lines(T)

    def encrypt(text, key):
        return scytale.scytale(text, key, 0)

    def decrypt(text, key):
        return scytale.scytale(text, key, 1)

    def use():
        print('\nScytale cipher')
        mode = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        text = ask_text()
        key = inp_int('Key :')
        res = scytale.scytale(text, key, mode)
        give_result(res)


class columnar_transposition:
    """Class using columnar transposition cipher."""

    def columnar_transposition(text, key, mode=0):
        if type(key) == str:
            key = word_to_transposition_key(key)
        nc = len(key)
        nl = int(len(text)//nc)
        r = len(text) % nc
        if mode == 0:
            T = write_lines_c(text, nc)
            c = ""
            for k in range(nc):
                i = key.index(k)
                for l in T:
                    if len(l) > i:
                        c = c + l[i]
            return c
        else:
            T = []
            nl2 = nl
            if r != 0:
                nl2 = nl + 1
            for k in range(nl2):
                if k == nl2 - 1:
                    if r != 0:
                        T.append([])
                else:
                    T.append([""] * nc)
            for i in range(nc):
                j = key.index(i)
                for k in range(nl2):
                    if not k == nl2 - 1:
                        T[k][j] = text[0]
                        text = text[1:len(text)]
                    else:
                        if j < r:
                            T[k].append(text[0])
                            text = text[1:len(text)]

            clairtext = read_lines(T)
            return clairtext

    def encrypt(text, key, alph='abcdefghijklmnopqrstuvwxyz'):
        columnar_transposition.columnar_transposition(text, key, 0, alph)

    def decrypt(text, key, alph='abcdefghijklmnopqrstuvwxyz'):
        columnar_transposition.columnar_transposition(text, key, 1, alph)

    def use():
        print('\nColumnar transposition cipher')
        mode = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        text = ask_text()
        key = int(cl_inp('Key : '))
        res = columnar_transposition.columnar_transposition(text, key, mode)
        give_result(res)


class rail_fence:
    """Class using Rail Fence cipher."""

    def rail_fence(text, key, mode=0, alph='abcdefghijklmnopqrstuvwxyz'):
        key = int(key)
        L = []
        for k in range(key):
            L.append([])            # We create a list of the levels
        if mode == 0:
            lev = 0
            m = 1                       # m is the step
            for k in text:
                L[lev].append(k)
                if lev == key - 1:
                    m = - 1
                elif lev == 0:
                    m = 1
                lev = lev + m
            res = ""
            for k in L:
                res += "".join(k)
            return res
        else:
            lt = len(text)
            ttest = 'X' * lt
            lev = 0
            m = 1                       # m is the step
            for k in ttest:
                L[lev].append(k)
                if lev == key - 1:
                    m = - 1
                elif lev == 0:
                    m = 1
                lev = lev + m
            n = 0
            for i in L:
                for j in range(len(i)):
                    i[j] = text[n]
                    n = n + 1
            res = ""
            lev = 0
            m = 1
            while len(res) != lt:
                if lev >= len(L) or lev < 0:
                    m = 0 - m
                    lev = lev + m + m
                if len(L[lev]) != 0:
                    res += L[lev][0]
                    L[lev] = L[lev][1:len(L[lev])]
                lev = lev + m
            return res

    def use():
        print('\nRail fence cipher')
        t = ask_text()
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        key = int(cl_inp("Key : "))
        res = rail_fence.rail_fence(t, key, mode)
        give_result(res)


class atbash:
    """Class using Atbash cipher."""

    def atbash(M, alf='abcdefghijklmnopqrstuvwxyz'):
        alf2 = "".join(reversed(alf))
        C = ""
        for k in M:
            C += alf2[alf.index(k)]
        return C

    def use():
        print('\nAtbash cipher')
        alf = cl_inp('Alphabet (let empty to use normal) :')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        t = ask_text()
        res = atbash.atbash(t, alf)
        give_result(res)


class caesar:
    """Class using Caesar cipher."""

    def caesar(M, key, mode=0, alf='abcdefghijklmnopqrstuvwxyz'):
        if type(key) == str:
            if not (key[0] in "0123456789"):
                key = alf.index(key)
            else:
                key = int(key)
        lalf = len(alf)
        C = ""
        if mode == 1:
            key = lalf - key
        for k in M:
            C += alf[(alf.index(k) + key) % lalf]
        return C

    def encrypt(M, key, alf='abcdefghijklmnopqrstuvwxyz'):
        return caesar.caesar(M, key, 0, alf)

    def decrypt(M, key, alf='abcdefghijklmnopqrstuvwxyz'):
        return caesar.caesar(M, key, 1, alf)

    def use():
        print('\nCaesar cipher')
        alf = cl_inp('Alphabet (let empty to use normal) :')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        t = ask_text()
        k = int(cl_inp('Key : '))
        res = caesar.caesar(t, k, m, alf)
        give_result(res)


class affine:
    """Class using affine cipher."""

    def affine(M, keya, keyb, mode=0, alf='abcdefghijklmnopqrstuvwxyz'):
        keya = int(keya)
        keyb = int(keyb)
        C = ""
        lalf = len(alf)
        if mode == 1:
            keya = inverse(keya, lalf)
            for k in M:
                C += alf[((alf.index(k) - keyb) * keya) % lalf]
        else:
            for k in M:
                C += alf[(alf.index(k) * keya + keyb) % lalf]
        return C

    def encrypt(M, keya, keyb, alf='abcdefghijklmnopqrstuvwxyz'):
        return affine.affine(M, keya, keyb, 0, alf)

    def decrypt(M, keya, keyb, alf='abcdefghijklmnopqrstuvwxyz'):
        return affine.affine(M, keya, keyb, 1, alf)

    def use():
        print('\nAffine cipher')
        alf = cl_inp('Alphabet (let empty to use normal) :')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        t = ask_text()
        a = int(cl_inp('Key a : '))
        b = int(cl_inp('Key b : '))
        res = affine.affine(t, a, b, m, alf)
        give_result(res)


class vigenere:
    """Class using Vigenere cipher."""

    def vigenere(M, key, mode, alf='abcdefghijklmnopqrstuvwxyz'):
        lalf = len(alf)
        lm = len(M)
        lkey = len(key)
        key = key * int(lm / lm + 2)
        C = ""
        if mode == 1:
            for k in range(lm):
                C += alf[(alf.index(M[k]) - alf.index(key[k % lkey]) + lalf) % lalf]
        else :
            for k in range(lm):
                C += alf[(alf.index(M[k]) + alf.index(key[k % lkey])) % lalf]
        return C

    def encrypt(M, key, alf='abcdefghijklmnopqrstuvwxyz'):
        return vigenere.vigenere(M, key, 0, alf)

    def decrypt(M, key, alf='abcdefghijklmnopqrstuvwxyz'):
        return vigenere.vigenere(M, key, 1, alf)

    def use():
        print('\nVigenere cipher')
        alf = cl_inp('Alphabet (let empty to use normal) :')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        t = ask_text()
        k = cl_inp('Key : ')
        res = vigenere.vigenere(t, k, m, alf)
        give_result(res)


class monosub:
    """Class using monoalphabetic substitution cipher."""

    def monosub(M, key, mode=0, alf='abcdefghijkmnopqrstuvwxyz'):
        alfcrypt = generate_alphabet_word(key, alf)
        if mode == 1:
            alf, alfcrypt = alfcrypt, alf
        lalf = len(alf)
        if len(alfcrypt) != lalf:
            return 0
        C = ""
        for k in M :
            C += alfcrypt[alf.index(k)]
        return C

    def encrypt(M, key, alf='abcdefghijkmnopqrstuvwxyz'):
        monosub.monosub(M, key, 0, alf)

    def decrypt(M, key, alf='abcdefghijkmnopqrstuvwxyz'):
        monosub.monosub(M, key, 1, alf)

    def use():
        print('\nMonoalphabetic substitution cipher')
        alf = cl_inp('Plaintext alphabet (let empty to use normal) : ')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        t = ask_text()
        k = cl_inp('Ciphertext alphabet or word : ')
        res = monosub.monosub(t, k, m, alf)
        give_result(res)


class freqana:
    """Class using frequency analysis."""

    def freqana(M, wprocess=False):
        if wprocess:
            M = msgform(M, 'min')
        D = {}
        for k in M:
            if k in D:
                D[k] += 1
            else:
                D[k] = 1
        L = sorted(D.items(), key=lambda t: t[1])
        L.reverse()
        return L, len(M)

    def use():
        print('\nFrequency analysis')
        t = ask_text()
        p = inp_lst('Word processing (y/n) ? ', ('yes', 'y', 'oui', 'o', 'Yes', 'Oui', 'n', 'no', 'non', 'Non', 'No'))
        if p in ('yes', 'y', 'oui', 'o', 'Yes', 'Oui'):
            p = True
        else:
            p = False
        L, lt = freqana.freqana(t, p)
        # Processing of list
        res = ""
        for k in L:
            res += str(k[0]) + ' : ' + str(k[1]) + ' --> ' + str(round(k[1] / lt, 4) * 100) + ' %\n'
        res += '\n' + str(lt) + ' characters analyzed'
        give_result(res)


class ic:
    """Class using index of coincidence."""

    def ic(M, wprocess=False):
        if wprocess:
            M = msgform(M, 'min')
        D = {}
        for k in M:
            if k in D:
                D[k] += 1
            else:
                D[k] = 1
        ic = 0
        for k in D:
            n = D[k]
            ic += n * (n-1)
        lm = len(M)
        return ic / (lm * (lm-1))

    def use():
        print('\nIndex of coincidence')
        t = ask_text()
        p = inp_lst('Word processing (y/n) ? ', ('yes', 'y', 'oui', 'o', 'Yes', 'Oui', 'n', 'no', 'non', 'Non', 'No'))
        if p in ('yes', 'y', 'oui', 'o', 'Yes', 'Oui'):
            p = True
        else:
            p = False
        res = ic.ic(t, p)
        give_result(res)


class kasiki:
    """Class using Kasiki examination."""

    def kasiki(M, p):
        if p:
            M = msgform(M, 'maj', False, True)
        lm = len(M)
        L_tri = {}
        L_quad = {}
        L_rep = {}
        for k in range(lm):
            if k <= lm - 3:
                tri = M[k:k + 3]
                if tri in L_tri:
                    d = k - L_tri[tri]
                    L_rep[tri] = (L_tri[tri] + 1, k + 1, d, prima.decomposition_divisions_successives(d))
                else:
                    L_tri[tri] = k
                if k <= lm - 4:
                    quad = tri + M[k + 3]
                    if quad in L_quad:
                        d = k - L_quad[quad]
                        L_rep[quad] = (L_quad[quad] + 1, k + 1 , d, prima.decomposition_divisions_successives(d))
                    else :
                        L_quad[quad] = k
        return L_rep

    def use():
        print('\nKasiki examination')
        t = ask_text()
        p = inp_lst('Word processing (y/n) ? ', ('yes', 'y', 'oui', 'o', 'Yes', 'Oui', 'n', 'no', 'non', 'Non', 'No'))
        if p in ('yes', 'y', 'oui', 'o', 'Yes', 'Oui'):
            p = True
        else:
            p = False
        d = kasiki.kasiki(t, p)
        res = "\n"
        for i in d:
            L = d[i]
            p = str(i) + ' : '
            for j in range(len(L) - 2):
                p = p + str(L[j])
                if j < len(L) - 3:
                    p = p + '-'
                elif j == len(L) - 3:
                    p = p + ' --> ' + str(L[j])
            res = res + p + ' --> ' + str(L[-1][1]) + '\n'


class hill:
    """Class using Hill cipher."""

    def hill(M, text, mode, alphabet='abcdefghijklmnopqrstuvwxyz') :
        """Return the encryption of the text with the square matrix M."""

        if type(M) != Matrix:
            M = Matrix(M)
        la = len(alphabet)
        if mode == 1 :
            M = M.inverse(la)
        dimension = len(M[0])
        text = text + 'x' * ((dimension - len(text) % dimension) % dimension)
        text_c = ""
        for k in range(len(text) // dimension):
            C = []    # column vector
            for l in text[k * dimension:k * (dimension+1)]:
                C.append([alphabet.index(l)])
            C2 = Matrix(C)
            C2 = M * C2
            C2 = C2 % la
            for l in C2 :
                text_c = text_c + alphabet[int(l[0])]
        return text_c

    def encrypt(M, text, alf='abcdefghijklmnopqrstuvwxyz'):
        return hill(M, text, 0, alf)

    def decrypt(M, text, alf='abcdefghijklmnopqrstuvwxyz'):
        return hill(M, text, 0, alf)

    def use():
        print('\nHill cipher')
        alf = cl_inp('Alphabet (let empty to use normal) :')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        t = ask_text()
        tM = inp_int("Dimension of the sqare matrix :")
        M = []
        for k in range(tM):
            L = []
            for l in range(tM):
                t = cl_inp('Line ' + str(k + 1) + ' column ' + str(l + 1) + ' : ')
                L.append(int(t))
            M.append(L)
        print(M)
        M = Matrix(M)
        print(M)
        res = hill.hill(M, t, m, alf)
        give_result(res)


def textana():
    """Return the analysis of the text."""

    print('\nText analysis')
    t = ask_text()
    p = inp_lst('Word processing (y/n) ? ', ('yes', 'y', 'oui', 'o', 'Yes', 'Oui', 'n', 'no', 'non', 'Non', 'No'))
    if p in ('yes', 'y', 'oui', 'o', 'Yes', 'Oui'):
        p = True
    else:
        p = False
    res = '\nFrequence analysis\n'
    L, lt = freqana.freqana(t, p)
    # Processing of list
    for k in L:
        res += str(k[0]) + ' : ' + str(k[1]) + ' --> ' + str(round(k[1] / lt, 2)) + ' %' + '\n'
    res += str(lt) + ' characters analyzed'
    res += '\nIndex of coincidence : ' + str(round(ic.ic(t, p), 4))
    res += '\nKasiki examination\n\n'
    d = kasiki.kasiki(t, p)
    for i in d:
        L = d[i]
        p = str(i) + ' : '
        for j in range(len(L) - 2):
            p = p + str(L[j])
            if j < len(L) - 3:
                p = p + '-'
            elif j == len(L) - 3:
                    p = p + ' --> ' + str(L[j])
        res = res + p + ' --> ' + str(L[-1][1]) + '\n'
    res += '\nEnd of the analysis'
    give_result(res)


##-using

def use():
    """Use crypta fonctions"""

    d = {'1': textana, '1a': freqana.use, '1b': ic.use, '1c': kasiki.use, '2': morse.use, '3': atbash.use, '4': caesar.use, '5': affine.use, '6': monosub.use, '7': vigenere.use, '8': hill.use, '9': reverse_code.use, '10': rail_fence.use, '11': scytale.use, '12': columnar_transposition.use}
    c = ""
    while c not in ('0', 'q'):

        color(c_succes)
        print("")
        print('\\'*50)

        color(c_prog)
        print('\nCrypta menu :\n')

        color(c_error)
        print('    0.Main menu')

        color(c_succes)
        print('    ' + '-'*16)
        color(c_ascii)

        print('    1.Text analysis')
        print('    1a.Frequence analysis')
        print('    1b.Index of coincidence')
        print('    1c.Kasiki examination')
        color(c_succes)
        print('    ' + '-'*16)
        color(c_ascii)
        print('    2.Morse code')
        color(c_succes)
        print('    ' + '-'*16)
        print('    3.Atbash cipher')
        print('    4.Caesar cipher')
        print('    5.Affine ciper')
        print('    6.Monoalphabetic substitution cipher')
        print('    7.Vigenere cipher')
        print('    8.Hill cipher')
        print('    9 .Reverse code')
        print('    10.Rail fence cipher')
        print('    11.Scytale cipher')
        print('    12.Columnar transposition cipher')
        color(c_prog)

        c = ""
        c = cl_inp('Your Choice :')

        if c not in d and c not in ('q', '0'):
            prnt = c + ' is NOT an option of this menu !'
            cl_out(c_error, prnt)
        elif c not in ('q', '0'):
            use_menu(d[c])
            color(c_succes)
            cl_inp('---End---')
            color(c_prog)