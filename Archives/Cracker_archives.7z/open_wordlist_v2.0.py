#!/bin/python3
# -*- coding: utf-8 -*-
'''Module incuding open_w function'''

auth = 'Lasercata'
date = '06.02.2020'
version = '2.0'

##-import
#from os import chdir
#chdir('../..')

from datetime import datetime

from modules.base.console.color import color, cl_inp, cl_out, c_error, c_wrdlt, c_output, c_prog, c_succes
from modules.password_testor.pwd_testor import walf, wlth
from modules.b_cvrt.b_cvrt import space
from modules.base.base_functions import set_prompt, inp_lst

##-open
def open_w(file_name):
    try:
        f = open(file_name)

    except FileNotFoundError:
        cl_out(c_error, 'No file of this name !!! \nBack menu ...')

    else:
        f.close()

        t1 = datetime.now()

        with open(file_name, 'r') as wordlist_f:
            lines = wordlist_f.readlines()
            lth = len(lines)

        with open(file_name, 'r') as wordlist_f:
            print('\nReading ...')

            rep = 0

            wordlist_c = []
            l_rep = []
            for word in wordlist_f.readlines():
                word = word.strip('\n')

                wordlist_c.append(word)

                rep += 1
                rep50 = round(rep / lth * 50)

                if rep50 not in l_rep:
                    l_rep.append(rep50)

                    color(c_wrdlt)
                    if rep > 1:
                        print('\b'*52, end='')
                    print('|' + '#'*rep50 + ' '*(50-rep50) + '|', end='')
                    color(c_prog)


        print('\n\nSearching the alphabets...')

        wordlist_content = ''
        for word in wordlist_c:
            wordlist_content += word + '\n'

        l_wordlist_c = len(wordlist_c)
        len_line = len(wordlist_c[0])

        #alphabets
        alfs_ = walf(wordlist_c, string=True)#list of the alphabets
        alf_lth = walf(wordlist_c) #lenth of the alphabets

        #list of the differents characters
        lst_chr = list(wlth(wordlist_content))
        lst_chr.remove('\n')
        char = set_prompt(lst_chr)

        #number of differents chararters
        lth_chr = len(lst_chr)

        #calc the time duration
        t2 = datetime.now()
        t_dif = t2 - t1
        cl_out(c_succes, 'Opened in ' + str(t_dif) + ' second(s)')


        color(c_output)

        prnt = '\nLenth of the words : ' + str(len_line) + ' ;\nLenth of the alphabet : ' + space(alf_lth)
        prnt += ' ;\nLenth of the wordlist : ' + space(l_wordlist_c) + ' lines ;' + '\n\nAlphabets : ' + alfs_ + ' ;'
        prnt += '\n\nNumber of differents characters : ' + space(lth_chr) + ' ;\nList of all the presents characters :\n '
        prnt += str(char)
        print(prnt)

        choice = inp_lst('Print the content ? (y/n)', ('y', 'n'))

        if choice == 'y':
            cl_out(c_wrdlt, wordlist_content)
            cl_out(c_output, prnt + '\n')

        else:
            print('\nBack menu ...')

        color(c_prog)


def use_open_w():
    try:
        file_name = cl_inp('Enter the wordlist\'s name :')
        wordlist_f = open(file_name, 'r')

    except FileNotFoundError:
        cl_out(c_error, 'No file of this name !!! \nBack menu ...')

    else:
        wordlist_f.close()
        open_w(file_name)


##-test module
if __name__ == '__main__':
    use_open_w()
