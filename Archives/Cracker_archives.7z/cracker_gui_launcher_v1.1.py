"""Launch Cracker with tkinter interface."""

auth = 'Elerias'
date = '01.05.2020'
version = '1.1'


##-import

from tkinter import *
from tkinter import ttk
from os import getcwd
from os import chdir
from hashlib import sha256
from time import time

from modules.hash import hasher
from modules.wordlists import wordlist_generator
from modules.passwords import pass_test
from modules.b_cvrt.b_cvrt_gui import Window_b_cvrt
from modules.prima.prima import *
from modules.crypta.crypta import *

cracker = """\n\n
 _______  ______ _______ _______ _     _ _______  ______
 |            |_____/ |_____| |            |____/  |______ |_____/
 |_____    |       \_|       |  |_____    |       \_ |______ |       \_\n\n\n\n"""


##-functions

def change_cur_dir():
    global var_cur_dir
    cur_dir = var_cur_dir.get()
    try:
        chdir(cur_dir)
    except:
        var_cur_dir.set(getcwd())
        return False
    var_cur_dir.set(getcwd())

def open_w(file_name) :
    try :
        wordlist_f = open(file_name, 'r')
    except FileNotFoundError :
        return "Error", 0, 0, file_name
    line = wordlist_f.readline()
    line = line.strip('\n')
    len_line = len(line)
    wordlist_content = wordlist_f.read()
    wordlist_c = wordlist_content.split('\n')
    l_wordlist_c = len(wordlist_c)
    wordlist_f.close()

    return "Found", l_wordlist_c, len_line, file_name


##-menus

def del_last_menu():
    global main_f, menu, b_menu_hasher, b_menu_wordlist, b_menu_pwd_testor, b_menu_b_cvrt, b_menu_prima, b_menu_crypta
    main_f.destroy()
    main_f = Frame(w)
    main_f.grid(column=0, row=1, sticky='w')
    L = (b_menu_hasher, b_menu_wordlist, b_menu_pwd_testor, b_menu_b_cvrt, b_menu_prima, b_menu_crypta)
    for k in L:
        k['relief'] = 'raised'


class hasher_gui:

    def menu():
        global main_f, menu, b_menu_hasher, l_com, var_type_hash, var_text, var_file, wid_t_hash, var_wrdlst
        del_last_menu()
        menu = 'hasher'
        b_menu_hasher['relief'] = 'sunken'
        Label(main_f, text="\nHash tools\n").grid(column=1, row=0)
        Label(main_f, text="Type of hash :").grid(column=0, row=1, sticky='w')
        Label(main_f, text="Text :").grid(column=0, row=2, sticky='w')
        Label(main_f, text="File to hash :").grid(column=0, row=3, sticky='w')
        Label(main_f, text="Digest :").grid(column=0, row=4, sticky='w')
        Label(main_f, text="Wordlist :").grid(column=0, row=5, sticky='w')
        var_type_hash = StringVar()
        OptionMenu(main_f, var_type_hash, "md5", "sha1", "sha224", "sha256", "sha384", "sha512", "sha3_224", "sha3_256", "sha3_384", "sha3_512", "blake2b", "blake2s", "shake_128", "shake_256").grid(column=1, row=1, sticky="w")
        var_type_hash.set("md5")
        var_text = StringVar()
        Entry(main_f, textvariable=var_text, width=66).grid(column=1, row=2, sticky='w')
        var_file = StringVar()
        Entry(main_f, textvariable=var_file, width=66).grid(column=1, row=3, sticky='w')
        wid_t_hash = Text(main_f, width=66, height=2)
        wid_t_hash.grid(column=1, row=4, sticky='w')
        wid_t_hash['font'] = 'TkTextFont'
        var_wrdlst = StringVar()
        Entry(main_f, textvariable=var_wrdlst, width=66).grid(column=1, row=5, sticky='w')
        Button(main_f, text="Hash", command=hasher_gui.hash_).grid(column=2, row=3, sticky='w')
        Button(main_f, text="Crack hash", command=hasher_gui.crack_hash).grid(column=2, row=4, sticky='w')
        Button(main_f, text="Crack hash with a wordlist", command=hasher_gui.crack_hash_wrdlst).grid(column=2, row=5, sticky='w')
        l_com = Label(main_f, text="\n") # Communication label
        l_com.grid(column=1, row=6)

    def hash_():
        global main_f, l_com, var_type_hash, var_text, var_file, wid_t_hash
        l_com['text'] = "\n"
        if var_file.get() == "":
            wid_t_hash.delete('0.0', '2.0')
            wid_t_hash.insert('0.0', hasher.hasher(var_type_hash.get(), var_text.get()))
        else:
            try:
                a = open(var_file.get(), 'r')
            except:
                l_com['text'] = "File not found\n"
                l_com['fg'] = 'red'
                return 0
            var_hash.set(hasher.hasher(var_type_hash.get(), a.read()))
            a.close()

    def crack_hash_wrdlst():
        global main_f, l_com, var_type_hash, var_text, wid_t_hash, var_wrdlst
        l_com['text'] = "\n"
        type_hash = var_type_hash.get()
        h = wid_t_hash.get('0.0', '2.0')[0:-1]
        try:
            a = open(var_wrdlst.get(), 'r')
        except:
            l_com['text'] = "File not found\n"
            l_com['fg'] = 'red'
            return 0
        found = False
        word = a.readline()
        found = hasher.hasher(type_hash, word) == h
        while word != "" and not(found):
            word = a.readline()[0:-1]
            found = hasher.hasher(type_hash, word) == h
        if found:
            l_com['text'] = "Preimage found\n"
            l_com['fg'] = 'green'
            var_text.set(word)
        else:
            l_com['text'] = "Preimage not found\n"
            l_com['fg'] = 'red'

    def crack_hash():
        global main_f, l_com, var_type_hash, var_text, var_hash, var_wrdlst
        # To do with crack_function


class wordlist_gui:

    def menu():
        global main_f, menu, b_menu_wordlist, l_com, var_length, var_alph, var_name_file
        del_last_menu()
        menu = 'wordlist'
        b_menu_wordlist['relief'] = 'sunken'
        Label(main_f, text="\nWordlists\n").grid(column=1, row=0)
        Label(main_f, text="Name of the file :").grid(column=0, row=1, sticky='w')
        Label(main_f, text="Alphabet :").grid(column=0, row=2, sticky='w')
        Label(main_f, text="Length :").grid(column=0, row=3, sticky='w')
        var_name_file = StringVar()
        Entry(main_f, textvariable=var_name_file).grid(column=1, row=1, sticky='w')
        var_alph = StringVar()
        ttk.Combobox(main_f, textvariable=var_alph, values=["a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z",
        "0,1,2,3,4,5,6,7,8,9",
        "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z",
        "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,0,1,2,3,4,5,6,7,8,9",
        "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,0,1,2,3,4,5,6,7,8,9",
        "a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,0,1,2,3,4,5,6,7,8,9"], width=50).grid(column=1, row=2, sticky='w')
        var_length = IntVar()
        Spinbox(main_f, from_=1, to=20, increment=1, textvariable=var_length, width=2).grid(column=1, row=3, sticky="w")
        Button(main_f, text="Generate", command=wordlist_gui.generate).grid(column=1, row=4, sticky='w')
        Button(main_f, text="Analyze", command=wordlist_gui.analyze).grid(column=2, row=1, sticky='w')
        l_com = Label(main_f, text="\n")
        l_com.grid(column=1, row=5, sticky='w')

    def generate():
        global main_f, var_alph, var_length, var_name_file, l_com
        l_com['text'] = "\n"
        alph = var_alph.get()
        alph = alph.split(",")
        length = var_length.get()
        name_file = var_name_file.get()
        wordlist_generator.wordlist_generator_6(alph, length, length, name_file, "")
        l_com['text'] = "File successfully created"
        l_com['fg'] = 'green'

    def analyze():
        global main_f, var_name_file, l_com, var_length
        l_com['text'] = "\n"
        name_file = var_name_file.get()
        r, nl, ll, nf = open_w(name_file)
        if r == "Error" :
            l_com['text'] = 'File not found\n'
            l_com['fg'] = 'red'
        else :
            l_com['text'] = 'File successfully analyzed\nNumber of lines : ' + str(nl)
            l_com['fg'] = 'green'
            var_length.set(ll)


class pwd_testor_gui:

    def menu():
        global main_f, menu,  b_menu_pwd_testor, var_password, l_com
        del_last_menu()
        menu = 'pwd_testor'
        b_menu_pwd_testor['relief'] = 'sunken'
        Label(main_f, text="\nPassword testor\n").grid(column=1, row=0)
        Label(main_f, text="Password :").grid(column=0, row=1)
        var_password = StringVar()
        Entry(main_f, textvariable=var_password, width=20).grid(column=1, row=1, sticky='w')
        Button(main_f, text="Test", command=pwd_testor_gui.test).grid(column=2, row=1, sticky='w')
        l_com = Label(main_f, text="\n")
        l_com.grid(column=1, row=2, sticky='w')

    def test():
        global main_f, var_password, l_com
        password = var_password.get()
        l_com['text'] = pass_test.get_sth(password)


class b_cvrt_gui:

    def menu():
        global main_f, menu, b_menu_b_cvrt
        del_last_menu()
        menu = 'b_cvrt'
        b_menu_b_cvrt['relief'] = 'sunken'
        a = Window_b_cvrt(main_f)


class prima_gui:

    def menu():
        global main_f, menu, b_menu_prima, var_algorithm, var_n, l_com
        del_last_menu()
        menu = 'prima'
        b_menu_prima['relief'] = 'sunken'
        Label(main_f, text="\nPrima\n").grid(column=1, row=0)
        Label(main_f, text="Number :").grid(column=0, row=1)
        Label(main_f, text="Algorithm :").grid(column=0, row=2)
        var_n = IntVar()
        Entry(main_f, textvariable=var_n, width=30).grid(column=1, row=1, sticky='w')
        var_algorithm = StringVar()
        OptionMenu(main_f, var_algorithm, "Trial division", "Wheel factorization", "Fermat's factorization", "p - 1", "Pollard's rho", "Miller-Rabin", "Test of Fermat", "Sieve of Erathostenes", "Segmented sieve of Erathostenes").grid(column=1, row=2, sticky='w')
        Button(main_f, text="Calculate", command=prima_gui.calculate).grid(column=1, row=3, sticky='w')
        l_com = Label(main_f, text="\n")
        l_com.grid(column=1, row=4, sticky='w')

    def calculate():
        global main_f, var_algorithm, var_n, l_com
        alg = var_algorithm.get()
        n = var_n.get()
        d = {"Trial division": trial_division, "Wheel factorization": wheel_factorization, "Fermat's factorization": fermat_factorization, "p - 1": pollard_pm1_decomposition, "Pollard's rho": pollard_rho_decomposition,  "Miller-Rabin": miller_rabin, "Test of Fermat": fermat_test, "Sieve of Erathostenes": basic_erathostenes_sieve, "Segmented sieve of Erathostenes": segmentation_erathostenes_sieve}
        f = d[alg]
        t0 = time()
        if alg in ("Trial division", "Wheel factorization", "Fermat's factorization", "p - 1", "Pollard's rho"):
            primality, dec = f(n)
            if primality:
                txt = 'Prime'
            else:
                txt = 'Not prime'
                for k in range(len(dec)):
                    dec[k] = str(dec[k])
                txt = txt + '\n' + str(n) + " = " + " * ".join(dec)
        elif alg in ("Miller-Rabin", "Test of Fermat"):
            if alg == "Miller-Rabin":
                primality = f(n, 10)
            else:
                primality = f(n)
            if primality:
                txt = 'Probably prime'
            else:
                txt = 'Not prime'
        else:
            L = f(n)
            f = open("Prime_numbers_0_" + str(n) + ".txt", 'w')
            for k in L:
                f.write(str(k)+"\n")
            f.close()
            txt = "Saved in Prime_numbers_0_" + str(n) + ".txt" + "\n" + str(len(L)) + " prime numbers"
        t1 = round(time()-t0, 3)
        l_com['text'] = txt + "\n" + str(t1) + " s"


class crypta_gui:

    def menu():
        global main_f, menu, b_menu_crypta, wid_plain_text, wid_result, var_name_file_1, var_algorithm, var_key, var_name_file_2, var_alph, var_word_processing
        del_last_menu()
        menu = 'crypta'
        b_menu_crypta['relief'] = 'sunken'
        Label(main_f, text="\nCrypta\n").grid(column=1, row=0)
        Label(main_f, text="Plain text :").grid(column=0, row=1, sticky='w')
        Label(main_f, text="Plain file :").grid(column=0, row=2, sticky='w')
        Label(main_f, text="Alphabet :").grid(column=0, row=3, sticky='w')
        Label(main_f, text="Algorithm :").grid(column=0, row=4, sticky='w')
        Label(main_f, text="Key :").grid(column=0, row=5, sticky='w')
        Label(main_f, text="Result :").grid(column=0, row=6, sticky='w')
        Label(main_f, text="File :").grid(column=0, row=7, sticky='w')
        wid_plain_text = Text(main_f, height=10, width=50)
        wid_plain_text.grid(column=1, row=1, sticky='w')
        var_name_file_1 = StringVar()
        Entry(main_f, textvariable=var_name_file_1).grid(column=1, row=2, sticky='w')
        var_algorithm = StringVar()
        OptionMenu(main_f, var_algorithm, "Reverse code", "Rail fence", "Columnar transposition", "Scytale", "Atbash", "Caesar", "Affine", "Vigenere", "Monoalphabetic substitution", "Morse code", "Frequence analysis", "Index of coincidence", "Kasiki examination", "Complete analysis", "ADFGX", "ADFGVX").grid(column=1, row=4, sticky='w')
        var_key = StringVar()
        Entry(main_f, textvariable=var_key).grid(column=1, row=5, sticky='w')
        var_alph = StringVar()
        ttk.Combobox(main_f, textvariable=var_alph, values=["abcdefghijklmnopqrstuvwxyz",
        "0123456789",
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
        "abcdefghijklmnopqrstuvwxyz0123456789",
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"],
        width=50).grid(column=1, row=3, sticky='w')
        Button(main_f, text="Encrypt", command=crypta_gui.encrypt).grid(column=2, row=3, sticky='w')
        Button(main_f, text="Decrypt", command=crypta_gui.decrypt).grid(column=2, row=4, sticky='w')
        Button(main_f, text="Analyze", command=crypta_gui.analyze).grid(column=2, row=5, sticky='w')
        Button(main_f, text="Write result in file", command=crypta_gui.write).grid(column=2, row=7, sticky='w')
        wid_result = Text(main_f, height=10, width=50)
        wid_result.grid(column=1, row=6, sticky='w')
        var_name_file_2 = StringVar()
        Entry(main_f, textvariable=var_name_file_2).grid(column=1, row=7, sticky='w')

    def encrypt():
        crypta_gui.execute(0)

    def decrypt():
        crypta_gui.execute(1)

    def analyze():
        crypta_gui.execute(2)

    def execute(mode):
        global main_f, wid_plain_text, wid_result, var_name_file_1, var_algorithm, var_key, var_name_file_2, var_alph
        dico = {"Reverse code": reverse_code.reverse_code, "Rail fence": rail_fence.rail_fence, "Columnar transposition": columnar_transposition.columnar_transposition, "Scytale": scytale.scytale, "Atbash": atbash.atbash, "Caesar": caesar.caesar, "Affine": affine.affine, "Vigenere":vigenere.vigenere, "Monoalphabetic substitution": monosub.monosub, "Morse code": morse.morse, "Frequence analysis": freqana.freqana, "Index of coincidence": ic.ic, "Kasiki examination": kasiki.kasiki, "Complete analysis": freqana.freqana, "ADFGX": ADFGX.ADFGX, "ADFGVX": ADFGVX.ADFGVX}
        alg = var_algorithm.get()
        text_0 = wid_plain_text.get('0.0', END)[0:-1]
        text = ""
        alph = var_alph.get()
        try:
            a = open(var_name_file_1.get(), 'r')
            text_0 = a.read()
            a.close()
            file_ = True
        except:
            file_ = False
        for k in text_0:
            if k in alph:
                text = text + k
            elif k.lower() in alph:
                text = text + k.lower()
        text2 = ""
        key = var_key.get()
        f = dico[alg]
        if alg in ("Reverse code", "Rail fence", "Columnar transposition", "Scytale", "Atbash", "Caesar", "Affine", "Vigenere", "Monoalphabetic substitution", "Morse code", "ADFGX", "ADFGVX"):
            if alg in ("Caesar", "Vigenere", "Monoalphabetic substitution"):
                text2 = f(text, key, mode, alph)
            elif alg == "Affine":
                text2 = f(text, int(key.split(' ')[0]), int(key.split(' ')[1]), mode, alph)
            elif alg in ("Rail fence", "Scytale"):
                text2 = f(text, int(key), mode)
            elif alg == "Columnar transposition":
                text2 = f(text, key, mode)
            elif alg == "Morse code":
                text2 = f(text, mode)
            elif alg in ("ADFGX", "ADFGVX"):
                text2 = f(text, key.split(' ')[0], key.split(' ')[1], mode)
            else:
                text2 = f(text)
        elif alg == "Index of coincidence":
            text2 = str(ic.ic(text, False))
        elif alg == "Frequence analysis":
            L, lt = freqana.freqana(text, False)
            for k in L:
                text2 += str(k[0]) + ' : ' + str(k[1]) + ' --> ' + str(round(k[1] / lt, 4) * 100) + ' %\n'
            text2 += '\n' + str(lt) + ' characters analyzed'
        elif alg == "Kasiki examination":
            d = kasiki.kasiki(text, False)
            text2 = "\n"
            for i in d:
                L = d[i]
                p = str(i) + ' : '
                for j in range(len(L) - 2):
                    p = p + str(L[j])
                    if j < len(L) - 3:
                        p = p + '-'
                    elif j == len(L) - 3:
                        p = p + ' --> ' + str(L[j])
                text2 = text2 + p + ' --> ' + str(L[-1][1]) + '\n'
        elif alg == "Complete analysis":
            L, lt = freqana.freqana(text, False)
            for k in L:
                text2 += str(k[0]) + ' : ' + str(k[1]) + ' --> ' + str(round(k[1] / lt, 4) * 100) + ' %\n'
            text2 += '\n' + str(lt) + ' characters analyzed'
            d = kasiki.kasiki(text, False)
            text2 += '\n' + str(ic.ic(text, False))
            text2 += "\n"
            for i in d:
                L = d[i]
                p = str(i) + ' : '
                for j in range(len(L) - 2):
                    p = p + str(L[j])
                    if j < len(L) - 3:
                        p = p + '-'
                    elif j == len(L) - 3:
                        p = p + ' --> ' + str(L[j])
                text2 = text2 + p + ' --> ' + str(L[-1][1]) + '\n'
        wid_result.delete('0.0', END)
        wid_result.insert('0.0', text2)

    def write():
        global var_name_file_2, wid_result
        a = open(var_name_file_2.get(), 'w')
        a.write(wid_result.get('0.0', END)[0:-1])
        a.close()


##-security

def verification():
    global w, h, autorisation, tries, l_com
    pwd_p = var_pwd_p.get()
    if sha256(pwd_p.encode()).hexdigest() == h:
        w.destroy()
        autorisation = True
    else :
        tries = tries - 1
        l_com['text'] = "Bad password\n" + str(tries) + " remaining tries"
        if tries == 1:
            l_com['fg'] = 'red'
        else:
            l_com['fg'] = 'orange'
        if tries == 0:
            w.destroy()
            autorisation = False


global w, h, autorisation, tries, l_com
autorisation = False
tries = 3
h = '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918'

w = Tk()
w.title('Security')
Label(w, text="Security\n").grid(column=0, row=0)
Label(w, text="Enter the password :").grid(column=0, row=1, sticky='w')

l_com = Label(w, text=str(tries) + " remaining tries\n", fg='green')
l_com.grid(column=0, row=3, sticky='w')

var_pwd_p = StringVar()
Entry(w, textvariable=var_pwd_p, width=25, show='*').grid(column=0, row=2)

b_line = Frame(w)
b_line.grid(column=0, row=4, sticky='e')
Button(b_line, text="Verify",command=verification).grid(column=0, row=0)
Button(b_line, text="Quit", command=w.destroy).grid(column=1, row=0)

w.mainloop()

if not autorisation:
    exit()


##-main

a = open('version.txt')
version_cracker = a.read()

global main_f, menu, b_menu_hasher, b_menu_wordlist, b_menu_pwd_testor, b_menu_b_cvrt, b_menu_prima, b_menu_crypta, var_cur_dir
menu = 'welcome'

w = Tk()
w.title('Cracker v' + version_cracker)
w.resizable(True, True)

path_f = Frame(w)
path_f.grid(column=0, row=0, sticky='w')
label_1 = Label(path_f, text="Current directory :")
label_1.grid(column=0,row=0)
var_cur_dir = StringVar()
var_cur_dir.set(getcwd())
cur_dir_entry = Entry(path_f, textvariable=var_cur_dir, width=70)
cur_dir_entry.grid(column=1, row=0)
b_apply = Button(path_f, text="Apply", command=change_cur_dir)
b_apply.grid(column=2, row=0)
b_quit = Button(path_f, text="Quit", command=w.destroy)
b_quit.grid(column=3, row=0)

main_f = Frame(w)
main_f.grid(column=0, row=1, sticky='w')
title = Label(main_f, text=cracker)
title.grid(column=1, row=1, sticky='w')

b_line = Frame(w)
b_line.grid(column=0, row=10, sticky='w')
b_menu_hasher = Button(b_line, text="Hash tools", command=hasher_gui.menu)
b_menu_hasher.grid(column=0, row=0)
b_menu_wordlist = Button(b_line, text="Wordlists", command=wordlist_gui.menu)
b_menu_wordlist.grid(column=1, row=0)
b_menu_pwd_testor = Button(b_line, text="Password testor", command=pwd_testor_gui.menu)
b_menu_pwd_testor.grid(column=2, row=0)
b_menu_b_cvrt = Button(b_line, text="Base convert", command=b_cvrt_gui.menu)
b_menu_b_cvrt.grid(column=3, row=0)
b_menu_prima = Button(b_line, text="Prima", command=prima_gui.menu)
b_menu_prima.grid(column=4, row=0)
b_menu_crypta = Button(b_line, text="Crypta", command=crypta_gui.menu)
b_menu_crypta.grid(column=5, row=0)

w.mainloop()