auth = 'lasercata'
version = '2.0'
date = '09.02.2020'


##-import
from sys import exit as sysexit
import argparse

try:
    from modules.base.cracker_console_functions import *
    
except ModuleNotFoundError as ept:
    err = str(ept).strip("No module named")

    print('\nPut the module ' + err + ' back !!!')
        
    sysexit()


##-functions
#---------try_int
def try_int(var):
    '''Try int(var)
    Return var (type = int) if possible ;
    Raise a parser error else.'''

    try:
        var = int(var)

    except ValueError as ept:
        raise argparse.ArgumentTypeError(str(ept))

    else:
        return var


#---------open_f
def op_f(filename):
    '''Try to open a file named filename.
    Return file.read() if file exist ;
    Raise a parser error else.'''
    
    try:
        with open(filename) as file_:
            txt = file_.read()

    except FileNotFoundError as err:
       raise argparse.ArgumentTypeError(str(err))

    else:
        return txt


#--------write_f
def write_f(filename, txt, verbose=False): #verbose is not used, but may be in a next version.
    '''Write txt in a file.
    If file exists, append the text ;
    Create it else.'''

    with open(filename, 'a') as f:
        if verbose:
            f.write('\n' + '-'*60 + '===Crackerp' + '\n' + date() + '\n___\n')
            
        f.write(txt)


##-parser
#---------ini
cmd_ = False

info = 'This toolbox application allow you to generate wordlists, hashs, crack hashs, and more !'

examples = '''Examples :

    python3 crackerp.py -hsh -ht md5 -txt test
    python3 crackerp.py -hc -fn w4az -ht md5 -txt 098f6bcd4621d373cade4e832627b4f6

    python3 crackerp.py -w -fn w4az -lth 4 -alf a-z
    python3 crackerp.py -o -fn w4az

    python3 crackerp.py -c -ca -k 3 -m 0 -txt test
    python3 crackerp.py -c -v -k key -m 1 -fn crypted_text -fo uncrypted_text
    
    python3 crackerp.py -p -n 89
    python3 crackerp.py -p -pb 9091
    
    python3 crackerp.py -f -fn filename
    
    python3 crackerp.py -bc -n 5AEF -nb 16 -b 2
    python3 crackerp.py -bc -n 55 -nb 10 -b 2 -ieee754
    
    python3 crackerp.py -pwd -fo pwd_test_for_******.txt

    python3 crackerp.py -i'''


def Cracker_parser():
    global cmd_


    parser = argparse.ArgumentParser(prog='Crackerp2',
                                        description=info,
                                        epilog=examples,
                                        formatter_class=argparse.RawDescriptionHelpFormatter)


    grp_lvl1 = parser.add_mutually_exclusive_group()

    grp_lvl1.add_argument('-hsh', '--hash',
                            help='Hash a string',
                            action='store_true')

    grp_lvl1.add_argument('-hc', '--hash_crack',
                            help='Try to crack a hash (brute force attack)',
                            action='store_true')


    grp_lvl1.add_argument('-w', '--generate_wordlist',
                            help='Generates a wordlist',
                            action='store_true')

    grp_lvl1.add_argument('-o', '--open',
                            help='Open a wordlist and show infos',
                            action='store_true')


    grp_lvl1.add_argument('-c', '--crypta',
                            help='Cryptography and cryptanalysis fonctions',
                            action='store_true')


    grp_lvl1.add_argument('-p', '--prima',
                            help='Deals with prime numbers',
                            action='store_true')


    grp_lvl1.add_argument('-f', '--freq_ana',
                            help='Frequency analysis fonction',
                            action='store_true')


    grp_lvl1.add_argument('-bc', '--base_convert',
                            help='Can convert number from any base, to any base',
                            action='store_true')


    grp_lvl1.add_argument('-pwd', '--pass_test',
                            help='Test your password\'s strenth',
                            action='store_true')


    grp_lvl1.add_argument('-i', '--show_infos',
                            help='Show infos on Cracker',
                            action='store_true')



    parser.add_argument('-ht', '--hash_type',
                        help='The hash\'s type. Should be used with -hsh or -hc option.') #hasher, h_crack

    parser.add_argument('-txt', '--text',
                        help='Some text (word to hash in -hsh, hash to crack in -c)') #hasher, hash_crack, crypta

    parser.add_argument('-fn', '--file_name',
                        help='The file\'s name. Should be used with -w, -hc, -c or -o options.') #wrdlst_gen, h_crack, open_w

    parser.add_argument('-fo', '--file_out',
                        help='The output file\'s name. Should be used with -hsh, -bc, -pwd or -c option.')

    parser.add_argument('-lth', '--lenth',
                        type=int,
                        help='The wordlist\'s words lenth. Should be used with -w option.') #wrdlst_gen

    parser.add_argument('-alf', '--alphabet',
                        help='The alphabet (a-z ; 0-9 ; a-z, 0-9 ; A-Z ; A-Z, 0-9 ; a-z, A-Z ; a-z, A-Z, 0-9 ; 0-1 ; hex (0-9, A-F) ; spe ; all (a-z, A-Z, 0-9, spe) are defined, but you can also write yours). Should be used with -w option.') #wrdlst_gen


    #---------crypta
    grp_crypta = parser.add_mutually_exclusive_group()

    grp_crypta.add_argument('-atb', '--atbash',
                            help='Crypt with atbash cipher. Should be used with --crypta option.',
                            action='store_true')

    grp_crypta.add_argument('-ca', '--caesar',
                            help='Crypt with caesar cipher. Should be used with --crypta option.',
                            action='store_true')

    grp_crypta.add_argument('-aff', '--affine',
                            help='Crypt with affine cipher. Should be used with --crypta option.',
                            action='store_true')

    grp_crypta.add_argument('-ms', '--monosub',
                            help='Crypt with monoalphabetic substitution cipher. Should be used with --crypta option.',
                            action='store_true')

    grp_crypta.add_argument('-v', '--vigenere',
                            help='Crypt with vigenere cipher. Should be used with --crypta option.',
                            action='store_true')

    grp_crypta.add_argument('-hl', '--hill',
                            help='Crypt with hill cipher. Should be used with --crypta option.',
                            action='store_true')

    grp_crypta.add_argument('-s', '--scytale',
                            help='Crypt with scytale cipher. Should be used with --crypta option.',
                            action='store_true')

    grp_crypta.add_argument('-ct', '--columnar_transposition',
                            help='Crypt with columnar transposition cipher. Should be used with --crypta option.',
                            action='store_true')


    parser.add_argument('-k', '--key',
                        help='The key. Should be used with --crypta option.') #crypta

    parser.add_argument('-k2', '--key2',
                        help='The key number 2 (b). Should be used with --crypta --affine option.') #crypta

    parser.add_argument('-m', '--mode',
                        type=int,
                        choices=(0, 1),
                        help='The mode (0 : encrypt ; 1 : decrypt). Should be used with --crypta option.') #crypta

    parser.add_argument('-mx', '--matrix',
                        type=Matrix,
                        help='The square matrix. Should be used with --crypta --hill option.') #crypta


    #---------base_convert
    parser.add_argument('-n', '--number',
                        help='Number. Should be used with --base_convert option.')

    parser.add_argument('-nb', '--number_base',
                        type=int,
                        help='The number\'s base. Should be used with --base_convert option.')

    parser.add_argument('-b', '--return_base',
                        type=int,
                        help='The number\'s return base. Should be used with --base_convert option.')

    parser.add_argument('-neg', '--negative',
                        action='store_true',
                        help='If typed, means that the number is encoded with the two by two complement standard. Should be used with --base_convert option.')

    parser.add_argument('-ieee754',
                        action='store_true',
                        help='If typed, means that the number is encoded with the IEEE754 standard. Should be used with --base_convert option.')



    parser.add_argument('-pb', '--probabilistic',
                        action='store_true',
                        help='If typed, try probabilistic primality test. Should be used with --prima option.') #Prima


    args = parser.parse_args()


    if args.show_infos: #------------------------------------------------------i

        lock(pwd)

        heading()


    elif args.hash: #--------------------------------------------------------hsh
        fn_xor_txt = (args.text != None and args.file_name == None) ^ (args.text == None or args.file_name != None) # --file_name xor -text are None
        
        if args.hash_type != None and fn_xor_txt:
            #---set text
            if args.text != None and args.file_name == None:
                txt = args.text
                    
            elif args.file_name != None and args.text == None:
                txt = op_f(args.file_name)
                
            else:
                cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!!')

            hashed = hasher.hasher(args.hash_type, txt)

            p = False
            if hashed != 'The hash was NOT founded !!!':
                p = True

            #---return
            if args.file_out == None and p:
                cl_out_2(c_prog, 'The hash of "' + txt + '" in ' + args.hash_type + ' is :\n', c_output, ' ' + hashed)
                
            elif p:
                cl_out(c_output, hashed)
                write_f(args.file_out, hashed)
                cl_out(c_succes, 'Done.')

            else:
                cl_out(c_error, 'The hash was NOT founded !!!')

        else:
            cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) and --hash_type (-ht) options !!! (optionnaly --file_out (-fo)')


    elif args.hash_crack: #---------------------------------------------------hc
    
        fn_xor_txt = (args.text != None and args.file_name == None) ^ (args.text == None or args.file_name != None) # --file_name xor -text are None
        
        if args.hash_type != None and args.file_name != None and fn_xor_txt:

            #---set text
            if args.text != None and args.file_name == None:
                txt = args.text
    
            elif args.file_name != None and args.text == None:
                txt = op_f(args.file_name)
    
            else:
                cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!!')

            #---return
            lock(pwd)

            hasher.hash_crack(args.hash_type, args.text, args.file_name)

        else:
            cl_out(c_error, '\nYou must complete --file_name (-fn), --hash_type (-ht) and --text (-txt) options !!!)')


    elif args.generate_wordlist: #---------------------------------------------w

        if args.alphabet != None and args.lenth != None and args.file_name != None:
            lock(pwd)

            wordlist_generator.use_wrdlst_gen(args.file_name, args.lenth, args.alphabet)

        else:
            cl_out(c_error, '\nYou must complete --lenth (-lth), --alphabet (-alf) and --file_name (-fn) options !!!')


    elif args.open: #----------------------------------------------------------o
        if args.file_name != None:

            wordlist_generator.open_w(args.file_name)

        else:
            cl_out(c_error, '\nYou must complete --file_name (-fn) option !!!')


    elif args.crypta: #--------------------------------------------------------c
        
        fn_xor_txt = (args.text != None and args.file_name == None) ^ (args.text == None or args.file_name != None) # --file_name xor -text are None

        if args.atbash: #-------------------------------atbash
            if fn_xor_txt:
                
                #---set text
                p = True
                if args.text != None and args.file_name == None:
                    txt = args.text
                        
                elif args.file_name != None and args.text == None:
                    txt = op_f(args.file_name)
                    
                else:
                    cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!!')
                    p = False
                
                
                #---set return
                if p:
                    lock(pwd)
                
                if args.alphabet == None and p:
                    ret = crypta.atbash.atbash(txt)

                elif p:
                    ret = crypta.atbash.atbash(txt, args.alphabet)
                    
                #---return
                if args.file_out == None and p:
                    cl_out(c_output, ret)
                    
                elif p:
                    cl_out(c_output, ret)
                    write_f(args.file_out, ret)
                    cl_out(c_succes, 'Done.')


            else:
                cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) option !!! (optionnaly --alphabet (-alf))')


        elif args.caesar: #-------------------------------caesar
            if args.key != None and args.mode != None and fn_xor_txt:

                key = try_int(args.key)
                
                #---set txt
                p = True
                if args.text != None and args.file_name == None:
                    txt = args.text
                        
                elif args.file_name != None and args.text == None:
                    txt = op_f(args.file_name)
                    
                else:
                    cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!!')
                    p = False
                    
                #---set return
                if p:
                    lock(pwd)
                
                if args.alphabet == None and p:
                    ret = crypta.caesar.caesar(txt, key, args.mode)

                elif p:
                    ret = crypta.caesar.caesar(txt, key, args.mode, args.alphabet)
                    
                #---return
                if args.file_out == None and p:
                    cl_out(c_output, ret)
                    
                elif p:
                    cl_out(c_output, ret)
                    write_f(args.file_out, ret)
                    cl_out(c_succes, 'Done.')

            else:
                cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn), --key (-k) and --mode (-m) options !!! (optionnaly --alphabet (-alf))')


        elif args.scytale: #-------------------------------scytale
            if args.key != None and args.mode != None and fn_xor_txt:

                key = try_int(args.key)
                
                #---set txt
                p = True
                if args.text != None and args.file_name == None:
                    txt = args.text
                        
                elif args.file_name != None and args.text == None:
                    txt = op_f(args.file_name)
                    
                else:
                    cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!!')
                    p = False
                    
                #---set return
                if p:
                    lock(pwd)
                    ret = crypta.scytale.scytale(txt, key, args.mode)
                    
                #---return
                if args.file_out == None and p:
                    cl_out(c_output, ret)
                    
                elif p:
                    cl_out(c_output, ret)
                    write_f(args.file_out, ret)
                    cl_out(c_succes, 'Done.')

            else:
                cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn), --key (-k) and --mode (-m) options !!!')


        elif args.affine: #-------------------------------affine
            if args.key != None and args.key2 != None and args.mode != None and fn_xor_txt:

                keya = try_int(args.key)
                keyb = try_int(args.key2)
                
                #---set txt
                p = True
                if args.text != None and args.file_name == None:
                    txt = args.text
                        
                elif args.file_name != None and args.text == None:
                    txt = op_f(args.file_name)
                    
                else:
                    cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!!')
                    p = False
                    
                #---set return
                if p:
                    lock(pwd)
                
                if args.alphabet == None and p:
                    ret = crypta.affine.affine(txt, keya, keyb, args.mode)

                elif p:
                    ret = crypta.affine.affine(txt, keya, keyb, args.mode, args.alphabet)
                    
                #---return
                if args.file_out == None and p:
                    cl_out(c_output, ret)
                    
                elif p:
                    cl_out(c_output, ret)
                    write_f(args.file_out, ret)
                    cl_out(c_succes, 'Done.')

            else:
                cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn), --key (-k), --key2 (-k2) and --mode (-m) options !!! (optionnaly --alphabet (-alf))')


        elif args.monosub: #-----------monoalphabetic_substitution
            if args.key != None and args.mode != None and fn_xor_txt:
                
                #---set txt
                p = True
                if args.text != None and args.file_name == None:
                    txt = args.text
                        
                elif args.file_name != None and args.text == None:
                    txt = op_f(args.file_name)
                    
                else:
                    cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!!')
                    p = False
                    
                #--- set return
                if p:
                    lock(pwd)
                
                if args.alphabet == None and p:
                    ret = crypta.monosub.monosub(txt, args.key, args.mode)

                elif p:
                    ret = crypta.monosub.monosub(txt, args.key, args.mode, args.alphabet)
                    
                #---return
                if args.file_out == None and p:
                    cl_out(c_output, ret)
                    
                elif p:
                    cl_out(c_output, ret)
                    write_f(args.file_out, ret)
                    cl_out(c_succes, 'Done.')

            else:
                cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn), --key (-k) and --mode (-m) options !!! (optionnaly --alphabet (-alf))')


        elif args.vigenere: #-------------------------------vigenere
            if args.key != None and args.mode != None and fn_xor_txt:
                
                #---set txt
                p = True
                if args.text != None and args.file_name == None:
                    txt = args.text
                        
                elif args.file_name != None and args.text == None:
                    txt = op_f(args.file_name)
                    
                else:
                    cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!!')
                    p = False
                    
                #---set return
                if p:
                    lock(pwd)
                
                if args.alphabet == None and p:
                    ret = crypta.vigenere.vigenere(txt, args.key, args.mode)

                elif p:
                    ret = crypta.vigenere.vigenere(txt, args.key, args.mode, args.alphabet)
                
                #---return
                if args.file_out == None and p:
                    cl_out(c_output, ret)
                    
                elif p:
                    cl_out(c_output, ret)
                    write_f(args.file_out, ret)
                    cl_out(c_succes, 'Done.')

            else:
                cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn), --key (-k) and --mode (-m) options !!! (optionnaly --alphabet (-alf) or/and --file_out (-fo))')
                
                
        elif args.hill: #-------------------------------hill
            if args.matrix != None and args.mode != None and fn_xor_txt:
                
                #---set txt
                p = True
                if args.text != None and args.file_name == None:
                    txt = args.text
                        
                elif args.file_name != None and args.text == None:
                    txt = op_f(args.file_name)
                    
                else:
                    cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!!')
                    p = False
                    
                #---set return
                if p:
                    lock(pwd)
                
                if args.alphabet == None and p:
                    ret = crypta.hill.hill(args.matrix, txt, args.mode)

                elif p:
                    ret = crypta.hill.hill(args.matrix, txt, args.mode, args.alphabet)
                    
                #---return
                if args.file_out == None and p:
                    cl_out(c_output, ret)
                    
                elif p:
                    cl_out(c_output, ret)
                    write_f(args.file_out, ret)
                    cl_out(c_succes, 'Done.')

            else:
                cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn), --matrix (-mx) and --mode (-m) options !!! (optionnaly --alphabet (-alf))')


        elif args.columnar_transposition: #-------------columnar_transposition
            if args.key != None and args.mode != None and fn_xor_txt:
                
                #---set txt
                p = True
                if args.text != None and args.file_name == None:
                    txt = args.text
                        
                elif args.file_name != None and args.text == None:
                    txt = op_f(args.file_name)
                    
                else:
                    cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!!')
                    p = False
                    
                #---set return
                if p:
                    lock(pwd)
                
                if args.alphabet == None and p:
                    ret = crypta.columnar_transposition.columnar_transposition(txt, key, args.mode)

                elif p:
                    ret = crypta.columnar_transposition.columnar_transposition(txt, key, args.mode, args.alphabet)
                    
                #---return
                if args.file_out == None and p:
                    cl_out(c_output, ret)
                    
                elif p:
                    cl_out(c_output, ret)
                    write_f(args.file_out, ret)
                    cl_out(c_succes, 'Done.')

            else:
                cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn), --key (-k) and --mode (-m) options !!! (optionnaly --alphabet (-alf))')

        else:
            cl_out(c_error, '\nYou must use one of these options : [--atbash (-atb) | --caesar (-ca) | --affine (-aff) | --monosub (-ms) | --vigenere (-v) | --hill (-hl) | --scytale (-s) | --columnar_transposition (-ct)] !!!')



    elif args.prima: #---------------------------------------------------------p
        if args.number != None:
            n = try_int(args.number)
            
            cl_out(c_output, prima.parser_use(n, args.probabilistic))

        else:
            cl_out(c_error, '\nYou must complete --number (-n) option !!! (and optionnaly --probabilistic (-pb))')



    elif args.freq_ana: #------------------------------------------------------f
        fn_xor_txt = (args.text != None and args.file_name == None) ^ (args.text == None or args.file_name != None) # --file_name xor -text are None
        
        if fn_xor_txt:
            #---set text
            p = True
            if args.text != None and args.file_name == None:
                txt = args.text
    
            elif args.file_name != None and args.text == None:
                txt = op_f(args.file_name)
    
            else:
                cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!!')
                p = False
    
            
            #---return
            if p:
                ret = crypta.freqana.p_use(txt, True)
                
            if args.file_out == None and p:
                cl_out(c_output, ret)
                
            elif p:
                cl_out(c_output, ret)
                write_f(args.file_out, ret)
                cl_out(c_succes, 'Done.')

        else:
            cl_out(c_error, '\nYou must complete --text (-txt) OR --file_name (-fn) options !!! (and optionnaly --file_out (-fo))')



    elif args.base_convert: #-------------------------------------------------bc
    
        if args.number != None and args.number_base != None and args.return_base != None:
            cl_out(c_output, b_cvrt.use_b_cvrt(args.number, args.number_base, args.return_base, args.negative, args.ieee754))

        else:
            cl_out(c_error, '\nYou must complete --number (-n), --number_base (-nb) and --return_base (-b) options !!! (optionnaly --negative (-neg))')



    elif args.pass_test: #---------------------------------------------------pwd
    
        color(c_prog)
        print('\nEnter the password to test :')
        color(c_input)
        word = getpass('>')
        color(c_prog)
        
        ret = pass_test.get_sth(word)
        
        #---return
        if args.file_out == None:
            cl_out(c_output, ret)
            
        else:
            cl_out(c_output, ret)
            write_f(args.file_out, ret)
            cl_out(c_succes, 'Done.')



    else : #--------------------------------------------------------------------
        print('\nWelcome in Cracker !')
        heading(False, False)

        color(c_input)
        print('\nHash : --hash (-hsh) option ;')
        print('Crack a hash (bruteforce attack) : --hash_crack (-hc) option ;')
        print('Generate a wordlist : --generate_wordlist (-w) option ;')
        print('Show info on a wordlist : --open (-o) option ;')
        print('Crypta (cryptography and cryptanalysis fonctions) : --crypta (-c) option ;')
        print('Prima (prime numbers fonctions) : --prima (-p) option ;')
        print('Frequency analysis : --freq_ana (-f) option ;')
        print('Base convert (convert numbers from any base to an other) : --base_convert (-bc) option ;')
        print('P@ssw0rd_Testor (test your password\'s strenth) : --pass_test (-pwd) option ;')
        print('Show informations on Cracker : --show_infos (-i) option.')

        cl_out(c_output, 'Type "crackerp.py -h" for more information.')

        cmd_ = True


##-run
color(c_prog)

print('___')
color(c_ascii)
print(cracker)
color(c_wrdlt)
print('\nby ', authors)

color(c_ascii)
print('')
print('\\'*60)
color(c_prog)


try:
    Cracker_parser()

except KeyboardInterrupt:
    cl_out(c_error, 'Keyboard Interrupt !!!', sp=True)

finally:
    color(c_ascii)
    print('')
    print('\\'*60)


if cmd_:
    if platform.system() == 'Windows':
        cl_out(c_wrdlt, 'Launching command prompt ...\n', c_ascii)
        system('prompt $_┌[$p]─[$t]$_└─$g&cmd') #prompt \n|path>\n> and launch a command prompt instance, to keep the prog open

    elif platform.system() == 'Linux':
        cl_out(c_wrdlt, 'Launching command prompt ...\n', c_ascii)
        system('bash')

#by lasercata, Elerias

# _______        _______  ______ _____ _______ _______
# |______ |      |______ |_____/   |   |_____| |______
# |______ |_____ |______ |    \_ __|__ |     | ______|

#        _______ _______ _______  ______ _______ _______ _______ _______
# |      |_____| |______ |______ |_____/ |       |_____|    |    |_____|
# |_____ |     | ______| |______ |    \_ |_____  |     |    |    |     |
