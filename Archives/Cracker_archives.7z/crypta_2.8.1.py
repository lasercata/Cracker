#!/bin/python3
# -*- coding: utf-8 -*-
"""Crypta is a cryptology program including cryptography and cryptanalysis fonctions."""

auth = 'Elerias'
date = '19.03.2020'
version = '2.8.1'
update_notes = """
Crypta v2.8
Improvements (from 2.7) :
    - Adding Playfair cipher
    - Beginning ver_plain_text
    - Adding crack function in 6 ciphers/codes (caesar, affine, atbash, rail fence, scytale, reverse)
Crypta v2.7       05.03.2020
Improvements (from 2.6.2) :
    - Correcting columnar transposition
    - Adding polybius square
    - Adding ADFGX and ADFGVX ciphers
    - Program works now if Cracker functions are not imported"""


##-initialisation

try:
    from modules.prima import prima
    from modules.base.matrix import *
except:
    pass
try:
    from modules.base.color import color, cl_out, cl_inp, c_succes, c_output, c_wrdlt, c_error, c_prog, c_ascii
    from modules.base.base_functions import use_menu, inp_lst, inp_int
except:
    # If we can't import Cracker, functions have to be defined for the good working of program
    def color(arg):
        pass
    def cl_inp(t):
        return input(t)
    def cl_out(a, t):
        print(t)
    def c_succes(t):
        print(t)
    def c_output(t):
        print(t)
    def c_wrdlt(t):
        print(t)
    def c_error(t=""):
        print(t)
    def c_prog(t):
        print(t)
    def c_ascii(t):
        print(t)
    def use_menu(t):
        t()
    def inp_lst(t, a):
        return input(t)
    def inp_int(t):
        return input(t)


##-plain text checker

def ver_plain_text(text, wprocess=True):
    """Return True if the text means something, else False."""
    if wprocess:
        text = msgform(text, "min", False, False)
    f, ltext = freqana.freqana(text)
    print(f)
    # french
    if f[0][0] != 'e':
        return False
    if f[0][1] / ltext <= 0.12:
        return False
    i = ic.ic(text)
    print(i)
    if i < 0.068 or i > 0.088:
        return False
    for k in range(5):
        if f[k+1][0] not in ('a', 's', 'i', 'n', 't', 'r', 'u', 'l', 'o', 'd', 'c', 'p', 'm'):
            return False
    print(4)
    L = 'bcdfgjklmnpqrstvwxz'
    L2 = 'aeihouy'
    for k in range(len(text)//6):
        w = text[k*6:k*6+6]
        if w[0] in L and w[1] in L and w[2] in L and w[3] in L and w[4] in L and w[5] in L:
            return False
        if w[0] in L2 and w[1] in L2 and w[2] in L2 and w[3] in L2 and w[4] in L1 and w[5] in L2:
            return False
    return True


##-base functions

def bezout(a, b):
    """Return the Bezout's coefficient of a and b.
    r = a % b
    r = ua + vb
    lu : last u
    lv : last v
    q : quotient
    """
    r = a % b
    lu = 1
    lv = 0
    u = 0
    v = 1
    while r > 1:
        r = a % b
        q = (a-r) // b
        u, lu = lu - q*u, u
        v, lv = lv - q*v, v
        a = b
        b = r
    return u, v

def inverse(a, n):
    """Return the inverse of a in base n."""
    u, v = bezout(a, n)
    inverse = u % n
    return inverse

def msgform(M, f, space=False, number=False):
    """Delete the special characters."""
    spe = "àåâæáāăãäąçćčďđėéęèěêĕëəēģğíıìįïīîķłľļĺňņńñőóøòöœõôŕřß§śšşþťțţųüűúůùūûýźżžÀÅÂÆÁĀĂÃÄĄÇĆČĎĐĖÉĘÈĚÊĔËƏĒĢĞÍIÌĮÏĪÎĶŁĽĻĹŇŅŃÑŐÓØÒÖŒÕÔŔŘSS§ŚŠŞÞŤȚŢŲÜŰÚŮÙŪÛÝŹŻŽ"
    nor = "aaaaaaaaaacccddeeeeeeeeeeggiiiiiiikllllnnnnoooooooorrsssssttttuuuuuuuuyzzzAAAAAAAAAACCCDDEEEEEEEEEEGGIIIIIIIKLLLLNNNNOOOOOOOORRSSSSSTTTTTUUUUUUUUYZZZ"
    aut = ""
    Mf = ""
    for k in range(len(spe)):
        M = M.replace(spe[k], nor[k])
    if f == 'maj':
        M = M.upper()
        aut = aut + 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    elif f == 'min':
        M = M.lower()
        aut = aut + 'abcdefghijklmnopqrstuvwxyz'
    else:
        aut = aut + 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    if number:
        aut = aut + '0123456789'
    if space:
        aut = aut + ' '
    for k in range(len(M)):
        if M[k] in aut:
            Mf = Mf + M[k]
    return Mf

def read_lines(T):
    """Return the text issue of the reading in lines of the list of list T."""
    text = ""
    for k in T:
        text = text + "".join(k)
    return text

def read_columns(T):
    """Return the text issue of the reading in columns of the list of list T."""
    text = ""
    for i in range(len(T[0])):
        for j in range(len(T)):
            if len(T[j]) > i:
                text = text + T[j][i]
    return text

def write_lines_c(text, nc):
    """Return the list of the list T issue of the writing in lines of the text in nc columns."""
    T = [[]]
    i = 0
    for k in range(len(text)):
        T[i].append(text[k])
        if k % nc == nc - 1:
            i = i + 1
            T.append([])
    return T

def write_columns_c(text, nc):
    """Return the list of the list T issue of the writing in columns of the text in nc columns."""
    T = []
    nl = len(text) // nc
    r = 0
    if len(text) % nc != 0:
        nl = nl + 1
        r = len(text) % nc
    for k in range(nl):
        T.append([])
    i = 0
    for k in range(len(text)):
        T[i].append(text[k])
        i = (i+1) % nl
        if i == nl - 1 and len(T[i]) == r:
            i = 0
    return T

def generate_alphabet_word(word, alph='abcdefghijklmnopqrstuvwxyz'):
    """Return the cipher alphabet generated with a word key."""
    cipher_alph = ""
    for k in word:
        if k in alph:
            i = alph.index(k)
            alph = alph[0:i] + alph[i + 1:len(alph)]
            cipher_alph = cipher_alph + k
    cipher_alph = cipher_alph + alph
    return cipher_alph

def word_to_square(word, size=5):
    """Return the square issue of a key word."""
    if size == 5:
        alph = 'abcdefghiklmnopqrstuvwxyz'
        for k in range(len(word)):
        	if word[k] == 'j':
        		word = word[0:k] + 'i' + word[k + 1:len(word)]
        L = [[], [], [], [], []]
    elif size == 6:
        alph = 'abcdefghijklmnopqrstuvwxyz0123456789'
        L = [[], [], [], [], [], []]
    alph = generate_alphabet_word(word, alph)
    for i in range(size):
        for j in range(size):
            L[i].append(alph[i*size + j])
    return L

def word_to_transposition_key(word, alph='abcdefghijklmnopqrstuvwxyz'):
    """Return a transposition key generated with a word key."""
    L = []
    for k in range(len(word)):
        i = alph.index(word[k])
        L.append((i, k))
    L.sort()
    Tk = []
    for k in L:
        Tk.append(k[1])
    return Tk

def read_file(f):
    """Return the text read of a file f after deleting of the \n."""
    a = open(f, 'r')
    t = a.read()
    t = t.split('\n')
    t = ' '.join(t)
    a.close()
    return t

def read_file_use():
    """Use read_file."""
    f = cl_inp('Name of the file to read : ')
    try:
        return read_file(f)
    except FileNotFoundError:
        cl_out(c_error, 'The file was NOT found !!!')
        return read_file_use()

def write_file(f, t):
    """Write in a file f the text t."""
    a = open(f, 'a')
    if type(t) == list:
        t = '\n'.join(t)
    a.write(t)
    a.close()

def write_file_use(t=""):
    """Use write_file."""
    f = cl_inp('Name of the file to write the data : ')
    if t == "":
        t = cl_inp('Text : ')
    write_file(f, t)
    print('Operation successfully realised')

def ask_text():
    """Use write_file or ask the text."""
    f = inp_lst('Read text from file ? (y/n) : ', ('y', 'yes', 'Y', 'YES', 'Yes', 'o', 'O', 'oui', 'OUI', 'Oui', 'n', 'no', 'non', 'Non', 'No', 'N', 'NON', 'NO'))
    if f in ('y', 'yes', 'Y', 'YES', 'Yes', 'o', 'O', 'oui', 'OUI', 'Oui'):
        t = read_file_use()
    else:
        t = cl_inp('Enter the text :\n')
    return t

def give_result(res):
    """Use write_file or print the result."""
    r = cl_inp('Write the result in a file ? (y/n) : ')
    if r in ('y', 'yes', 'Y', 'YES', 'o', 'O', 'oui', 'OUI'):
        write_file_use(res)
    else:
        print('Result :\n')
        print(res)


##-ciphers

class playfair:
    """Class using Playfair cipher."""
    
    def playfair(text, key, mode=0):
        square = word_to_square(key)
        r = ""
        a = 1
        i2, i3, j2, j3 = 0, 0, 0, 0
        if mode == 1:
            a = -1
        if len(text) % 2 == 1:
            text = text + "x"
        for l in range(len(text)//2):
            bi = text[l*2:l*2+2]
            print(bi)
            if bi[0] == 'j':
                bi = 'i' + bi[1]
            if bi[1] == 'j':
                bi = bi[0] + 'i'
            if bi[0] == bi[1]:
                bi = bi[0] + "q"
            for i in range(5):
                for j in range(5):
                    if square[i][j] == bi[0]:
                        i2, j2 = i, j
                    elif square[i][j] == bi[1]:
                        i3, j3 = i, j
            if i2 == i3:
                r = r + square[i2][(j2+a)%5] + square[i2][(j3+a)%5]
            elif j2 == j3:
                r = r + square[(i2+a)%5][j2] + square[(i3+a)%5][j3]
            else:
                r = r + square[i2][j3] + square[i3][j2]
        return r

    def encrypt(text, key):
        return playfair.playfair(text, key, mode=0)

    def decrypt(text, key):
        return playfair.playfair(text, key, mode=1)

    def use():
        print('\nPlayfair cipher')
        mode = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) : ', ('0', '1')))
        text = ask_text()
        key = cl_inp('Key : ')
        res = playfair.playfair(text, key, mode)
        give_result(res)


class polybius:
    """Class using the polybus square."""
    
    def polybius(text, key="", mode=0, L_index=['1', '2', '3', '4', '5'], size=5, space=True):
        """i and j are encrypted by the same way."""
        square = word_to_square(key, size)
        r = ""
        d = {}
        # Creating of the dictionnary
        for i in range(size):
            for j in range(size):
                if mode == 0:
                    d[square[i][j]] = L_index[i] + L_index[j]
                else:
                    d[L_index[i] + L_index[j]] = square[i][j]
        if mode == 0:
            if size == 5:
                d['j'] = d['i']
            for i in text:
                if i in d:
                    if space:
                        r = r + d[i] + " "
                    else:
                        r = r + d[i]
            if space:
                r = r[0:-1]
        else:
            if space:
                for i in range(len(text)-1):
                    a = text[i] + text[i + 1] 
                    if a in d:
                        r = r + d[a]
            else:
                for i in range(len(text)):
                    a = text[i*2:i*2+2]
                    if a in d:
                        r = r + d[a]
        return r

    def encrypt(text, key=""):
        return polybius.polybius(text, key, 0)

    def decrypt(text, key=""):
        return polubius.polybius(text, key, 1)

    def use():
        print('\nPolybius square')
        mode = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) : ', ('0', '1')))
        text = ask_text()
        key = cl_inp('Key : ')
        res = polybius.polybius(text, key, mode)
        give_result(res)
    

class morse:
    """Class using morse code."""
  
    def morse(text, mode):
        if mode == 0:
            return morse.encode(text)
        else:
            return morse.decode(text)
        
    def encode(text):
        d = {'a': '.-', 'b': '-...', 'c': '-.-.', 'd': '-..', 'e': '.', 'f': '..-.', 'g': '--.', 'h': '....', 'i': '..', 'j': '.---', 'k': '-.-', 'l': '.-..', 'm': '--', 'n': '-.', 'o': '---', 'p': '.--.', 'q': '--.-', 'r': '.-.', 's': '...', 't': '-', 'u': '..-', 'v': '...-', 'w': '.--', 'x': '-..-', 'y': '-.--', 'z': '--..', '1': '.----', '2': '..---', '3': '...--', '4': '....-', '5': '.....', '6': '-....', '7': '--...', '8': '---..', '9': '----.', '0': '-----'}
        alf_spe = "àåâæáāăãäąçćčďđėéęèěêĕëəēģğíıìįïīîķłľļĺňņńñőóøòöœõôŕřß§śšşþťțţųüűúůùūûýźżž"
        alf_nor = "aaaaaaaaaacccddeeeeeeeeeeggiiiiiiikllllnnnnoooooooorrsssssttttuuuuuuuuyzzz"
        text = text.lower()
        res = ""
        for k in text:
            if k in alf_spe:
                res += d[alf_nor[alf_spe.index(k)]] + ' '
            elif k in d:
                res += d[k] + ' '
            elif k == ' ':
                res += '/ '
        return res
        
    def decode(text, a='.', b='-', sep_l=' ', sep_w='/'):
        d = {a+b: 'a', b+a+a+a: 'b', b+a+b+a: 'c', b+a+a: 'd', a: 'e', a+a+b+a: 'f', b+b+a: 'g', a+a+a+a: 'h', a+a: 'i', a+b+b+b: 'j', b+a+b: 'k', a+b+a+a: 'l', b+b: 'm', b+a: 'n', b+b+b: 'o', a+b+b+a: 'p', b+b+a+b: 'q', a+b+a: 'r', a+a+a: 's', b: 't', a+a+b: 'u', a+a+a+b: 'v', a+b+b: 'w', b+a+a+b: 'x', b+a+b+b: 'y', b+b+a+a: 'z', a+b+b+b+b: '1', a+a+b+b+b: '2', a+a+a+b+b: '3', a+a+a+a+b: '4', a+a+a+a+a: '5', b+a+a+a+a: '6', b+b+a+a+a: '7', b+b+b+a+a: '8', b+b+b+b+a: '9', b+b+b+b+b: '0', sep_w: ' '}
        T = text.split(sep_l)
        res = ""
        for k in T:
            if k in d:
                res += d[k]
        return res
    
    def use():
        print("\nMorse code")
        t = ask_text()
        res = morse.encode(t)
        give_result(res)


class reverse_code:
    """Class using reverse code."""

    def reverse_code(text):
        L = list(text)
        L.reverse()
        return "".join(L)

    def crack(text):
        t2 = reverse.reverse(text)
        if ver_plain_text(t2):
            return [True, t2]
        else:
            return False

    def use():
        print("\nReverse code")
        text = ask_text()
        res = reverse_code.reverse_code(text)
        give_result(res)


class scytale:
    """Class using scytale cipher."""

    def scytale(text, key, mode=0):
        key = int(key)
        if mode == 0:
            T = write_lines_c(text, key)
            return read_columns(T)
        else:
            T = write_columns_c(text, key)
            return read_lines(T)

    def encrypt(text, key):
        return scytale.scytale(text, key, 0)

    def decrypt(text, key):
        return scytale.scytale(text, key, 1)

    def crack(text):
        for k in range(len(text)):
            t2 = scytale.scytale(text, k, 1)
            if ver_plain_text(t2):
                return [True, t2, k]
        return [False]

    def use():
        print('\nScytale cipher')
        mode = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        text = ask_text()
        key = inp_int('Key :')
        res = scytale.scytale(text, key, mode)
        give_result(res)


class columnar_transposition:
    """Class using columnar transposition cipher."""

    def columnar_transposition(text, key, mode=0):
        if type(key) == str:
            key = word_to_transposition_key(key)
        nc = len(key)
        nl = len(text)//nc
        r = len(text) % nc
        if mode == 0:
            T = write_lines_c(text, nc)
            c = ""
            for k in range(nc):
                i = key[k]
                for l in T:
                    if len(l) > i:
                        c = c + l[i]
            return c
        else:
            T = []
            if r != 0:
                nl = nl + 1
            for k in range(nl):
                if k == nl - 1 and r != 0:
                        T.append([""] * r)
                else:
                    T.append([""] * nc)
            for i in range(nc):
                j = key[i]
                for k in range(nl):
                    if k != nl - 1 or r == 0:
                        T[k][j] = text[0]
                        text = text[1:len(text)]
                    else:
                        if j < r:
                            T[k][j] = text[0]
                            text = text[1:len(text)]

            clairtext = read_lines(T)
            return clairtext

    def encrypt(text, key):
        print(text)
        return columnar_transposition.columnar_transposition(text, key, 0)

    def decrypt(text, key):
        print(text)
        return columnar_transposition.columnar_transposition(text, key, 1)

    def use():
        print('\nColumnar transposition cipher')
        mode = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) : ', ('0', '1')))
        text = ask_text()
        key = cl_inp('Key : ')
        res = columnar_transposition.columnar_transposition(text, key, mode)
        give_result(res)


class rail_fence:
    """Class using Rail Fence cipher."""

    def rail_fence(text, key, mode=0):
        key = int(key)
        L = []
        for k in range(key):
            L.append([])            # We create a list of the levels
        if mode == 0:
            lev = 0
            m = 1                       # m is the step
            for k in text:
                L[lev].append(k)
                if lev == key - 1:
                    m = - 1
                elif lev == 0:
                    m = 1
                lev = lev + m
            res = ""
            for k in L:
                res += "".join(k)
            return res
        else:
            lt = len(text)
            ttest = 'X' * lt
            lev = 0
            m = 1
            for k in ttest:
                L[lev].append(k)
                if lev == key - 1:
                    m = - 1
                elif lev == 0:
                    m = 1
                lev = lev + m
            n = 0
            for i in L:
                for j in range(len(i)):
                    i[j] = text[n]
                    n = n + 1
            res = ""
            lev = 0
            m = 1
            while len(res) != lt:
                if lev >= len(L) or lev < 0:
                    m = 0 - m
                    lev = lev + m + m
                if len(L[lev]) != 0:
                    res += L[lev][0]
                    L[lev] = L[lev][1:len(L[lev])]
                lev = lev + m
            return res

    def encrypt(text, key):
    	return rail_fence.rail_fence(text, key, 0)

    def decrypt(text, key):
    	return rail_fence.rail_fence(text, key, 1)

    def crack(text):
        for k in range(len(text)):
            t2 = rail_fence.rail_fence(text, k, 1)
            if ver_plain_text(t2):
                return [True, t2, k]
        return [False]

    def use():
        print('\nRail fence cipher')
        t = ask_text()
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        key = int(cl_inp("Key : "))
        res = rail_fence.rail_fence(t, key, mode)
        give_result(res)


class atbash:
    """Class using Atbash cipher."""

    def atbash(M, alf='abcdefghijklmnopqrstuvwxyz'):
        alf2 = "".join(reversed(alf))
        C = ""
        for k in M:
            C += alf2[alf.index(k)]
        return C

    def crack(text, alph='abcdefghijklmnopqrstuvwxyz'):
        t2 = atbash(text, alph)
        if ver_plain_text(t2):
            return [True, t2]
        else:
            return False

    def use():
        print('\nAtbash cipher')
        alf = cl_inp('Alphabet (let empty to use normal) :')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        t = ask_text()
        res = atbash.atbash(t, alf)
        give_result(res)


class caesar:
    """Class using Caesar cipher."""

    def caesar(M, key, mode=0, alf='abcdefghijklmnopqrstuvwxyz'):
        if type(key) == str:
            if not (key[0] in "0123456789"):
                key = alf.index(key)
            else:
                key = int(key)
        lalf = len(alf)
        C = ""
        if mode == 1:
            key = lalf - key
        for k in M:
            C += alf[(alf.index(k) + key) % lalf]
        return C

    def encrypt(M, key, alf='abcdefghijklmnopqrstuvwxyz'):
        return caesar.caesar(M, key, 0, alf)

    def decrypt(M, key, alf='abcdefghijklmnopqrstuvwxyz'):
        return caesar.caesar(M, key, 1, alf)

    def crack(text, alph='abcdeffhijklmnopqrstuvwxyz'):
        for k in range(len(alph)):
            t2 = caesar.caesar(text, k, 1, alph)
            if ver_plain_text(t2):
                return [True, t2, k]
        return [False]

    def use():
        print('\nCaesar cipher')
        alf = cl_inp('Alphabet (let empty to use normal) :')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        t = ask_text()
        k = int(cl_inp('Key : '))
        res = caesar.caesar(t, k, m, alf)
        give_result(res)
    

class affine:
    """Class using affine cipher."""

    def affine(M, keya, keyb, mode=0, alf='abcdefghijklmnopqrstuvwxyz'):
        keya = int(keya)
        keyb = int(keyb)
        C = ""
        lalf = len(alf)
        if mode == 1:
            keya = inverse(keya, lalf)
            for k in M:
                C += alf[((alf.index(k) - keyb) * keya) % lalf]
        else:
            for k in M:
                C += alf[(alf.index(k) * keya + keyb) % lalf]
        return C

    def encrypt(M, keya, keyb, alf='abcdefghijklmnopqrstuvwxyz'):
        return affine.affine(M, keya, keyb, 0, alf)

    def decrypt(M, keya, keyb, alf='abcdefghijklmnopqrstuvwxyz'):
        return affine.affine(M, keya, keyb, 1, alf)
    
    def crack(text, alph='abcdefghijklmnopqrstuvwxyz'):
        for a in range(len(alph)):
            if gcd(a, alph) == 1:
                for b in range(len(alph)):
                    t2 = affine.affine(text, k, 1, alph)
                    if ver_plain_text(t2):
                        return [True, t2, k]
        return [False]

    def use():
        print('\nAffine cipher')
        alf = cl_inp('Alphabet (let empty to use normal) :')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        t = ask_text()
        a = int(cl_inp('Key a : '))
        b = int(cl_inp('Key b : '))
        res = affine.affine(t, a, b, m, alf)
        give_result(res)


class vigenere:
    """Class using Vigenere cipher."""

    def vigenere(M, key, mode, alf='abcdefghijklmnopqrstuvwxyz'):
        lalf = len(alf)
        lm = len(M)
        lkey = len(key)
        key = key * int(lm / lm + 2)
        C = ""
        if mode == 1:
            for k in range(lm):
                C += alf[(alf.index(M[k]) - alf.index(key[k % lkey]) + lalf) % lalf]
        else :
            for k in range(lm):
                C += alf[(alf.index(M[k]) + alf.index(key[k % lkey])) % lalf]
        return C

    def encrypt(M, key, alf='abcdefghijklmnopqrstuvwxyz'):
        return vigenere.vigenere(M, key, 0, alf)

    def decrypt(M, key, alf='abcdefghijklmnopqrstuvwxyz'):
        return vigenere.vigenere(M, key, 1, alf)

    def use():
        print('\nVigenere cipher')
        alf = cl_inp('Alphabet (let empty to use normal) :')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        t = ask_text()
        k = cl_inp('Key : ')
        res = vigenere.vigenere(t, k, m, alf)
        give_result(res)

class ADFGVX:
    """Class using ADFGVX cipher."""

    def ADFGVX(text, square_key, transposition_key, mode=0):
        if mode == 0:
            return columnar_transposition.encrypt(polybius.polybius(text, square_key, 0, L_index=['A', 'D', 'F', 'G', 'V', 'X'], size=6, space=False), transposition_key)
        else:
            return polybius.polybius(columnar_transposition.decrypt(text, transposition_key), square_key, 1, L_index=['A', 'D', 'F', 'G', 'V', 'X'], size=6, space=False)

    def encrypt(text, square_key, transposition_key):
        return ADFGVX.ADFGVX(text, square_key, transposition_key, mode=0)

    def decrypt(text, square_key, transposition_key):
        return ADFGVX.ADFGVX(text, square_key, transposition_key, mode=1)

    def use():
        print("\nADFGVX cipher")
        t = ask_text()
        sk = cl_inp("Square key : ")
        tk = cl_inp("Transposition key : ")
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        res = ADFGVX.ADFGVX(t, sk, tk, m)
        give_result(res)


class ADFGX:
    """Class using ADFGX cipher."""

    def ADFGX(text, square_key, transposition_key, mode=0):
        if mode == 0:
            return columnar_transposition.encrypt(polybius.polybius(text, square_key, 0, L_index=['A', 'D', 'F', 'G', 'X'], size=5, space=False), transposition_key)
        else:
            return polybius.polybius(columnar_transposition.decrypt(text, transposition_key), square_key, 1, L_index=['A', 'D', 'F', 'G', 'X'], size=5, space=False)

    def encrypt(text, square_key, transposition_key):
        return ADFGVX.ADFGVX(text, square_key, transposition_key, mode=0)

    def decrypt(text, square_key, transposition_key):
        return ADFGVX.ADFGVX(text, square_key, transposition_key, mode=1)

    def use():
        print("\nADFGX cipher")
        t = ask_text()
        sk = cl_inp("Square key : ")
        tk = cl_inp("Transposition key : ")
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        res = ADFGX.ADFGX(t, sk, tk, m)
        give_result(res)

class monosub:
    """Class using monoalphabetic substitution cipher."""

    def monosub(M, key, mode=0, alf='abcdefghijkmnopqrstuvwxyz'):
        alfcrypt = generate_alphabet_word(key, alf)
        if mode == 1:
            alf, alfcrypt = alfcrypt, alf
        lalf = len(alf)
        if len(alfcrypt) != lalf:
            return 0
        C = ""
        for k in M :
            C += alfcrypt[alf.index(k)]
        return C

    def encrypt(M, key, alf='abcdefghijkmnopqrstuvwxyz'):
        monosub.monosub(M, key, 0, alf)

    def decrypt(M, key, alf='abcdefghijkmnopqrstuvwxyz'):
        monosub.monosub(M, key, 1, alf)

    def use():
        print('\nMonoalphabetic substitution cipher')
        alf = cl_inp('Plaintext alphabet (let empty to use normal) : ')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        t = ask_text()
        k = cl_inp('Ciphertext alphabet or word : ')
        res = monosub.monosub(t, k, m, alf)
        give_result(res)


class freqana:
    """Class using frequency analysis."""

    def freqana(M, wprocess=False):
        if wprocess:
            M = msgform(M, 'min')
        D = {}
        for k in M:
            if k in D:
                D[k] += 1
            else:
                D[k] = 1
        L = sorted(D.items(), key=lambda t: t[1])
        L.reverse()
        return L, len(M)

    def use():
        print('\nFrequency analysis')
        t = ask_text()
        p = inp_lst('Word processing (y/n) ? ', ('yes', 'y', 'oui', 'o', 'Yes', 'Oui', 'n', 'no', 'non', 'Non', 'No'))
        if p in ('yes', 'y', 'oui', 'o', 'Yes', 'Oui'):
            p = True
        else:
            p = False
        L, lt = freqana.freqana(t, p)
        # Processing of list
        res = ""
        for k in L:
            res += str(k[0]) + ' : ' + str(k[1]) + ' --> ' + str(round(k[1] / lt, 4) * 100) + ' %\n'
        res += '\n' + str(lt) + ' characters analyzed'
        give_result(res)


class ic:
    """Class using index of coincidence."""

    def ic(M, wprocess=False):
        if wprocess:
            M = msgform(M, 'min')
        D = {}
        for k in M:
            if k in D:
                D[k] += 1
            else:
                D[k] = 1
        ic = 0
        for k in D:
            n = D[k]
            ic += n * (n-1)
        lm = len(M)
        return ic / (lm * (lm-1))

    def use():
        print('\nIndex of coincidence')
        t = ask_text()
        p = inp_lst('Word processing (y/n) ? ', ('yes', 'y', 'oui', 'o', 'Yes', 'Oui', 'n', 'no', 'non', 'Non', 'No'))
        if p in ('yes', 'y', 'oui', 'o', 'Yes', 'Oui'):
            p = True
        else:
            p = False
        res = ic.ic(t, p)
        give_result(res)


class kasiki:
    """Class using Kasiki examination."""

    def kasiki(M, p):
        if p:
            M = msgform(M, 'maj', False, True)
        lm = len(M)
        L_tri = {}
        L_quad = {}
        L_rep = {}
        for k in range(lm):
            if k <= lm - 3:
                tri = M[k:k + 3]
                if tri in L_tri:
                    d = k - L_tri[tri]
                    L_rep[tri] = (L_tri[tri] + 1, k + 1, d, prima.decomposition_divisions_successives(d))
                else:
                    L_tri[tri] = k
                if k <= lm - 4:
                    quad = tri + M[k + 3]
                    if quad in L_quad:
                        d = k - L_quad[quad]
                        L_rep[quad] = (L_quad[quad] + 1, k + 1 , d, prima.decomposition_divisions_successives(d))
                    else :
                        L_quad[quad] = k
        return L_rep

    def use():
        print('\nKasiki examination')
        t = ask_text()
        p = inp_lst('Word processing (y/n) ? ', ('yes', 'y', 'oui', 'o', 'Yes', 'Oui', 'n', 'no', 'non', 'Non', 'No'))
        if p in ('yes', 'y', 'oui', 'o', 'Yes', 'Oui'):
            p = True
        else:
            p = False
        d = kasiki.kasiki(t, p)
        res = "\n"
        for i in d:
            L = d[i]
            p = str(i) + ' : '
            for j in range(len(L) - 2):
                p = p + str(L[j])
                if j < len(L) - 3:
                    p = p + '-'
                elif j == len(L) - 3:
                    p = p + ' --> ' + str(L[j])
            res = res + p + ' --> ' + str(L[-1][1]) + '\n'


class hill:
    """Class using Hill cipher."""

    def hill(M, text, mode, alphabet='abcdefghijklmnopqrstuvwxyz') :
        """Return the encryption of the text with the square matrix M."""

        if type(M) != Matrix:
            M = Matrix(M)
        la = len(alphabet)
        if mode == 1 :
            M = M.inverse(la)
        dimension = len(M[0])
        text = text + 'x' * ((dimension - len(text) % dimension) % dimension)
        text_c = ""
        for k in range(len(text) // dimension):
            C = []    # column vector
            for l in text[k * dimension:k * (dimension+1)]:
                C.append([alphabet.index(l)])
            C2 = Matrix(C)
            C2 = M * C2
            C2 = C2 % la
            for l in C2 :
                text_c = text_c + alphabet[int(l[0])]
        return text_c

    def encrypt(M, text, alf='abcdefghijklmnopqrstuvwxyz'):
        return hill(M, text, 0, alf)

    def decrypt(M, text, alf='abcdefghijklmnopqrstuvwxyz'):
        return hill(M, text, 0, alf)

    def use():
        print('\nHill cipher')
        alf = cl_inp('Alphabet (let empty to use normal) :')
        if alf == "":
            alf = 'abcdefghijklmnopqrstuvwxyz'
        m = int(inp_lst('Mode (crypt : 0 ; decrypt : 1) :', ('0', '1')))
        t = ask_text()
        tM = inp_int("Dimension of the sqare matrix :")
        M = []
        for k in range(tM):
            L = []
            for l in range(tM):
                t = cl_inp('Line ' + str(k + 1) + ' column ' + str(l + 1) + ' : ')
                L.append(int(t))
            M.append(L)
        print(M)
        M = Matrix(M)
        print(M)
        res = hill.hill(M, t, m, alf)
        give_result(res)


def textana():
    """Return the analysis of the text."""

    print('\nText analysis')
    t = ask_text()
    p = inp_lst('Word processing (y/n) ? ', ('yes', 'y', 'oui', 'o', 'Yes', 'Oui', 'n', 'no', 'non', 'Non', 'No'))
    if p in ('yes', 'y', 'oui', 'o', 'Yes', 'Oui'):
        p = True
    else:
        p = False
    res = '\nFrequence analysis\n'
    L, lt = freqana.freqana(t, p)
    # Processing of list
    for k in L:
        res += str(k[0]) + ' : ' + str(k[1]) + ' --> ' + str(round(k[1] / lt, 2)) + ' %' + '\n'
    res += str(lt) + ' characters analyzed'
    res += '\nIndex of coincidence : ' + str(round(ic.ic(t, p), 4))
    res += '\nKasiki examination\n\n'
    d = kasiki.kasiki(t, p)
    for i in d:
        L = d[i]
        p = str(i) + ' : '
        for j in range(len(L) - 2):
            p = p + str(L[j])
            if j < len(L) - 3:
                p = p + '-'
            elif j == len(L) - 3:
                    p = p + ' --> ' + str(L[j])
        res = res + p + ' --> ' + str(L[-1][1]) + '\n'
    res += '\nEnd of the analysis'
    give_result(res)


##-using

def use():
    """Use crypta fonctions."""

    d = {'1': textana, '1a': freqana.use, '1b': ic.use, '1c': kasiki.use, '2': morse.use, '3': atbash.use, '4': caesar.use, '5': affine.use, '6': polybius.use, '7': monosub.use, '8': vigenere.use, '9': playfair.use, '10': hill.use, '11': reverse_code.use, '12': rail_fence.use, '13': scytale.use, '14': columnar_transposition.use, '15a': ADFGX.use, '15b': ADFGVX.use}
    c = ""
    while c not in ('0', 'q'):

        color(c_succes)
        print()
        print('\\'*50)

        color(c_prog)
        print('\nCrypta menu :\n')

        color(c_error)
        print('    0.Exit')

        color(c_succes)
        print('    ' + '-'*16)
        color(c_ascii)

        print('    1.Text analysis')
        print('    1a.Frequence analysis')
        print('    1b.Index of coincidence')
        print('    1c.Kasiki examination')
        color(c_succes)
        print('    ' + '-'*16)
        color(c_ascii)
        print('    2.Morse code')
        color(c_succes)
        print('    ' + '-'*16)
        print('    3.Atbash cipher')
        print('    4.Caesar cipher')
        print('    5.Affine ciper')
        print('    6.Polybius square')
        print('    7.Monoalphabetic substitution cipher')
        print('    8.Vigenere cipher')
        print('    9.Playfair cipher')
        print('    10.Hill cipher')
        print('    11.Reverse code')
        print('    12.Rail fence cipher')
        print('    13.Scytale cipher')
        print('    14.Columnar transposition cipher')
        print('    15a.ADFGX cipher')
        print('    15b.ADFGVX cipher')
        print()
        color(c_prog)

        c = ""
        c = cl_inp('Your Choice : ')

        if c not in d and c not in ('q', '0'):
            prnt = c + ' is NOT an option of this menu !'
            cl_out(c_error, prnt)
        elif c not in ('q', '0'):
            use_menu(d[c])
            color(c_succes)
            cl_inp('\n---End---')
            color(c_prog)